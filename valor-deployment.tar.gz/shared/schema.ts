import { pgTable, text, serial, integer, boolean, timestamp, jsonb, date, time } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  preferences: jsonb("preferences"),  // Store user preferences as JSON
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const usersRelations = relations(users, ({ many }) => ({
  reminders: many(reminders),
  printModels: many(printModels),
  learningProgress: many(learningProgress),
  projects: many(projects),
}));

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  preferences: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Message schema
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  role: text("role").notNull(), // 'user' or 'assistant'
  content: text("content").notNull(),
  metadata: jsonb("metadata"), // For additional data like attachments, source references
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  userId: true,
  role: true,
  content: true,
  metadata: true,
});

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// Reminders & Scheduled Tasks schema
export const reminders = pgTable("reminders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: date("due_date"),
  dueTime: time("due_time"),
  recurring: boolean("recurring").default(false),
  recurringPattern: text("recurring_pattern"), // daily, weekly, monthly, etc.
  completed: boolean("completed").default(false),
  notified: boolean("notified").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const remindersRelations = relations(reminders, ({ one }) => ({
  user: one(users, {
    fields: [reminders.userId],
    references: [users.id],
  }),
}));

export const insertReminderSchema = createInsertSchema(reminders).pick({
  userId: true,
  title: true,
  description: true,
  dueDate: true,
  dueTime: true,
  recurring: true,
  recurringPattern: true,
  notified: true,
  completed: true,
});

export type InsertReminder = z.infer<typeof insertReminderSchema>;
export type Reminder = typeof reminders.$inferSelect;

// 3D Print Models schema
export const printModels = pgTable("print_models", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  gcode: text("gcode"), // Actual G-code or path to G-code file
  parameters: jsonb("parameters"), // Print parameters as JSON
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const printModelsRelations = relations(printModels, ({ one }) => ({
  user: one(users, {
    fields: [printModels.userId],
    references: [users.id],
  }),
}));

export const insertPrintModelSchema = createInsertSchema(printModels).pick({
  userId: true,
  name: true,
  description: true,
  gcode: true,
  parameters: true,
});

export type InsertPrintModel = z.infer<typeof insertPrintModelSchema>;
export type PrintModel = typeof printModels.$inferSelect;

// Learning Progress schema
export const learningProgress = pgTable("learning_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  topic: text("topic").notNull(),
  progress: integer("progress").default(0), // 0-100%
  notes: text("notes"),
  resources: jsonb("resources"), // List of resources used
  lastStudied: timestamp("last_studied").defaultNow(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const learningProgressRelations = relations(learningProgress, ({ one }) => ({
  user: one(users, {
    fields: [learningProgress.userId],
    references: [users.id],
  }),
}));

export const insertLearningProgressSchema = createInsertSchema(learningProgress).pick({
  userId: true,
  topic: true,
  progress: true,
  notes: true,
  resources: true,
  lastStudied: true,
});

export type InsertLearningProgress = z.infer<typeof insertLearningProgressSchema>;
export type LearningProgress = typeof learningProgress.$inferSelect;

// Projects schema
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  status: text("status").default("In Progress"),
  deadline: timestamp("deadline"),
  progress: integer("progress").default(0), // 0-100%
  tasks: jsonb("tasks"), // List of tasks
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const projectsRelations = relations(projects, ({ one }) => ({
  user: one(users, {
    fields: [projects.userId],
    references: [users.id],
  }),
}));

export const insertProjectSchema = createInsertSchema(projects).pick({
  userId: true,
  name: true,
  description: true,
  status: true,
  deadline: true,
  progress: true,
  tasks: true,
  notes: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// Message schemas for API requests/responses
export const askMessageSchema = z.object({
  user: z.string().default("default"),
  message: z.string().min(1, "Message cannot be empty"),
  systemPrompt: z.string().optional(), // Optional system prompt for specific instructions
});

export type AskMessageRequest = z.infer<typeof askMessageSchema>;

export const messageResponseSchema = z.object({
  reply: z.string()
});

export type MessageResponse = z.infer<typeof messageResponseSchema>;

// Reminder request schema
export const reminderSchema = z.object({
  userId: z.string().default("default"),
  title: z.string().min(1, "Title cannot be empty"),
  description: z.string().optional(),
  dueDate: z.string().optional(), // ISO date format
  dueTime: z.string().optional(), // ISO time format
  recurring: z.boolean().optional(),
  recurringPattern: z.string().optional(),
});

export type ReminderRequest = z.infer<typeof reminderSchema>;

// Print model request schema
export const printModelSchema = z.object({
  userId: z.string().default("default"),
  name: z.string().min(1, "Name cannot be empty"),
  description: z.string().optional(),
  parameters: z.record(z.any()).optional(), // Print parameters as JSON
  geometryDescription: z.string().optional(), // Description for generating G-code
});

export type PrintModelRequest = z.infer<typeof printModelSchema>;

// Define conversation schema for memory storage
export type Conversation = {
  userId: string;
  messages: {
    role: 'user' | 'assistant' | 'system';
    content: string;
  }[];
};
