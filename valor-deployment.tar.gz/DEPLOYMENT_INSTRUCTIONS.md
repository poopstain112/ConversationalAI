# Valor AI - Digital Ocean Deployment

## Quick Start Commands

### 1. Upload Files to Your Server
```bash
# Upload the valor-deploy directory to your Digital Ocean server
scp -r valor-deploy/ root@your-server-ip:/var/www/
```

### 2. Server Setup (Ubuntu 20.04+)
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PostgreSQL
sudo apt install postgresql postgresql-contrib -y
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Install PM2 and Nginx
sudo npm install -g pm2
sudo apt install nginx -y
```

### 3. Database Setup
```bash
# Create database user and database
sudo -u postgres createuser --interactive valor_user
sudo -u postgres createdb valor_db
sudo -u postgres psql -c "ALTER USER valor_user WITH PASSWORD 'your_secure_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE valor_db TO valor_user;"
```

### 4. Configure Environment
```bash
cd /var/www/valor-deploy
cp .env.example .env
nano .env
```

Edit .env file:
```
NODE_ENV=production
PORT=3000
OPENAI_API_KEY=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
DATABASE_URL=postgresql://valor_user:your_secure_password@localhost:5432/valor_db
```

### 5. Install Dependencies and Start
```bash
npm install --production
pm2 start ecosystem.config.js
pm2 startup
pm2 save
```

### 6. Setup Nginx for HTTPS
```bash
# Install SSL certificate
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d yourdomain.com

# Nginx will auto-configure HTTPS
sudo systemctl reload nginx
```

## Access Valor
- Visit: https://yourdomain.com
- Camera access will work immediately with HTTPS
- All memory and conversation history preserved

## Troubleshooting
```bash
# Check Valor status
pm2 status
pm2 logs valor

# Check database connection
sudo -u postgres psql valor_db -c "SELECT version();"

# Restart Valor
pm2 restart valor
```

Valor is now running independently on your Digital Ocean server with full camera capabilities!