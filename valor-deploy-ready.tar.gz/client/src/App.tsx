import { Route, Switch } from "wouter";
import Valor from "./pages/Valor";

function App() {
  return (
    <Switch>
      <Route path="/" component={Valor} />
    </Switch>
  );
}

export default App;