import React, { useState, useEffect } from 'react';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Settings, 
  VolumeX, 
  Volume2,
  PaintBucket,
  Moon,
  Sun,
  Laptop,
  Save,
  Trash,
  AlertTriangle,
  BrainCircuit,
  Bell,
  BellOff
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { VoiceSettings, type VoiceSettings as VoiceSettingsType } from '@/components/settings/voice-settings';

// Default voice settings
const defaultVoiceSettings: VoiceSettingsType = {
  enabled: true,
  voice: '',  // Will be populated with first available voice
  rate: 1.0,
  pitch: 1.0,
  volume: 1.0,
  autoRead: true
};

// App settings interface
interface AppSettings {
  theme: 'light' | 'dark' | 'system';
  enableProactiveMessages: boolean;
  notificationSound: boolean;
  saveConversationHistory: boolean;
  autoSaveInterval: number; // in minutes
  customName: string;
  customWelcomeMessage: string;
  voiceSettings: VoiceSettingsType;
}

// Default app settings
const defaultAppSettings: AppSettings = {
  theme: 'system',
  enableProactiveMessages: true,
  notificationSound: true,
  saveConversationHistory: true,
  autoSaveInterval: 5,
  customName: 'Valor AI',
  customWelcomeMessage: "Hello! I'm Valor AI, your intelligent assistant. How can I help you today?",
  voiceSettings: defaultVoiceSettings
};

export default function SettingsPage() {
  const { toast } = useToast();
  const [settings, setSettings] = useState<AppSettings>(defaultAppSettings);
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  
  // Load settings on mount
  useEffect(() => {
    const loadSettings = () => {
      try {
        const savedSettings = localStorage.getItem('app_settings');
        if (savedSettings) {
          const parsedSettings = JSON.parse(savedSettings);
          setSettings(parsedSettings);
        }
        setSettingsLoaded(true);
      } catch (error) {
        console.error('Error loading settings:', error);
        toast({
          title: "Error loading settings",
          description: "Could not load your saved settings",
          variant: "destructive",
        });
        setSettingsLoaded(true);
      }
    };
    
    loadSettings();
  }, [toast]);
  
  // Save settings
  const saveSettings = () => {
    try {
      localStorage.setItem('app_settings', JSON.stringify(settings));
      toast({
        title: "Settings saved",
        description: "Your preferences have been saved",
      });
      
      // Apply theme settings
      if (settings.theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else if (settings.theme === 'light') {
        document.documentElement.classList.remove('dark');
      } else {
        // System theme
        if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }
    } catch (error) {
      toast({
        title: "Error saving settings",
        description: "Could not save your settings",
        variant: "destructive",
      });
    }
  };
  
  // Reset settings to defaults
  const resetSettings = () => {
    if (confirm('Are you sure you want to reset all settings to defaults?')) {
      setSettings(defaultAppSettings);
      toast({
        title: "Settings reset",
        description: "All settings have been reset to defaults",
      });
    }
  };
  
  // Update voice settings
  const updateVoiceSettings = (voiceSettings: VoiceSettingsType) => {
    setSettings(prev => ({
      ...prev,
      voiceSettings
    }));
  };
  
  // If settings haven't loaded yet, show loading state
  if (!settingsLoaded) {
    return (
      <div className="container mx-auto py-6">
        <div className="flex items-center justify-center h-screen">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-2">Loading settings...</h2>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center gap-2 mb-6">
        <Settings className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-bold">Settings</h1>
      </div>
      
      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="voice">Voice</TabsTrigger>
        </TabsList>
        
        {/* General Settings */}
        <TabsContent value="general" className="space-y-6">
          {/* Basic Settings */}
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>
                Configure basic settings for your AI assistant
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="custom-name" className="flex flex-col gap-1">
                  <span>Assistant name</span>
                  <span className="text-xs text-muted-foreground">
                    Customize the name of your AI assistant
                  </span>
                </Label>
                <Input
                  id="custom-name"
                  value={settings.customName}
                  onChange={(e) => 
                    setSettings(prev => ({ ...prev, customName: e.target.value }))
                  }
                  className="max-w-[250px]"
                />
              </div>
              
              <div className="flex items-start justify-between pt-2">
                <Label htmlFor="welcome-message" className="flex flex-col gap-1">
                  <span>Welcome message</span>
                  <span className="text-xs text-muted-foreground">
                    Customize the initial greeting message
                  </span>
                </Label>
                <Textarea
                  id="welcome-message"
                  value={settings.customWelcomeMessage}
                  onChange={(e) => 
                    setSettings(prev => ({ ...prev, customWelcomeMessage: e.target.value }))
                  }
                  className="max-w-[350px] min-h-[80px]"
                />
              </div>
            </CardContent>
          </Card>
          
          {/* Notifications Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Notifications</CardTitle>
              <CardDescription>
                Configure how and when the AI assistant communicates with you
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="proactive-toggle" className="flex flex-col gap-1">
                  <span>Enable proactive messages</span>
                  <span className="text-xs text-muted-foreground">
                    Allow the assistant to initiate conversations
                  </span>
                </Label>
                <Switch 
                  id="proactive-toggle"
                  checked={settings.enableProactiveMessages}
                  onCheckedChange={(checked) => 
                    setSettings(prev => ({ ...prev, enableProactiveMessages: checked }))
                  }
                />
              </div>
              
              <div className="flex items-center justify-between">
                <Label htmlFor="sound-toggle" className="flex flex-col gap-1">
                  <span>Notification sounds</span>
                  <span className="text-xs text-muted-foreground">
                    Play a sound when new notifications arrive
                  </span>
                </Label>
                <Switch 
                  id="sound-toggle"
                  checked={settings.notificationSound}
                  onCheckedChange={(checked) => 
                    setSettings(prev => ({ ...prev, notificationSound: checked }))
                  }
                />
              </div>
            </CardContent>
          </Card>
          
          {/* Data & Privacy */}
          <Card>
            <CardHeader>
              <CardTitle>Data & Privacy</CardTitle>
              <CardDescription>
                Control how your data is handled
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="history-toggle" className="flex flex-col gap-1">
                  <span>Save conversation history</span>
                  <span className="text-xs text-muted-foreground">
                    Store your conversations for future reference
                  </span>
                </Label>
                <Switch 
                  id="history-toggle"
                  checked={settings.saveConversationHistory}
                  onCheckedChange={(checked) => 
                    setSettings(prev => ({ ...prev, saveConversationHistory: checked }))
                  }
                />
              </div>
              
              <div className="flex items-center justify-between">
                <Label htmlFor="auto-save-interval" className="flex flex-col gap-1">
                  <span>Auto-save interval (minutes)</span>
                  <span className="text-xs text-muted-foreground">
                    How often to automatically save your conversations
                  </span>
                </Label>
                <Input
                  id="auto-save-interval"
                  type="number"
                  min={1}
                  max={60}
                  value={settings.autoSaveInterval}
                  onChange={(e) => 
                    setSettings(prev => ({ 
                      ...prev, 
                      autoSaveInterval: parseInt(e.target.value) || 5 
                    }))
                  }
                  className="max-w-[100px]"
                  disabled={!settings.saveConversationHistory}
                />
              </div>
              
              <div className="pt-4">
                <Button 
                  variant="destructive" 
                  size="sm"
                  onClick={() => {
                    if (confirm('Are you sure you want to clear all conversation history? This cannot be undone.')) {
                      // Clear conversation history
                      localStorage.removeItem('chat_history');
                      
                      toast({
                        title: "History cleared",
                        description: "All conversation history has been deleted",
                      });
                    }
                  }}
                >
                  <Trash className="mr-2 h-4 w-4" />
                  Clear all conversation history
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Appearance Settings */}
        <TabsContent value="appearance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>
                Customize the look and feel of the application
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Theme</Label>
                <div className="flex items-center gap-4">
                  <Button
                    variant={settings.theme === 'light' ? "default" : "outline"}
                    className="flex flex-1 flex-col items-center justify-center gap-1 h-24"
                    onClick={() => setSettings(prev => ({ ...prev, theme: 'light' }))}
                  >
                    <Sun className="h-6 w-6" />
                    <span>Light</span>
                  </Button>
                  
                  <Button
                    variant={settings.theme === 'dark' ? "default" : "outline"}
                    className="flex flex-1 flex-col items-center justify-center gap-1 h-24"
                    onClick={() => setSettings(prev => ({ ...prev, theme: 'dark' }))}
                  >
                    <Moon className="h-6 w-6" />
                    <span>Dark</span>
                  </Button>
                  
                  <Button
                    variant={settings.theme === 'system' ? "default" : "outline"}
                    className="flex flex-1 flex-col items-center justify-center gap-1 h-24"
                    onClick={() => setSettings(prev => ({ ...prev, theme: 'system' }))}
                  >
                    <Laptop className="h-6 w-6" />
                    <span>System</span>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Voice Settings */}
        <TabsContent value="voice" className="space-y-6">
          <VoiceSettings 
            settings={settings.voiceSettings}
            onSettingsChange={updateVoiceSettings}
          />
        </TabsContent>
      </Tabs>
      
      {/* Save/Reset Buttons */}
      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={resetSettings}>
          <AlertTriangle className="mr-2 h-4 w-4" />
          Reset to defaults
        </Button>
        
        <Button onClick={saveSettings}>
          <Save className="mr-2 h-4 w-4" />
          Save settings
        </Button>
      </div>
    </div>
  );
}