import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarIcon, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function DemoPage() {
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [time, setTime] = useState<string>("12:00");
  const [loading, setLoading] = useState(false);
  
  const handleCreateReminder = async () => {
    if (!title) {
      toast({
        title: "Error",
        description: "Please enter a reminder title",
        variant: "destructive",
      });
      return;
    }
    
    setLoading(true);
    
    try {
      const formattedDate = date ? format(date, 'yyyy-MM-dd') : undefined;
      
      const response = await fetch('/api/reminders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title,
          description,
          dueDate: formattedDate,
          dueTime: time,
          userId: "1" // Default user ID
        })
      });
      
      toast({
        title: "Success!",
        description: "Reminder created successfully. You'll be notified when it's due.",
        variant: "default",
      });
      
      // Reset form
      setTitle("");
      setDescription("");
      setDate(new Date());
      setTime("12:00");
    } catch (error) {
      console.error("Error creating reminder:", error);
      toast({
        title: "Error",
        description: "Failed to create reminder. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleTriggerProactiveMessage = async () => {
    // For demo purposes, this will send a test proactive message through WebSocket
    try {
      if (!window.WebSocket) {
        toast({
          title: "Error",
          description: "WebSockets are not supported in your browser.",
          variant: "destructive",
        });
        return;
      }
      
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      const ws = new WebSocket(wsUrl);
      
      ws.onopen = () => {
        // Send a test message
        ws.send(JSON.stringify({
          type: 'trigger_proactive',
          message: "Would you like me to help you organize your tasks or set up more reminders? I can also assist with 3D printing or code generation."
        }));
        
        toast({
          title: "Test Message Sent",
          description: "You should see a proactive message appear shortly.",
        });
        
        // Close the connection after sending the message
        ws.close();
      };
      
      ws.onerror = (error) => {
        console.error("WebSocket error:", error);
        toast({
          title: "Error",
          description: "Failed to connect to WebSocket server.",
          variant: "destructive",
        });
      };
    } catch (error) {
      console.error("Error triggering proactive message:", error);
      toast({
        title: "Error",
        description: "Failed to trigger proactive message.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <div className="container mx-auto py-6 max-w-2xl">
      <h1 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
        Valor AI Demo
      </h1>
      
      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Create a Reminder</CardTitle>
            <CardDescription>
              Set up a reminder and receive a proactive notification when it's due.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input 
                id="title" 
                placeholder="What do you want to be reminded about?" 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description (optional)</Label>
              <Textarea 
                id="description" 
                placeholder="Add more details about this reminder" 
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Due Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !date && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="space-y-2">
                <Label>Due Time</Label>
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <Input 
                    type="time" 
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                  />
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full"
              onClick={handleCreateReminder}
              disabled={loading}
            >
              {loading ? "Creating..." : "Create Reminder"}
            </Button>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Test Proactive Messaging</CardTitle>
            <CardDescription>
              Trigger a test message from the AI assistant to see how proactive messaging works.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              This will simulate the AI assistant initiating a conversation with you.
              In a real scenario, this would happen automatically based on your usage patterns,
              scheduled events, or other triggers.
            </p>
          </CardContent>
          <CardFooter>
            <Button
              variant="secondary"
              className="w-full"
              onClick={handleTriggerProactiveMessage}
            >
              Trigger Test Message
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}