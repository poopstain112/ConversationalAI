import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Printer, Copy, Save, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function GcodePage() {
  const { toast } = useToast();
  const [description, setDescription] = useState("");
  const [gcode, setGcode] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  
  const handleGenerate = async () => {
    if (!description) {
      toast({
        title: "Error",
        description: "Please enter a geometric description",
        variant: "destructive",
      });
      return;
    }
    
    setLoading(true);
    
    try {
      const response = await fetch('/api/gcode/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ description })
      });
      
      if (!response.ok) {
        throw new Error('Failed to generate G-code');
      }
      
      const data = await response.json();
      setGcode(data.gcode);
      
      // Set a default name based on the description
      if (!name) {
        // Extract a short name from the description
        const defaultName = description.split(' ').slice(0, 3).join('_').toLowerCase();
        setName(defaultName);
      }
      
      toast({
        title: "G-code Generated",
        description: "Your G-code has been generated successfully.",
      });
    } catch (error) {
      console.error("Error generating G-code:", error);
      toast({
        title: "Error",
        description: "Failed to generate G-code. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };
  
  const handleSave = async () => {
    if (!gcode) {
      toast({
        title: "Error",
        description: "Please generate G-code first",
        variant: "destructive",
      });
      return;
    }
    
    if (!name) {
      toast({
        title: "Error",
        description: "Please enter a name for the model",
        variant: "destructive",
      });
      return;
    }
    
    setSaving(true);
    
    try {
      const response = await fetch('/api/print-models', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name,
          description,
          gcode,
          parameters: {
            generatedAt: new Date().toISOString(),
            source: 'Valor AI G-code Generator'
          }
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to save print model');
      }
      
      toast({
        title: "Model Saved",
        description: "Your 3D print model has been saved successfully.",
      });
    } catch (error) {
      console.error("Error saving model:", error);
      toast({
        title: "Error",
        description: "Failed to save model. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };
  
  const handleCopy = async () => {
    if (!gcode) {
      toast({
        title: "Error",
        description: "Please generate G-code first",
        variant: "destructive",
      });
      return;
    }
    
    try {
      await navigator.clipboard.writeText(gcode);
      toast({
        title: "Copied!",
        description: "G-code copied to clipboard.",
      });
    } catch (error) {
      console.error("Error copying to clipboard:", error);
      toast({
        title: "Error",
        description: "Failed to copy to clipboard. Please try manually.",
        variant: "destructive",
      });
    }
  };

  const handleDownload = () => {
    if (!gcode) {
      toast({
        title: "Error",
        description: "Please generate G-code first",
        variant: "destructive",
      });
      return;
    }
    
    // Create a blob with the G-code
    const blob = new Blob([gcode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    // Create a temporary link and trigger a download
    const a = document.createElement('a');
    a.href = url;
    a.download = `${name || 'model'}.gcode`;
    document.body.appendChild(a);
    a.click();
    
    // Clean up
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Download Started",
      description: "Your G-code file is being downloaded.",
    });
  };
  
  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center gap-2 mb-4">
        <Printer className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">G-code Generator</h1>
      </div>
      
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Describe Your 3D Model</CardTitle>
            <CardDescription>
              Provide a detailed geometric description of what you want to print.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea 
              placeholder="Describe the 3D object you want to print, e.g. 'A 20mm cubic lattice structure with 2mm thick walls and 5mm spacing between struts.'"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="h-[200px] resize-none"
            />
          </CardContent>
          <CardFooter>
            <Button 
              onClick={handleGenerate}
              disabled={loading || !description}
              className="w-full"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                "Generate G-code"
              )}
            </Button>
          </CardFooter>
        </Card>
        
        {/* G-code output and save options */}
        <Card>
          <CardHeader>
            <CardTitle>G-code Output</CardTitle>
            <CardDescription>
              Review and save the generated G-code for your 3D printer.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Tabs defaultValue="gcode" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="gcode">G-code</TabsTrigger>
                <TabsTrigger value="save">Save Model</TabsTrigger>
              </TabsList>
              <TabsContent value="gcode" className="space-y-4">
                <Textarea 
                  value={gcode}
                  readOnly
                  className="h-[200px] font-mono text-sm"
                  placeholder="G-code will appear here after generation..."
                />
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    onClick={handleCopy}
                    disabled={!gcode}
                    className="flex-1"
                  >
                    <Copy className="mr-2 h-4 w-4" />
                    Copy
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={handleDownload}
                    disabled={!gcode}
                    className="flex-1"
                  >
                    <Save className="mr-2 h-4 w-4" />
                    Download
                  </Button>
                </div>
              </TabsContent>
              <TabsContent value="save" className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="model-name">Model Name</Label>
                  <Input 
                    id="model-name" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter a name for your model"
                  />
                </div>
                <Button 
                  onClick={handleSave}
                  disabled={saving || !gcode || !name}
                  className="w-full"
                >
                  {saving ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Save to Library
                    </>
                  )}
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
      
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>How G-code Generation Works</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground space-y-2">
            <p>Valor AI uses advanced AI algorithms to convert your natural language descriptions into G-code for 3D printing. Here's how it works:</p>
            <ol className="list-decimal pl-5 space-y-1">
              <li>You describe the geometric shape or object you want to print</li>
              <li>Our AI analyzes your description and identifies key parameters</li>
              <li>The system generates appropriate G-code commands for your 3D printer</li>
              <li>You can review, download, or save the G-code for future use</li>
            </ol>
            <p className="mt-2">For best results, be as specific as possible about dimensions, shapes, and features. Include measurements when relevant.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}