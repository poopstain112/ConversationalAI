import { FC, useState } from "react";
import Header from "@/components/header";
import MessageList from "@/components/chat/message-list";
import MessageForm from "@/components/chat/message-form";
import { useChat } from "@/hooks/use-chat";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const Home: FC = () => {
  const [userId] = useState("default");
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  
  const {
    conversation,
    isLoading,
    isError,
    error,
    isTyping,
    sendMessage,
    clearConversation,
  } = useChat(userId);
  
  // Handle error display
  if (isError && error && !showError) {
    setErrorMessage(error instanceof Error ? error.message : "An error occurred");
    setShowError(true);
  }
  
  return (
    <>
      <Header currentUser={userId} onClearConversation={clearConversation} />
      
      <main className="flex-1 overflow-hidden flex flex-col">
        <div className="max-w-4xl w-full mx-auto px-4 sm:px-6 lg:px-8 flex-1 flex flex-col">
          {/* Error message */}
          {showError && (
            <div className="py-4">
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{errorMessage}</AlertDescription>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-1 top-1"
                  onClick={() => setShowError(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </Alert>
            </div>
          )}
          
          {/* Messages display */}
          <MessageList
            conversation={conversation}
            isTyping={isTyping}
          />
        </div>
      </main>
      
      <MessageForm
        onSendMessage={sendMessage}
        disabled={isLoading || isTyping}
      />
    </>
  );
};

export default Home;
