import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { 
  Mic, MicOff, Camera, CameraOff, Send, Loader2, Eye, 
  ZoomIn, ZoomOut, Flashlight, ScanLine, Ruler, BrainCircuit,
  Sun, MonitorSmartphone, BellRing
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useWebSocket } from '@/hooks/use-websocket';
import { useBatterySaver } from '@/hooks/use-battery-saver';
import { useVoiceCommands } from '@/hooks/use-voice-commands';
import { useOfflineCapabilities } from '@/hooks/use-offline-capabilities';
import { ObjectDetectionOverlay, DistanceIndicator } from '@/components/vision/object-detection';
import { CameraControls } from '@/components/vision/camera-controls';
import { BarcodeScanner } from '@/components/vision/barcode-scanner';
import { MeasurementTool } from '@/components/vision/measurement-tool';
import { VisualHistory } from '@/components/vision/visual-history';
import { MultiView } from '@/components/vision/multi-view';
import { ProactiveMessage } from '@/components/proactive-ai/proactive-message';
import { apiRequest } from '@/lib/queryClient';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';

export default function VisionPage() {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isCameraOn, setIsCameraOn] = useState(false);
  const [message, setMessage] = useState('');
  const [responses, setResponses] = useState<{ role: 'assistant' | 'user', content: string, timestamp: Date }[]>([]);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  
  // Enhanced camera features
  const [cameraPermission, setCameraPermission] = useState<'granted' | 'denied' | 'prompt'>('prompt');
  const [hasFrontCamera, setHasFrontCamera] = useState(true);
  const [hasFlash, setHasFlash] = useState(false);
  const [isFlashOn, setIsFlashOn] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1.0);
  const [isMeasurementOn, setIsMeasurementOn] = useState(false);
  const [isQRScanOn, setIsQRScanOn] = useState(false);
  const [currentFacingMode, setCurrentFacingMode] = useState<'environment' | 'user'>('environment');
  const [targetObject, setTargetObject] = useState<string | undefined>();
  const [detections, setDetections] = useState<any[]>([]);
  const [estimatedDistance, setEstimatedDistance] = useState<number | null>(null);
  const [estimatedDirection, setEstimatedDirection] = useState<string | null>(null);
  
  // Advanced Features
  const [showDetectionOverlay, setShowDetectionOverlay] = useState(true);
  const [offlineMode, setOfflineMode] = useState(false);
  const [aiResponsePending, setAiResponsePending] = useState(false);
  
  // Battery optimization
  const { 
    batteryMode, 
    setBatteryMode, 
    batteryLevel, 
    isCharging, 
    isLowBattery,
    currentFrameRate
  } = useBatterySaver({
    savingModeFrameRate: 15,
    normalModeFrameRate: 30,
    lowBatteryThreshold: 20,
    autoEnableSavingMode: true
  });
  
  // Voice commands
  const { 
    isEnabled: voiceEnabled,
    isListening: voiceListening,
    toggleVoiceRecognition,
    lastCommand,
    error: voiceError
  } = useVoiceCommands({
    commands: [
      {
        phrase: "take photo",
        aliases: ["capture image", "take picture", "save view"],
        action: () => {
          if (isCameraOn) {
            toast({
              title: "Voice command detected",
              description: "Taking photo",
            });
            // TODO: Implement photo capture
          }
        }
      },
      {
        phrase: "zoom in",
        action: () => {
          if (isCameraOn && zoomLevel < 5) {
            setZoomLevel(prev => Math.min(prev + 0.5, 5));
          }
        }
      },
      {
        phrase: "zoom out",
        action: () => {
          if (isCameraOn && zoomLevel > 1) {
            setZoomLevel(prev => Math.max(prev - 0.5, 1));
          }
        }
      },
      {
        phrase: "toggle flash",
        aliases: ["turn on flash", "turn off flash", "flashlight"],
        action: () => {
          if (isCameraOn && hasFlash) {
            toggleFlash();
          }
        }
      },
      {
        phrase: "scan barcode",
        aliases: ["scan code", "read barcode", "read qr code"],
        action: () => {
          if (isCameraOn) {
            setIsQRScanOn(true);
          }
        }
      },
      {
        phrase: "measure",
        aliases: ["start measuring", "get dimensions"],
        action: () => {
          if (isCameraOn) {
            setIsMeasurementOn(true);
          }
        }
      }
    ],
    enabledByDefault: false
  });
  
  // Offline capabilities
  const {
    isOnline,
    isSyncing,
    pendingItems,
    cacheItem,
    syncNow
  } = useOfflineCapabilities();
  
  // WebSocket for proactive messaging
  const { lastMessage, isConnected: wsConnected } = useWebSocket({
    onMessage: (data) => {
      if (data.type === 'detection_result') {
        // Update detections with results from the server
        setDetections(data.detections || []);
        
        // If there's a target object, update the distance and direction
        if (targetObject && data.detections) {
          const targetDetection = data.detections.find(
            (d: any) => d.label.toLowerCase().includes(targetObject.toLowerCase())
          );
          
          if (targetDetection) {
            // Calculate distance (simplified model)
            const distance = calculateDistance(targetDetection);
            setEstimatedDistance(distance);
            
            // Determine direction
            setEstimatedDirection(getObjectDirection(targetDetection));
          } else {
            setEstimatedDistance(null);
            setEstimatedDirection(null);
          }
        }
      }
    }
  });
  
  // Check camera capabilities on mount
  useEffect(() => {
    const checkCameraCapabilities = async () => {
      try {
        // Check if we have permission already
        const permissions = await navigator.permissions.query({ name: 'camera' as any });
        setCameraPermission(permissions.state as any);
        
        // Check for available devices
        const devices = await navigator.mediaDevices.enumerateDevices();
        const cameras = devices.filter(device => device.kind === 'videoinput');
        
        // Check if there are at least 2 cameras (front and back)
        setHasFrontCamera(cameras.length >= 2);
        
        // Note: We can't reliably check for flashlight capabilities without trying to access it
        // We'll update this when the camera is actually turned on
      } catch (error) {
        console.error("Error checking camera capabilities:", error);
      }
    };
    
    checkCameraCapabilities();
  }, []);
  
  // Calculate estimated distance to object
  const calculateDistance = (detection: any): number => {
    // In a real implementation, this would use depth sensing or object size
    // Here we're doing a simple approximation based on bounding box size
    
    if (!videoRef.current) return 0;
    
    const videoWidth = videoRef.current.videoWidth;
    const videoHeight = videoRef.current.videoHeight;
    const boxArea = detection.bbox.width * detection.bbox.height;
    const screenArea = videoWidth * videoHeight;
    
    // Very rough estimate - objects taking up more of the screen are closer
    const areaRatio = boxArea / screenArea;
    const estimatedDistance = 1 / (areaRatio * 10); // Convert to a reasonable distance metric (0.5-5m)
    
    return Math.min(Math.max(estimatedDistance, 0.1), 10); // Clamp between 0.1 and 10 meters
  };
  
  // Determine object direction relative to center
  const getObjectDirection = (detection: any): string => {
    if (!videoRef.current) return 'center';
    
    const videoWidth = videoRef.current.videoWidth;
    const videoHeight = videoRef.current.videoHeight;
    
    // Calculate center of the detection
    const centerX = detection.bbox.x + detection.bbox.width / 2;
    const centerY = detection.bbox.y + detection.bbox.height / 2;
    
    // Calculate center of the screen
    const screenCenterX = videoWidth / 2;
    const screenCenterY = videoHeight / 2;
    
    // Determine primary direction
    const dx = centerX - screenCenterX;
    const dy = centerY - screenCenterY;
    
    // Create a deadzone in the center
    const deadzone = Math.min(videoWidth, videoHeight) * 0.1;
    
    if (Math.abs(dx) < deadzone && Math.abs(dy) < deadzone) {
      return 'center';
    }
    
    // Return primary direction
    if (Math.abs(dx) > Math.abs(dy)) {
      return dx > 0 ? 'right' : 'left';
    } else {
      return dy > 0 ? 'down' : 'up';
    }
  };
  
  // Handle camera toggle
  const toggleCamera = async () => {
    if (isCameraOn) {
      // Turn off camera
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
        mediaStreamRef.current = null;
      }
      setIsCameraOn(false);
      setIsFlashOn(false);
    } else {
      // Turn on camera
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            width: { ideal: 1280 },
            height: { ideal: 720 },
            facingMode: currentFacingMode,
            // @ts-ignore - Advanced camera controls that might not be supported in all browsers
            advanced: [
              { zoom: zoomLevel },
              { torch: isFlashOn }
            ]
          }
        });
        
        mediaStreamRef.current = stream;
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          
          // Try to play the video
          try {
            await videoRef.current.play();
          } catch (playError) {
            console.error("Error playing video:", playError);
          }
        }
        
        // Check if flash is available
        const videoTrack = stream.getVideoTracks()[0];
        if (videoTrack) {
          const capabilities = videoTrack.getCapabilities();
          // @ts-ignore - torch might not be recognized in all browsers
          setHasFlash(!!capabilities.torch);
        }
        
        setIsCameraOn(true);
        
        toast({
          title: "Camera activated",
          description: "The AI can now see through your camera.",
        });
        
        // Start object detection immediately
        runObjectDetection();
      } catch (error) {
        console.error("Error accessing camera:", error);
        toast({
          title: "Camera error",
          description: "Could not access your camera. Please check permissions.",
          variant: "destructive",
        });
      }
    }
  };
  
  // Switch between front and rear cameras
  const switchCamera = async () => {
    if (!isCameraOn || !hasFrontCamera) return;
    
    const newFacingMode = currentFacingMode === 'environment' ? 'user' : 'environment';
    
    // Stop current tracks
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
    }
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: newFacingMode,
          // @ts-ignore
          advanced: [
            { zoom: zoomLevel },
            { torch: isFlashOn && newFacingMode === 'environment' } // Front camera usually doesn't have flash
          ]
        }
      });
      
      mediaStreamRef.current = stream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        
        try {
          await videoRef.current.play();
        } catch (playError) {
          console.error("Error playing video:", playError);
        }
      }
      
      setCurrentFacingMode(newFacingMode);
      
      // Check if flash is available on this camera
      const videoTrack = stream.getVideoTracks()[0];
      if (videoTrack) {
        const capabilities = videoTrack.getCapabilities();
        // @ts-ignore
        setHasFlash(!!capabilities.torch);
        
        // Turn off flash when switching to front camera
        if (newFacingMode === 'user' && isFlashOn) {
          setIsFlashOn(false);
        }
      }
      
      toast({
        title: "Camera switched",
        description: `Now using ${newFacingMode === 'environment' ? 'rear' : 'front'} camera`,
      });
    } catch (error) {
      console.error("Error switching camera:", error);
      toast({
        title: "Camera error",
        description: "Could not switch cameras. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  // Toggle flash/torch
  const toggleFlash = async () => {
    if (!isCameraOn || !hasFlash) return;
    
    try {
      const videoTrack = mediaStreamRef.current?.getVideoTracks()[0];
      if (videoTrack) {
        // @ts-ignore - Torch control not in standard typings
        await videoTrack.applyConstraints({
          advanced: [{ torch: !isFlashOn }]
        });
        
        setIsFlashOn(!isFlashOn);
        
        toast({
          title: !isFlashOn ? "Flash turned on" : "Flash turned off",
          description: "Camera flash setting updated",
        });
      }
    } catch (error) {
      console.error("Error toggling flash:", error);
      toast({
        title: "Flash control error",
        description: "Could not toggle flash. This device may not support flash control.",
        variant: "destructive",
      });
    }
  };
  
  // Handle zoom changes
  const handleZoomChange = async (newZoomLevel: number) => {
    if (!isCameraOn) return;
    
    try {
      const videoTrack = mediaStreamRef.current?.getVideoTracks()[0];
      if (videoTrack) {
        // @ts-ignore - Zoom control not in standard typings
        await videoTrack.applyConstraints({
          advanced: [{ zoom: newZoomLevel }]
        });
        
        setZoomLevel(newZoomLevel);
      }
    } catch (error) {
      console.error("Error changing zoom:", error);
      // Silently fail, some devices don't support zoom control
    }
  };
  
  // Handle microphone toggle
  const toggleMicrophone = async () => {
    setIsRecording(!isRecording);
    
    if (!isRecording) {
      toast({
        title: "Microphone activated",
        description: "The AI can now hear you.",
      });
      
      // Also enable voice commands when microphone is activated
      if (!voiceEnabled) {
        toggleVoiceRecognition();
      }
    } else {
      toast({
        title: "Microphone deactivated",
        description: "The AI can no longer hear you.",
      });
      
      // Disable voice commands when microphone is deactivated
      if (voiceEnabled) {
        toggleVoiceRecognition();
      }
    }
  };
  
  // Run object detection on video frames
  const runObjectDetection = () => {
    if (!isCameraOn || !videoRef.current) return;
    
    // In a real implementation, this would send video frames to a server
    // or run detection on device using TensorFlow.js or a similar library
    
    // For this demo, we'll simulate detections
    const simulateDetection = () => {
      // Sample simulated objects
      const sampleObjects = [
        { label: 'Keyboard', confidence: 0.91 },
        { label: 'Monitor', confidence: 0.87 },
        { label: 'Coffee Mug', confidence: 0.78 },
        { label: 'Mouse', confidence: 0.85 },
        { label: 'Phone', confidence: 0.92 },
        { label: 'Book', confidence: 0.76 },
      ];
      
      // Generate 1-3 random detections
      const numDetections = Math.floor(Math.random() * 3) + 1;
      const newDetections = [];
      
      if (videoRef.current) {
        const videoWidth = videoRef.current.videoWidth || 640;
        const videoHeight = videoRef.current.videoHeight || 480;
        
        for (let i = 0; i < numDetections; i++) {
          const objectIndex = Math.floor(Math.random() * sampleObjects.length);
          const w = Math.floor(videoWidth * (0.1 + Math.random() * 0.3));
          const h = Math.floor(videoHeight * (0.1 + Math.random() * 0.3));
          const x = Math.floor(Math.random() * (videoWidth - w));
          const y = Math.floor(Math.random() * (videoHeight - h));
          
          newDetections.push({
            id: `detection-${Date.now()}-${i}`,
            ...sampleObjects[objectIndex],
            bbox: {
              x, y, width: w, height: h
            }
          });
        }
      }
      
      // Update state with new detections
      setDetections(newDetections);
      
      // If there's a target object, update the distance and direction
      if (targetObject) {
        const targetDetection = newDetections.find(
          d => d.label.toLowerCase().includes(targetObject.toLowerCase())
        );
        
        if (targetDetection) {
          const distance = calculateDistance(targetDetection);
          setEstimatedDistance(distance);
          setEstimatedDirection(getObjectDirection(targetDetection));
        } else {
          setEstimatedDistance(null);
          setEstimatedDirection(null);
        }
      }
    };
    
    // Run simulation every 500ms
    const intervalId = setInterval(simulateDetection, 500);
    
    // Cleanup
    return () => clearInterval(intervalId);
  };
  
  // Handle barcode scanning results
  const handleScanResult = (result: any) => {
    toast({
      title: `${result.type} detected`,
      description: result.data,
    });
    
    // Add scan result to conversation
    setResponses(prev => [
      ...prev, 
      {
        role: 'user',
        content: `I scanned a ${result.type}: ${result.data}`,
        timestamp: new Date()
      }
    ]);
    
    // Process with AI
    processInput(`I scanned a ${result.type} code with the text: ${result.data}. What does this mean?`);
    
    // Turn off scanner after successful scan
    setIsQRScanOn(false);
  };
  
  // Capture current frame from video
  const captureFrame = () => {
    if (videoRef.current && canvasRef.current && isCameraOn) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        // Set canvas dimensions to match video
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        
        // Draw the current video frame to the canvas
        context.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height);
        
        // Get the image data as base64
        const imageData = canvasRef.current.toDataURL('image/jpeg');
        return imageData.split(',')[1]; // Remove the data URL prefix
      }
    }
    return null;
  };
  
  // Process the user's message and image
  const processInput = async (customMessage?: string) => {
    const userMessage = customMessage || message.trim();
    
    if (!userMessage && !isCameraOn) {
      toast({
        title: "No input",
        description: "Please either type a message or enable the camera.",
        variant: "destructive",
      });
      return;
    }
    
    setIsProcessing(true);
    setAiResponsePending(true);
    
    try {
      // Capture current frame if camera is on
      const imageData = captureFrame();
      
      // Add user message to the conversation
      const inputMessage = userMessage || "What do you see?";
      setResponses(prev => [...prev, {
        role: 'user',
        content: inputMessage,
        timestamp: new Date()
      }]);
      
      // Clear the input field if not using a custom message
      if (!customMessage) {
        setMessage('');
      }
      
      // For offline mode, check connectivity
      if (!isOnline && offlineMode) {
        // Cache the request for later
        cacheItem({
          message: inputMessage,
          image: imageData,
          timestamp: new Date().toISOString()
        });
        
        // Show a local response
        setResponses(prev => [...prev, {
          role: 'assistant',
          content: "I'm currently in offline mode. Your request has been saved and will be processed when you're back online.",
          timestamp: new Date()
        }]);
        
        toast({
          title: "Offline mode active",
          description: "Your request has been saved for later processing",
        });
        
        setIsProcessing(false);
        setAiResponsePending(false);
        return;
      }
      
      // Send the message and image to the server
      const response = await fetch('/api/vision', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: inputMessage,
          image: imageData,
          timestamp: new Date().toISOString()
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to process input');
      }
      
      const data = await response.json();
      
      // Add AI response to conversation
      setResponses(prev => [...prev, {
        role: 'assistant',
        content: data.reply,
        timestamp: new Date()
      }]);
      
      // Check if user is looking for something specific
      const lookingForMatch = inputMessage.match(/where is (my|the) ([a-z\s]+)/i);
      if (lookingForMatch && lookingForMatch[2]) {
        const objectToFind = lookingForMatch[2].trim();
        setTargetObject(objectToFind);
        
        toast({
          title: "Object finder activated",
          description: `Looking for: ${objectToFind}`,
        });
      }
      
      // Speak the response if speech synthesis is available
      if (window.speechSynthesis) {
        const speech = new SpeechSynthesisUtterance(data.reply);
        speech.rate = 1.0;
        speech.pitch = 1.0;
        window.speechSynthesis.speak(speech);
      }
    } catch (error) {
      console.error("Error processing input:", error);
      
      toast({
        title: "Processing error",
        description: "Could not process your input. Please try again.",
        variant: "destructive",
      });
      
      if (offlineMode) {
        // Save the request for later if in offline mode
        cacheItem({
          message: userMessage || "What do you see?",
          image: captureFrame(),
          timestamp: new Date().toISOString()
        });
        
        // Show a local fallback response
        setResponses(prev => [...prev, {
          role: 'assistant',
          content: "I couldn't process your request right now. It has been saved for later processing when connectivity improves.",
          timestamp: new Date()
        }]);
      }
    } finally {
      setIsProcessing(false);
      setAiResponsePending(false);
    }
  };
  
  // Scan pending items when coming back online
  useEffect(() => {
    if (isOnline && pendingItems > 0 && !isSyncing) {
      toast({
        title: "Back online",
        description: `Processing ${pendingItems} pending items`,
      });
      
      syncNow();
    }
  }, [isOnline, pendingItems, isSyncing, syncNow]);
  
  // Run object detection when camera is on
  useEffect(() => {
    if (isCameraOn) {
      const cleanup = runObjectDetection();
      return cleanup;
    }
  }, [isCameraOn]);
  
  // Clean up media streams when component unmounts
  useEffect(() => {
    return () => {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);
  
  // Handle the actual message from the user (forwarded from ProactiveMessage)
  const handleProactiveResponse = (message: string) => {
    // Add the message to the regular chat and process it
    processInput(message);
  };
  
  return (
    <div className="container mx-auto pb-24 sm:pb-6">
      <div className="flex items-center gap-2 mb-4">
        <Eye className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Visual Assistant</h1>
        
        <div className="ml-auto flex items-center gap-2">
          {/* Online/Offline indicator */}
          <Badge variant={isOnline ? "default" : "destructive"} className="ml-auto">
            {isOnline ? "Online" : "Offline"}
          </Badge>
          
          {/* Battery indicator */}
          {batteryLevel !== null && (
            <Badge 
              variant={isLowBattery ? "destructive" : (isCharging ? "outline" : "secondary")} 
              className="flex items-center gap-1"
            >
              <div className="w-4 h-2 border rounded-sm relative">
                <div 
                  className={`absolute inset-y-0 left-0 ${
                    isLowBattery ? 'bg-red-500' : (isCharging ? 'bg-green-500' : 'bg-gray-500')
                  }`} 
                  style={{ width: `${batteryLevel}%` }}
                />
              </div>
              {batteryLevel}%
              {isCharging && "⚡"}
            </Badge>
          )}
          
          {/* WebSocket connection status */}
          <Badge variant={wsConnected ? "outline" : "secondary"} className="ml-auto">
            {wsConnected ? "Connected" : "Disconnected"}
          </Badge>
        </div>
      </div>
      
      <div className="grid gap-6 md:grid-cols-2">
        {/* Video feed and controls */}
        <Card className="col-span-2 md:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle>Visual Input</CardTitle>
            <CardDescription>
              Enable your camera so the AI can see through your smart glasses.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center space-y-4">
            <div className="relative w-full aspect-video bg-muted rounded-md overflow-hidden">
              {isCameraOn ? (
                <>
                  <video 
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />
                  
                  {/* Object detection overlay */}
                  {showDetectionOverlay && (
                    <ObjectDetectionOverlay
                      videoRef={videoRef}
                      detections={detections}
                      targetObject={targetObject}
                      showOverlay={true}
                    />
                  )}
                  
                  {/* Distance indicator */}
                  {estimatedDistance !== null && (
                    <DistanceIndicator
                      distance={estimatedDistance}
                      direction={estimatedDirection}
                    />
                  )}
                  
                  {/* Barcode scanner */}
                  {isQRScanOn && (
                    <BarcodeScanner
                      videoRef={videoRef}
                      isActive={isCameraOn && isQRScanOn}
                      onScanResult={handleScanResult}
                    />
                  )}
                  
                  {/* Measurement tool */}
                  {isMeasurementOn && (
                    <MeasurementTool
                      videoRef={videoRef}
                      isActive={isCameraOn && isMeasurementOn}
                    />
                  )}
                </>
              ) : (
                <div className="flex items-center justify-center w-full h-full text-muted-foreground">
                  <p>Camera is off</p>
                </div>
              )}
            </div>
            
            {/* Hidden canvas for frame capture */}
            <canvas ref={canvasRef} className="hidden" />
            
            {/* Enhanced camera controls */}
            {isCameraOn && (
              <CameraControls
                onToggleCamera={toggleCamera}
                onSwitchCamera={switchCamera}
                onToggleFlash={toggleFlash}
                onZoomChange={handleZoomChange}
                onToggleMeasurement={() => setIsMeasurementOn(!isMeasurementOn)}
                onToggleQRScan={() => setIsQRScanOn(!isQRScanOn)}
                isCameraOn={isCameraOn}
                isFlashOn={isFlashOn}
                zoomLevel={zoomLevel}
                isMeasurementOn={isMeasurementOn}
                isQRScanOn={isQRScanOn}
                hasFrontCamera={hasFrontCamera}
                hasFlash={hasFlash}
                batteryMode={batteryMode}
                onBatteryModeChange={(mode) => setBatteryMode(mode)}
              />
            )}
            
            {/* Main camera toggle */}
            {!isCameraOn && (
              <Button 
                onClick={toggleCamera}
                variant="default"
                className="w-full"
              >
                <Camera className="mr-2 h-4 w-4" />
                Start Camera
              </Button>
            )}
            
            {/* Additional settings */}
            <div className="w-full border-t pt-3 flex flex-col gap-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="voice-toggle" className="flex items-center gap-2">
                  <Mic className="h-4 w-4 text-muted-foreground" />
                  Voice Commands
                </Label>
                <Switch 
                  id="voice-toggle" 
                  checked={voiceEnabled}
                  onCheckedChange={toggleVoiceRecognition}
                />
              </div>
              
              <div className="flex justify-between items-center">
                <Label htmlFor="offline-toggle" className="flex items-center gap-2">
                  <Sun className="h-4 w-4 text-muted-foreground" />
                  Offline Mode
                </Label>
                <Switch 
                  id="offline-toggle" 
                  checked={offlineMode}
                  onCheckedChange={setOfflineMode}
                />
              </div>
              
              {voiceEnabled && (
                <p className="text-xs text-muted-foreground">
                  {voiceListening 
                    ? "Listening for commands: 'take photo', 'zoom in/out', 'toggle flash', 'scan barcode', 'measure'" 
                    : "Voice commands enabled but not active"}
                </p>
              )}
              
              {lastCommand && (
                <p className="text-xs px-2 py-1 bg-muted rounded-md">
                  Last command: "{lastCommand}"
                </p>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Chat interface */}
        <Card className="col-span-2 md:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle>Communication</CardTitle>
            <CardDescription>
              Interact with the AI using your camera, microphone, or text.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="h-[400px] overflow-y-auto space-y-4 p-4 border rounded-md">
              {responses.length === 0 ? (
                <div className="text-center text-muted-foreground py-8">
                  <p>Your conversation will appear here</p>
                  <p className="text-sm mt-1">Enable the camera to let the AI see through your smart glasses</p>
                </div>
              ) : (
                responses.map((msg, index) => (
                  <div 
                    key={index} 
                    className={`flex flex-col ${msg.role === 'assistant' ? 'items-start' : 'items-end'}`}
                  >
                    <div 
                      className={`rounded-lg px-4 py-2 max-w-[85%] ${
                        msg.role === 'assistant' 
                          ? 'bg-primary/10 text-foreground' 
                          : 'bg-primary text-primary-foreground'
                      }`}
                    >
                      {msg.content}
                    </div>
                    <span className="text-xs text-muted-foreground mt-1">
                      {msg.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                ))
              )}
              
              {aiResponsePending && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>AI is thinking...</span>
                </div>
              )}
            </div>
            
            <div className="flex gap-2">
              <Textarea 
                placeholder="Type a message or enable camera to let the AI see..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    processInput();
                  }
                }}
                className="flex-1"
              />
              <Button 
                onClick={() => processInput()}
                disabled={isProcessing}
                size="icon"
                className="h-auto"
              >
                {isProcessing ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </div>
            
            {/* Voice command trigger */}
            <Button 
              variant="outline" 
              className="w-full flex items-center justify-center gap-2"
              onClick={toggleMicrophone}
              disabled={!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia}
            >
              {isRecording ? (
                <>
                  <MicOff className="h-4 w-4" />
                  Stop Voice Input
                </>
              ) : (
                <>
                  <Mic className="h-4 w-4" />
                  Start Voice Input
                </>
              )}
            </Button>
            
            {/* Object finding helper */}
            {isCameraOn && (
              <div className="flex items-center gap-2">
                <Input 
                  placeholder="What object are you looking for?" 
                  value={targetObject || ''}
                  onChange={(e) => setTargetObject(e.target.value || undefined)}
                  className="flex-1"
                />
                <Button
                  variant={targetObject ? "default" : "outline"}
                  onClick={() => {
                    if (targetObject) {
                      setTargetObject(undefined);
                      setEstimatedDistance(null);
                      setEstimatedDirection(null);
                    }
                  }}
                >
                  {targetObject ? "Stop Finding" : "Find Object"}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Help card */}
      <Card className="mt-6">
        <CardHeader className="pb-2">
          <CardTitle>How to Use the Visual Assistant</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground space-y-2">
            <p>This visual assistant connects to your smart glasses so Valor AI can see what you see and guide you in real-time. Here's how to use it:</p>
            <ol className="list-decimal pl-5 space-y-1">
              <li>Start the camera to transmit your view to the AI</li>
              <li>Use the microphone for audio communication or type your questions</li>
              <li>Use enhanced features like measurement tools, QR scanning, and object recognition</li>
              <li>Say "find my [object]" to activate object finding</li>
              <li>Enable battery saving mode for extended sessions</li>
              <li>Use offline mode when you have intermittent connectivity</li>
            </ol>
            <p className="mt-2">Voice commands like "zoom in", "zoom out", "take photo", "scan barcode", and "measure" work when voice commands are enabled.</p>
          </div>
        </CardContent>
      </Card>
      
      {/* Visual history, Multi-view and Proactive message components */}
      {isCameraOn && <VisualHistory videoRef={videoRef} canvasRef={canvasRef} isActive={isCameraOn} />}
      {isCameraOn && <MultiView primaryVideoRef={videoRef} onSecondaryConnect={() => {}} onSecondaryDisconnect={() => {}} />}
      <ProactiveMessage onSendMessage={handleProactiveResponse} />
    </div>
  );
}