import React, { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';


interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface Conversation {
  userId: string;
  messages: Message[];
}

const Valor = () => {
  const queryClient = useQueryClient();
  const [userInput, setUserInput] = useState('');
  const [userId] = useState('default');
  const [imageData, setImageData] = useState<string | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [showGcodeModal, setShowGcodeModal] = useState(false);
  const [gcodeDescription, setGcodeDescription] = useState('');
  const [generatedGcode, setGeneratedGcode] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);

  // Fetch conversation history
  const { data: conversation, isLoading } = useQuery<Conversation>({
    queryKey: [`/api/conversation/${userId}`],
    refetchOnWindowFocus: false,
  });

  // Send message mutation
  const sendMessage = useMutation({
    mutationFn: async (message: string) => {
      const response = await fetch('/api/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, userId })
      });
      
      if (!response.ok) {
        throw new Error('Failed to send message');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/conversation/${userId}`] });
      setUserInput('');
    },
  });

  // Clear conversation mutation
  const clearConversation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/conversation/${userId}/clear`, {
        method: 'POST'
      });
      
      if (!response.ok) {
        throw new Error('Failed to clear conversation');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/conversation/${userId}`] });
    },
  });

  // Vision analysis mutation
  const analyzeImage = useMutation({
    mutationFn: async (image: string) => {
      const response = await fetch('/api/vision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image })
      });
      
      if (!response.ok) {
        throw new Error('Failed to analyze image');
      }
      
      return response.json();
    },
    onSuccess: (data: any) => {
      if (data && data.description) {
        // After receiving the analysis, send it as a message
        sendMessage.mutate(`Image analysis: ${data.description}`);
      }
      setShowCamera(false);
      stopCamera();
    },
  });

  // G-code generation mutation
  const generateGcode = useMutation({
    mutationFn: async (description: string) => {
      // In a real implementation, you would have a dedicated endpoint
      const response = await fetch('/api/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: `Generate G-code for: ${description}`, 
          userId 
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to generate G-code');
      }
      
      return response.json();
    },
    onSuccess: (data: any) => {
      if (data && data.message) {
        setGeneratedGcode(data.message);
        queryClient.invalidateQueries({ queryKey: [`/api/conversation/${userId}`] });
      }
      setShowGcodeModal(false);
    },
  });

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userInput.trim()) {
      sendMessage.mutate(userInput);
    }
  };

  // Camera functions
  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      console.error('Error accessing camera:', err);
      alert('Could not access the camera');
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setImageData(null);
  };

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height);
        const imgData = canvasRef.current.toDataURL('image/jpeg').split(',')[1];
        setImageData(imgData);
      }
    }
  };

  const submitImage = () => {
    if (imageData) {
      analyzeImage.mutate(imageData);
    }
  };

  const submitGcodeRequest = () => {
    if (gcodeDescription.trim()) {
      generateGcode.mutate(gcodeDescription);
    }
  };

  const copyGcodeToClipboard = () => {
    navigator.clipboard.writeText(generatedGcode)
      .then(() => alert('G-code copied to clipboard'))
      .catch(err => console.error('Failed to copy: ', err));
  };

  const downloadGcode = () => {
    const blob = new Blob([generatedGcode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `valor_gcode_${Date.now()}.gcode`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  useEffect(() => {
    if (showCamera) {
      startCamera();
    } else {
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [showCamera]);

  // Format code blocks in message content
  const formatMessageContent = (content: string) => {
    // Split by code block markers
    const parts = content.split(/(```[\s\S]*?```)/g);
    
    return parts.map((part, index) => {
      if (part.startsWith('```') && part.endsWith('```')) {
        // Process code block
        const code = part.slice(3, -3);
        const languageMatch = code.match(/^([a-z]+)\n/);
        const language = languageMatch ? languageMatch[1] : '';
        const codeContent = languageMatch ? code.slice(language.length + 1) : code;
        
        return (
          <pre key={index} className="bg-slate-800 p-4 rounded overflow-x-auto">
            <code className={`language-${language}`}>
              {codeContent}
            </code>
          </pre>
        );
      } else {
        // Regular text - split by newlines to preserve line breaks
        return (
          <span key={index}>
            {part.split('\n').map((line, i) => (
              <React.Fragment key={i}>
                {line}
                {i < part.split('\n').length - 1 && <br />}
              </React.Fragment>
            ))}
          </span>
        );
      }
    });
  };

  if (isLoading) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }

  return (
    <div className="flex flex-col h-screen bg-slate-900">
      {/* Header */}
      <header className="bg-slate-800 p-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-cyan-400 bg-clip-text text-transparent">
          Valor AI
        </h1>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => clearConversation.mutate()}
          >
            Clear Chat
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setShowCamera(true)}
          >
            Camera
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setShowGcodeModal(true)}
          >
            G-Code
          </Button>
        </div>
      </header>

      {/* Chat messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {conversation?.messages.map((message, index) => (
          <div key={index} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div 
              className={`max-w-3/4 p-3 rounded-lg ${
                message.role === 'user' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-slate-700 text-slate-100'
              }`}
            >
              {formatMessageContent(message.content)}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input area */}
      <form onSubmit={handleSubmit} className="p-4 bg-slate-800 border-t border-slate-700">
        <div className="flex space-x-2">
          <Textarea
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            placeholder="Send a message to Valor..."
            className="flex-1 bg-slate-700"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit(e);
              }
            }}
          />
          <Button type="submit" disabled={sendMessage.isPending}>
            {sendMessage.isPending ? 'Sending...' : 'Send'}
          </Button>
        </div>
      </form>

      {/* Camera Modal */}
      {showCamera && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <Card className="w-full max-w-md bg-slate-800 border-slate-700">
            <div className="p-4 border-b border-slate-700 flex justify-between">
              <h2 className="text-xl font-semibold">Camera</h2>
              <button 
                onClick={() => setShowCamera(false)}
                className="text-slate-400 hover:text-slate-100"
              >
                ×
              </button>
            </div>
            <div className="p-4 space-y-4">
              <div className="bg-black rounded-lg overflow-hidden">
                <video 
                  ref={videoRef} 
                  autoPlay 
                  playsInline 
                  className="w-full h-64 object-cover"
                />
              </div>
              <canvas ref={canvasRef} className="hidden" />
              
              <div className="flex justify-between space-x-2">
                <Button onClick={captureImage} className="flex-1">
                  Capture
                </Button>
                <Button 
                  onClick={submitImage} 
                  className="flex-1"
                  disabled={!imageData || analyzeImage.isPending}
                >
                  {analyzeImage.isPending ? 'Analyzing...' : 'Analyze'}
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* G-code Modal */}
      {showGcodeModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <Card className="w-full max-w-md bg-slate-800 border-slate-700">
            <div className="p-4 border-b border-slate-700 flex justify-between">
              <h2 className="text-xl font-semibold">Generate 3D Print G-Code</h2>
              <button 
                onClick={() => setShowGcodeModal(false)}
                className="text-slate-400 hover:text-slate-100"
              >
                ×
              </button>
            </div>
            <div className="p-4 space-y-4">
              <p className="text-slate-300">
                Describe what you want to create and Valor will generate G-code for your 3D printer:
              </p>
              <Textarea
                value={gcodeDescription}
                onChange={(e) => setGcodeDescription(e.target.value)}
                placeholder="Example: A simple cylinder with 20mm diameter and 30mm height"
                className="w-full bg-slate-700"
                rows={4}
              />
              <Button 
                onClick={submitGcodeRequest} 
                className="w-full"
                disabled={generateGcode.isPending}
              >
                {generateGcode.isPending ? 'Generating...' : 'Generate G-Code'}
              </Button>

              {generatedGcode && (
                <div className="mt-4 space-y-3">
                  <h3 className="font-semibold">Generated G-Code:</h3>
                  <pre className="bg-slate-900 p-3 rounded-md overflow-x-auto text-sm max-h-40">
                    {generatedGcode}
                  </pre>
                  <div className="flex space-x-2">
                    <Button 
                      onClick={copyGcodeToClipboard} 
                      variant="outline" 
                      className="flex-1"
                    >
                      Copy to Clipboard
                    </Button>
                    <Button 
                      onClick={downloadGcode} 
                      variant="outline" 
                      className="flex-1"
                    >
                      Download
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default Valor;