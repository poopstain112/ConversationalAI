import { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AlertCircle, Camera, Upload } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

type AnalysisResult = {
  description: string;
  timestamp: Date;
};

export default function ValorVision() {
  const [isCapturing, setIsCapturing] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    return () => {
      // Clean up when component unmounts
      if (isCapturing) {
        stopCamera();
      }
    };
  }, [isCapturing]);

  const startCamera = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCapturing(true);
      }
    } catch (err) {
      console.error('Error accessing camera:', err);
      setError('Could not access camera. Please check permissions and try again.');
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setIsCapturing(false);
    }
  };

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      if (context) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        const imageDataUrl = canvas.toDataURL('image/jpeg');
        setCapturedImage(imageDataUrl);
        stopCamera();
      }
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.match('image.*')) {
      setError('Please select an image file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      setCapturedImage(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const analyzeImage = async () => {
    if (!capturedImage) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      // Convert base64 data URL to binary
      const base64Data = capturedImage.split(',')[1];
      
      const response = await fetch('/api/vision', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ image: base64Data }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to analyze image');
      }
      
      const data = await response.json();
      
      setAnalysis(prev => [
        ...prev, 
        { 
          description: data.description,
          timestamp: new Date()
        }
      ]);
    } catch (err) {
      console.error('Error analyzing image:', err);
      setError('Failed to analyze the image. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const resetAll = () => {
    setCapturedImage(null);
    setError(null);
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const formatTimestamp = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-950">
      <header className="p-4 border-b border-gray-800 bg-gradient-to-r from-slate-900 to-slate-800">
        <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
          Valor Vision
        </h1>
      </header>

      <main className="flex-1 p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="bg-slate-900 border-gray-800">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4 text-slate-200">Camera Input</h2>
              
              {error && (
                <Alert variant="destructive" className="mb-4 bg-red-900 border-red-800">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <div className="relative bg-slate-800 rounded-md overflow-hidden aspect-video mb-4">
                {isCapturing ? (
                  <video 
                    ref={videoRef} 
                    autoPlay 
                    playsInline
                    className="w-full h-full object-cover"
                  />
                ) : capturedImage ? (
                  <img 
                    src={capturedImage} 
                    alt="Captured" 
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <Camera className="h-20 w-20 text-slate-600" />
                  </div>
                )}
                
                <canvas ref={canvasRef} className="hidden" />
              </div>
              
              <div className="flex flex-wrap gap-2">
                {!isCapturing && !capturedImage && (
                  <>
                    <Button 
                      onClick={startCamera}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <Camera className="mr-2 h-4 w-4" /> Start Camera
                    </Button>
                    
                    <Button 
                      onClick={triggerFileInput}
                      variant="outline"
                      className="border-slate-700 hover:bg-slate-800"
                    >
                      <Upload className="mr-2 h-4 w-4" /> Upload Image
                    </Button>
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileUpload}
                      accept="image/*"
                      className="hidden"
                    />
                  </>
                )}
                
                {isCapturing && (
                  <>
                    <Button 
                      onClick={captureImage}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Take Photo
                    </Button>
                    
                    <Button 
                      onClick={stopCamera}
                      variant="outline"
                      className="border-slate-700 hover:bg-slate-800"
                    >
                      Cancel
                    </Button>
                  </>
                )}
                
                {capturedImage && (
                  <>
                    <Button 
                      onClick={analyzeImage}
                      className="bg-purple-600 hover:bg-purple-700"
                      disabled={isLoading}
                    >
                      {isLoading ? 'Analyzing...' : 'Analyze Image'}
                    </Button>
                    
                    <Button 
                      onClick={resetAll}
                      variant="outline"
                      className="border-slate-700 hover:bg-slate-800"
                    >
                      Reset
                    </Button>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-900 border-gray-800">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4 text-slate-200">Analysis Results</h2>
              
              <ScrollArea className="h-[500px] pr-4">
                {analysis.length === 0 ? (
                  <div className="text-center py-12 text-slate-500">
                    <p>No analysis results yet.</p>
                    <p className="text-sm mt-2">Capture or upload an image and click "Analyze Image".</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {analysis.map((result, index) => (
                      <div key={index} className="bg-slate-800 p-4 rounded-lg">
                        <div className="text-xs text-slate-500 mb-1">
                          {formatTimestamp(result.timestamp)}
                        </div>
                        <p className="text-slate-200">{result.description}</p>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}