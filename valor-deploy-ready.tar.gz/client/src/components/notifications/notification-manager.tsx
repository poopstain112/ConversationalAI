import React, { useState, useEffect } from 'react';
import { NotificationToast, NotificationType } from './notification-toast';
import { useWebSocket } from '@/hooks/use-websocket';

type Notification = {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  autoClose?: boolean;
  duration?: number;
  action?: React.ReactNode;
};

export function NotificationManager() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  
  // WebSocket connection for real-time notifications
  const { lastMessage } = useWebSocket({
    onMessage: (data) => {
      if (data && typeof data === 'object' && data.type === 'notification') {
        addNotification({
          id: `notification-${Date.now()}`,
          type: data.notificationType || 'info',
          title: data.title || 'Notification',
          message: data.message || '',
          autoClose: data.autoClose !== false,
          duration: data.duration || 6000,
        });
      }
    },
  });

  const addNotification = (notification: Notification) => {
    setNotifications(prev => [...prev, notification]);
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(notification => notification.id !== id));
  };

  // For testing purposes - add a notification when component mounts
  useEffect(() => {
    // Uncomment for testing
    /*
    setTimeout(() => {
      addNotification({
        id: `notification-${Date.now()}`,
        type: 'ai',
        title: 'Valor AI',
        message: 'I just wanted to check in. How can I assist you today?',
        autoClose: true,
        duration: 8000,
      });
    }, 3000);
    */
  }, []);

  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col gap-2">
      {notifications.map(notification => (
        <NotificationToast
          key={notification.id}
          id={notification.id}
          type={notification.type}
          title={notification.title}
          message={notification.message}
          autoClose={notification.autoClose}
          duration={notification.duration}
          onClose={removeNotification}
          action={notification.action}
        />
      ))}
    </div>
  );
}