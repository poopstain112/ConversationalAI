import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BellRing, X, Info, BrainCircuit, AlertCircle, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

export type NotificationType = 'info' | 'ai' | 'alert' | 'success';

interface NotificationProps {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  autoClose?: boolean;
  duration?: number;
  onClose: (id: string) => void;
  action?: React.ReactNode;
}

export const NotificationToast: React.FC<NotificationProps> = ({
  id,
  type = 'info',
  title,
  message,
  autoClose = true,
  duration = 6000, // 6 seconds by default
  onClose,
  action
}) => {
  const [isVisible, setIsVisible] = useState(true);
  
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (autoClose) {
      timer = setTimeout(() => {
        setIsVisible(false);
      }, duration);
    }
    
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [autoClose, duration]);
  
  const handleClose = () => {
    setIsVisible(false);
  };
  
  const handleAnimationComplete = () => {
    if (!isVisible) {
      onClose(id);
    }
  };
  
  const getIcon = () => {
    switch (type) {
      case 'ai':
        return <BrainCircuit className="h-5 w-5 text-primary" />;
      case 'alert':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'info':
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };
  
  const getBorderColor = () => {
    switch (type) {
      case 'ai':
        return 'border-primary';
      case 'alert':
        return 'border-red-500';
      case 'success':
        return 'border-green-500';
      case 'info':
      default:
        return 'border-blue-500';
    }
  };
  
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          onAnimationComplete={handleAnimationComplete}
          className={`bg-card border ${getBorderColor()} border-l-4 shadow-lg rounded-lg overflow-hidden max-w-sm w-full`}
        >
          <div className="p-4">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-0.5">
                {getIcon()}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-start">
                  <h3 className="font-medium text-foreground">{title}</h3>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 -mt-1 -mr-1 text-muted-foreground hover:text-foreground"
                    onClick={handleClose}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                
                <p className="text-sm text-muted-foreground mt-1">{message}</p>
                
                {action && (
                  <div className="mt-3">
                    {action}
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* Progress bar for auto-close */}
          {autoClose && (
            <motion.div
              initial={{ width: '100%' }}
              animate={{ width: 0 }}
              transition={{ duration: duration / 1000, ease: 'linear' }}
              className="h-1 bg-primary/20"
            />
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
};