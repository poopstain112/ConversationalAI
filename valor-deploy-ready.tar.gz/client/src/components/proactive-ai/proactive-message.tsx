import React, { useState, useEffect } from 'react';
import { useWebSocket } from '@/hooks/use-websocket';
import { useToast } from '@/hooks/use-toast';
import { AnimatePresence, motion } from 'framer-motion';
import { BrainCircuit, X, MessageSquareDashed, BellRing } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

interface ProactiveMessageProps {
  onSendMessage: (message: string) => void;
  userId?: string;
}

export const ProactiveMessage: React.FC<ProactiveMessageProps> = ({
  onSendMessage,
  userId = 'default'
}) => {
  const { toast } = useToast();
  const [showNotification, setShowNotification] = useState(false);
  const [proactiveMessage, setProactiveMessage] = useState<string>('');
  const [userReply, setUserReply] = useState('');
  const [notificationCount, setNotificationCount] = useState(0);
  const [lastSeenTimestamp, setLastSeenTimestamp] = useState(Date.now());
  
  // Connect to the WebSocket to listen for proactive messages
  const { lastMessage, isConnected, status } = useWebSocket({
    onMessage: (data) => {
      // Handle proactive messages
      if (data.type === 'proactive') {
        // Don't show notifications for messages we've seen before
        if (data.timestamp && data.timestamp <= lastSeenTimestamp) {
          return;
        }
        
        setProactiveMessage(data.message);
        setNotificationCount(prev => prev + 1);
        
        // Show notification
        if (!showNotification) {
          playNotificationSound();
          setShowNotification(true);
        }
        
        // Show toast notification
        toast({
          title: "Valor has something to share",
          description: data.message.length > 60 ? `${data.message.substring(0, 57)}...` : data.message,
          action: (
            <Button variant="outline" size="sm" onClick={() => setShowNotification(true)}>
              View
            </Button>
          )
        });
      }
    }
  });

  // Play notification sound when there's a new proactive message
  const playNotificationSound = () => {
    try {
      const audio = new Audio('/notification.mp3');
      audio.volume = 0.5;
      audio.play().catch(e => console.log('Error playing notification sound:', e));
    } catch (error) {
      console.error('Failed to play notification sound:', error);
    }
  };
  
  // Handle user submitting a response to the proactive message
  const handleSubmitReply = () => {
    if (!userReply.trim()) return;
    
    // Send the user's reply
    onSendMessage(userReply);
    
    // Close the notification
    setShowNotification(false);
    setNotificationCount(0);
    setLastSeenTimestamp(Date.now());
    setUserReply('');
  };
  
  // Dismiss the notification
  const handleDismiss = () => {
    setShowNotification(false);
    setNotificationCount(0);
    setLastSeenTimestamp(Date.now());
  };
  
  // Reset notification when closed
  useEffect(() => {
    if (!showNotification) {
      setTimeout(() => {
        setProactiveMessage('');
      }, 500);
    }
  }, [showNotification]);
  
  // Demo function - in a real app, this would be triggered by the server
  const demoTriggerProactiveMessage = () => {
    setProactiveMessage("I noticed you haven't interacted in a while. How about we review what you've learned today?");
    setNotificationCount(prev => prev + 1);
    setShowNotification(true);
    playNotificationSound();
  };
  
  return (
    <>
      {/* Notification indicator */}
      {notificationCount > 0 && !showNotification && (
        <div 
          className="fixed bottom-6 right-6 z-50 cursor-pointer" 
          onClick={() => setShowNotification(true)}
        >
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
            className="relative"
          >
            <div className="bg-primary text-white p-3 rounded-full shadow-lg flex items-center justify-center">
              <BellRing className="h-6 w-6" />
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                {notificationCount}
              </span>
            </div>
          </motion.div>
        </div>
      )}
      
      {/* Full proactive message display */}
      <AnimatePresence>
        {showNotification && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            transition={{ type: "spring", stiffness: 400, damping: 40 }}
            className="fixed inset-0 flex items-center justify-center p-4 bg-black/40 z-50"
            onClick={handleDismiss}
          >
            <motion.div 
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="bg-card border max-w-lg w-full rounded-lg shadow-lg overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="px-4 py-3 border-b flex justify-between items-center bg-muted/50">
                <div className="flex items-center gap-2">
                  <BrainCircuit className="h-5 w-5 text-primary" />
                  <h3 className="font-medium">Valor has something to share</h3>
                </div>
                <Button variant="ghost" size="icon" onClick={handleDismiss}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              {/* Message content */}
              <div className="p-4">
                <div className="flex gap-3 mb-4">
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                    <BrainCircuit className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div className="bg-muted p-3 rounded-lg">
                    <p>{proactiveMessage}</p>
                  </div>
                </div>
                
                {/* User reply */}
                <div className="flex flex-col gap-2">
                  <Textarea
                    placeholder="Type your reply..."
                    className="min-h-20"
                    value={userReply}
                    onChange={(e) => setUserReply(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSubmitReply();
                      }
                    }}
                  />
                  
                  <div className="flex justify-between">
                    <Button 
                      variant="ghost" 
                      onClick={handleDismiss}
                    >
                      Dismiss
                    </Button>
                    <Button 
                      onClick={handleSubmitReply}
                      disabled={!userReply.trim()}
                    >
                      <MessageSquareDashed className="h-4 w-4 mr-2" />
                      Reply
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};