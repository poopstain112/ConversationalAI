import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Camera, Trash2, Download, Share2, BookmarkPlus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface HistoryItem {
  id: string;
  timestamp: number;
  imageData: string;
  label: string;
  annotation: string;
}

interface VisualHistoryProps {
  videoRef: React.RefObject<HTMLVideoElement>;
  canvasRef: React.RefObject<HTMLCanvasElement>;
  isActive: boolean;
  onCapture?: (item: HistoryItem) => void;
}

export const VisualHistory: React.FC<VisualHistoryProps> = ({
  videoRef,
  canvasRef,
  isActive,
  onCapture
}) => {
  const { toast } = useToast();
  const [historyItems, setHistoryItems] = useState<HistoryItem[]>([]);
  const [isExpanded, setIsExpanded] = useState(false);
  const [newItemLabel, setNewItemLabel] = useState('');
  const [selectedItem, setSelectedItem] = useState<HistoryItem | null>(null);
  
  // Load saved items from localStorage on mount
  useEffect(() => {
    const savedItems = localStorage.getItem('visionHistory');
    if (savedItems) {
      try {
        const parsed = JSON.parse(savedItems);
        setHistoryItems(parsed);
      } catch (e) {
        console.error('Error loading visual history:', e);
      }
    }
  }, []);
  
  // Save to localStorage when items change
  useEffect(() => {
    localStorage.setItem('visionHistory', JSON.stringify(historyItems));
  }, [historyItems]);
  
  // Capture current frame
  const captureFrame = () => {
    if (!videoRef.current || !canvasRef.current) {
      toast({
        title: "Capture failed",
        description: "Camera or canvas not available",
        variant: "destructive",
      });
      return;
    }
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    // Create a new canvas for the snapshot to avoid capturing UI elements
    const snapshotCanvas = document.createElement('canvas');
    snapshotCanvas.width = video.videoWidth;
    snapshotCanvas.height = video.videoHeight;
    
    const ctx = snapshotCanvas.getContext('2d');
    if (!ctx) return;
    
    // Draw the video frame
    ctx.drawImage(video, 0, 0, snapshotCanvas.width, snapshotCanvas.height);
    
    // Copy any annotations from the overlay canvas
    if (canvas) {
      try {
        ctx.drawImage(canvas, 0, 0, snapshotCanvas.width, snapshotCanvas.height);
      } catch (e) {
        console.error('Error copying annotations:', e);
      }
    }
    
    // Convert to data URL
    const imageData = snapshotCanvas.toDataURL('image/jpeg', 0.85);
    
    // Generate a unique ID
    const id = `history_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    
    // Create history item
    const newItem: HistoryItem = {
      id,
      timestamp: Date.now(),
      imageData,
      label: newItemLabel || `Capture ${historyItems.length + 1}`,
      annotation: 'AI analysis pending...' // This would be filled by AI in a real implementation
    };
    
    // Add to history
    setHistoryItems(prev => [newItem, ...prev]);
    
    // Notify parent
    if (onCapture) {
      onCapture(newItem);
    }
    
    // Show success toast
    toast({
      title: "Snapshot saved",
      description: "Image saved to visual history",
    });
    
    // Reset label
    setNewItemLabel('');
    
    // Get AI annotation for this image
    getAIAnnotation(imageData, id);
  };
  
  // Get AI annotation for the captured image
  const getAIAnnotation = async (imageData: string, itemId: string) => {
    try {
      // Extract base64 data (remove data URL prefix)
      const base64Image = imageData.split(',')[1];
      
      // Call the vision API to analyze the image
      const response = await fetch('/api/vision', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          image: base64Image,
          message: "Describe what you see in this image concisely",
          timestamp: new Date().toISOString()
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to get AI annotation');
      }
      
      const data = await response.json();
      
      // Update the item with AI annotation
      setHistoryItems(prev => prev.map(item => 
        item.id === itemId 
          ? { ...item, annotation: data.reply } 
          : item
      ));
    } catch (error) {
      console.error('Error getting AI annotation:', error);
      
      // Mark as failed
      setHistoryItems(prev => prev.map(item => 
        item.id === itemId 
          ? { ...item, annotation: 'Failed to analyze image' } 
          : item
      ));
      
      toast({
        title: "Analysis failed",
        description: "Could not get AI description for the image",
        variant: "destructive",
      });
    }
  };
  
  // Delete a history item
  const deleteItem = (id: string) => {
    setHistoryItems(prev => prev.filter(item => item.id !== id));
    
    if (selectedItem?.id === id) {
      setSelectedItem(null);
    }
    
    toast({
      title: "Item deleted",
      description: "Visual history item has been removed",
    });
  };
  
  // Download a history item as an image
  const downloadItem = (item: HistoryItem) => {
    const a = document.createElement('a');
    a.href = item.imageData;
    a.download = `${item.label.replace(/\s+/g, '_')}_${new Date(item.timestamp).toISOString().split('T')[0]}.jpg`;
    a.click();
  };
  
  // Format timestamp
  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };
  
  if (!isActive) return null;
  
  return (
    <div className={`fixed ${isExpanded ? 'inset-0 bg-black/50 z-50' : 'bottom-4 right-4 z-40'} 
      transition-all duration-300 ease-in-out`}>
      
      {/* Collapsed state - just show the button */}
      {!isExpanded && (
        <Button
          variant="secondary"
          size="sm"
          className="relative flex items-center gap-2 shadow-lg"
          onClick={() => setIsExpanded(true)}
        >
          {historyItems.length > 0 && (
            <span className="absolute -top-2 -right-2 bg-red-500 text-white w-5 h-5 rounded-full flex items-center justify-center text-xs">
              {historyItems.length}
            </span>
          )}
          <Camera className="h-4 w-4" />
          History
        </Button>
      )}
      
      {/* Expanded state - show the full history panel */}
      {isExpanded && (
        <div className="fixed inset-0 flex items-center justify-center p-4" onClick={() => setIsExpanded(false)}>
          <Card 
            className="w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col" 
            onClick={(e) => e.stopPropagation()}
          >
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle>Visual History</CardTitle>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setIsExpanded(false)}
                >
                  Close
                </Button>
              </div>
              <CardDescription>
                Save and review frames with AI annotations
              </CardDescription>
            </CardHeader>
            
            <CardContent className="flex-1 overflow-hidden flex flex-col">
              {/* Capture new item */}
              <div className="flex items-center gap-2 mb-4">
                <Input
                  placeholder="Enter a label for this capture..."
                  value={newItemLabel}
                  onChange={(e) => setNewItemLabel(e.target.value)}
                  className="flex-1"
                />
                <Button 
                  variant="default"
                  onClick={captureFrame}
                  className="whitespace-nowrap"
                >
                  <BookmarkPlus className="h-4 w-4 mr-2" />
                  Save Frame
                </Button>
              </div>
              
              {/* Split view: list on left, detail on right */}
              <div className="flex-1 overflow-hidden flex gap-4">
                {/* History list */}
                <div className="w-1/3 overflow-y-auto pr-2 border-r border-border">
                  {historyItems.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <p>No items in history</p>
                      <p className="text-sm mt-1">Capture frames to add them here</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {historyItems.map(item => (
                        <div 
                          key={item.id}
                          className={`p-2 rounded-md cursor-pointer transition-colors 
                            ${selectedItem?.id === item.id ? 'bg-primary/10' : 'hover:bg-muted'}`}
                          onClick={() => setSelectedItem(item)}
                        >
                          <div className="flex items-center gap-2">
                            <div className="h-16 w-16 bg-muted rounded-md overflow-hidden flex-shrink-0">
                              <img 
                                src={item.imageData} 
                                alt={item.label}
                                className="h-full w-full object-cover"
                              />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium text-sm truncate">{item.label}</h4>
                              <p className="text-xs text-muted-foreground">
                                {formatTimestamp(item.timestamp)}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                {/* Selected item detail */}
                <div className="w-2/3 overflow-y-auto">
                  {selectedItem ? (
                    <div className="space-y-4">
                      <div className="aspect-video bg-muted rounded-md overflow-hidden relative">
                        <img 
                          src={selectedItem.imageData} 
                          alt={selectedItem.label}
                          className="h-full w-full object-contain"
                        />
                      </div>
                      
                      <div>
                        <h3 className="font-semibold text-lg">{selectedItem.label}</h3>
                        <p className="text-sm text-muted-foreground">
                          {formatTimestamp(selectedItem.timestamp)}
                        </p>
                      </div>
                      
                      <div className="bg-muted p-3 rounded-md">
                        <h4 className="font-medium text-sm mb-1">AI Analysis:</h4>
                        <p className="text-sm">{selectedItem.annotation}</p>
                      </div>
                      
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => downloadItem(selectedItem)}
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Download
                        </Button>
                        <Button 
                          variant="destructive" 
                          size="sm"
                          onClick={() => deleteItem(selectedItem.id)}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center h-full text-muted-foreground">
                      <p>{historyItems.length > 0 ? 'Select an item to view details' : 'No items in history'}</p>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};