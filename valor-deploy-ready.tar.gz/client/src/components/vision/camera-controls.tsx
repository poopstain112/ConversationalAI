import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { 
  CameraIcon, 
  FlipHorizontal, 
  Flashlight,
  ZoomIn,
  ZoomOut,
  Sun,
  ScanLine,
  Ruler
} from 'lucide-react';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface CameraControlsProps {
  onToggleCamera: () => Promise<void>;
  onSwitchCamera: () => Promise<void>;
  onToggleFlash: () => Promise<void>;
  onZoomChange: (zoomLevel: number) => void;
  onToggleMeasurement: () => void;
  onToggleQRScan: () => void;
  isCameraOn: boolean;
  isFlashOn: boolean;
  zoomLevel: number;
  isMeasurementOn: boolean;
  isQRScanOn: boolean;
  hasFrontCamera: boolean;
  hasFlash: boolean;
  batteryMode: 'normal' | 'saving';
  onBatteryModeChange: (mode: 'normal' | 'saving') => void;
}

export const CameraControls: React.FC<CameraControlsProps> = ({
  onToggleCamera,
  onSwitchCamera,
  onToggleFlash,
  onZoomChange,
  onToggleMeasurement,
  onToggleQRScan,
  isCameraOn,
  isFlashOn,
  zoomLevel,
  isMeasurementOn,
  isQRScanOn,
  hasFrontCamera,
  hasFlash,
  batteryMode,
  onBatteryModeChange
}) => {
  const [isZoomControlVisible, setIsZoomControlVisible] = useState(false);
  const [currentZoom, setCurrentZoom] = useState(zoomLevel);

  // Update current zoom when prop changes
  useEffect(() => {
    setCurrentZoom(zoomLevel);
  }, [zoomLevel]);

  // Handle zoom slider change
  const handleZoomChange = (value: number[]) => {
    const newZoom = value[0];
    setCurrentZoom(newZoom);
    onZoomChange(newZoom);
  };

  return (
    <div className="flex flex-col gap-2">
      {/* Primary controls */}
      <div className="flex justify-center gap-2 mb-2">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                onClick={onToggleCamera}
                variant={isCameraOn ? "destructive" : "default"}
                size="icon"
              >
                <CameraIcon className="h-5 w-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>{isCameraOn ? 'Stop Camera' : 'Start Camera'}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        
        {hasFrontCamera && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  onClick={onSwitchCamera}
                  variant="outline"
                  size="icon"
                  disabled={!isCameraOn}
                >
                  <FlipHorizontal className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Switch Camera</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
        
        {hasFlash && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  onClick={onToggleFlash}
                  variant={isFlashOn ? "default" : "outline"}
                  size="icon"
                  disabled={!isCameraOn}
                >
                  <Flashlight className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{isFlashOn ? 'Turn Off Flash' : 'Turn On Flash'}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
        
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                onClick={() => setIsZoomControlVisible(!isZoomControlVisible)}
                variant="outline"
                size="icon"
                disabled={!isCameraOn}
              >
                {currentZoom > 1 ? <ZoomOut className="h-5 w-5" /> : <ZoomIn className="h-5 w-5" />}
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Zoom Controls</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
      
      {/* Zoom slider (conditionally visible) */}
      {isZoomControlVisible && isCameraOn && (
        <div className="flex items-center gap-2 px-2">
          <ZoomOut className="h-4 w-4 text-muted-foreground" />
          <Slider
            value={[currentZoom]}
            min={1}
            max={5}
            step={0.1}
            onValueChange={handleZoomChange}
            className="flex-1"
          />
          <ZoomIn className="h-4 w-4 text-muted-foreground" />
          <span className="text-xs text-muted-foreground w-8 text-right">{currentZoom.toFixed(1)}x</span>
        </div>
      )}
      
      {/* Advanced controls */}
      <div className="flex justify-center gap-2 mt-1">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                onClick={onToggleMeasurement}
                variant={isMeasurementOn ? "default" : "outline"}
                size="icon"
                disabled={!isCameraOn}
              >
                <Ruler className="h-5 w-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>{isMeasurementOn ? 'Disable Measurement' : 'Enable Measurement'}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                onClick={onToggleQRScan}
                variant={isQRScanOn ? "default" : "outline"}
                size="icon"
                disabled={!isCameraOn}
              >
                <ScanLine className="h-5 w-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>{isQRScanOn ? 'Disable QR/Barcode Scan' : 'Enable QR/Barcode Scan'}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                onClick={() => onBatteryModeChange(batteryMode === 'normal' ? 'saving' : 'normal')}
                variant={batteryMode === 'saving' ? "default" : "outline"}
                size="icon"
              >
                <Sun className="h-5 w-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>{batteryMode === 'saving' ? 'Normal Mode' : 'Battery Saving Mode'}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    </div>
  );
};