import React, { useRef, useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { CheckCircle, Info } from 'lucide-react';

interface BarcodeScannerProps {
  videoRef: React.RefObject<HTMLVideoElement>;
  isActive: boolean;
  onScanResult: (result: ScanResult) => void;
}

export interface ScanResult {
  type: string;
  data: string;
  timestamp: number;
}

export const BarcodeScanner: React.FC<BarcodeScannerProps> = ({
  videoRef,
  isActive,
  onScanResult
}) => {
  const { toast } = useToast();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [lastScan, setLastScan] = useState<ScanResult | null>(null);
  const [scanning, setScanning] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  // Load the barcode scanning library dynamically
  useEffect(() => {
    if (!isActive) return;
    
    const loadBarcodeDetector = async () => {
      try {
        // Check if BarcodeDetector is supported by the browser
        if ('BarcodeDetector' in window) {
          setScanning(true);
          setErrorMessage(null);
        } else {
          // Fallback to using external library or show error message
          setErrorMessage('Barcode scanning is not supported in this browser.');
          console.log('BarcodeDetector is not supported in this browser.');
          // In a real implementation, we would load a fallback library like ZXing here
        }
      } catch (error) {
        console.error('Error initializing barcode scanner:', error);
        setErrorMessage('Failed to initialize barcode scanner.');
      }
    };
    
    loadBarcodeDetector();
    
    return () => {
      setScanning(false);
    };
  }, [isActive]);
  
  // Run the scan loop when active
  useEffect(() => {
    if (!isActive || !scanning || !videoRef.current || !canvasRef.current) return;
    
    let animationFrameId: number;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    
    if (!ctx) {
      setErrorMessage('Could not initialize canvas context.');
      return;
    }
    
    // Set up canvas dimensions
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    
    // Function to run barcode detection
    const detectBarcodes = async () => {
      if (!video.paused && !video.ended && video.readyState >= 2) {
        // Draw the current video frame to the canvas
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        try {
          // Use the BarcodeDetector API if available
          if ('BarcodeDetector' in window) {
            const barcodeDetector = new (window as any).BarcodeDetector({
              formats: ['qr_code', 'code_128', 'code_39', 'code_93', 'ean_13', 'ean_8', 'itf', 'upc_a', 'upc_e']
            });
            
            const barcodes = await barcodeDetector.detect(canvas);
            
            // Process detected barcodes
            if (barcodes.length > 0) {
              const barcode = barcodes[0]; // Use the first detected barcode
              
              // Create scan result
              const result: ScanResult = {
                type: barcode.format,
                data: barcode.rawValue,
                timestamp: Date.now()
              };
              
              // Only process new scans (avoid duplicates)
              if (!lastScan || 
                  lastScan.data !== result.data || 
                  (result.timestamp - lastScan.timestamp) > 2000) {
                
                setLastScan(result);
                onScanResult(result);
                
                // Draw highlight around the barcode
                if (barcode.cornerPoints) {
                  ctx.strokeStyle = '#4ade80';
                  ctx.lineWidth = 3;
                  ctx.beginPath();
                  
                  // Draw polygon connecting the corner points
                  const points = barcode.cornerPoints;
                  ctx.moveTo(points[0].x, points[0].y);
                  for (let i = 1; i < points.length; i++) {
                    ctx.lineTo(points[i].x, points[i].y);
                  }
                  ctx.closePath();
                  ctx.stroke();
                  
                  // Draw label with the detected value
                  ctx.fillStyle = 'rgba(74, 222, 128, 0.8)';
                  const labelText = `${barcode.format}: ${barcode.rawValue}`;
                  ctx.font = '16px Arial';
                  const textWidth = ctx.measureText(labelText).width;
                  
                  const labelX = points[0].x;
                  const labelY = points[0].y - 10;
                  
                  ctx.fillRect(labelX, labelY - 25, textWidth + 10, 25);
                  ctx.fillStyle = 'white';
                  ctx.fillText(labelText, labelX + 5, labelY - 7);
                  
                  // Show success toast
                  toast({
                    title: "Barcode Detected",
                    description: `${barcode.format}: ${barcode.rawValue}`,
                    action: (
                      <div className="h-8 w-8 bg-green-500 rounded-full flex items-center justify-center">
                        <CheckCircle className="h-5 w-5 text-white" />
                      </div>
                    )
                  });
                }
              }
            }
          }
        } catch (error) {
          console.error('Barcode detection error:', error);
        }
      }
      
      // Continue scanning loop
      animationFrameId = requestAnimationFrame(detectBarcodes);
    };
    
    // Start the detection loop
    animationFrameId = requestAnimationFrame(detectBarcodes);
    
    // Cleanup function
    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [isActive, scanning, videoRef, canvasRef, lastScan, onScanResult, toast]);
  
  // Display error message if needed
  if (errorMessage) {
    return (
      <div className="absolute inset-0 bg-black/40 flex items-center justify-center pointer-events-none">
        <div className="bg-black/80 p-4 rounded-lg max-w-xs text-center text-white flex flex-col items-center gap-2">
          <Info className="h-6 w-6 text-yellow-500" />
          <p>{errorMessage}</p>
        </div>
      </div>
    );
  }
  
  // Hidden canvas for barcode detection
  return (
    <canvas
      ref={canvasRef}
      className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-0"
      aria-hidden="true"
    />
  );
};