import React, { useRef, useEffect, useState } from 'react';
import { Ruler, Move, Maximize2, Minimize2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Point {
  x: number;
  y: number;
}

interface MeasurementToolProps {
  videoRef: React.RefObject<HTMLVideoElement>;
  isActive: boolean;
  cameraFov?: number; // Camera field of view in degrees (for more accurate measurements)
  referenceObjectWidth?: number; // Width of a known object in cm (for calibration)
}

export const MeasurementTool: React.FC<MeasurementToolProps> = ({
  videoRef,
  isActive,
  cameraFov = 60, // Default FOV for most smartphone cameras
  referenceObjectWidth
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [points, setPoints] = useState<Point[]>([]);
  const [isDragging, setIsDragging] = useState<number | null>(null);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  const [measurementMode, setMeasurementMode] = useState<'distance' | 'area'>('distance');
  const [calibrated, setCalibrated] = useState(!!referenceObjectWidth);
  const [pixelsPerCm, setPixelsPerCm] = useState<number | null>(null);
  const [currentPosition, setCurrentPosition] = useState<Point | null>(null);
  
  // Update canvas dimensions when video dimensions change
  useEffect(() => {
    if (!isActive || !videoRef.current) return;
    
    const updateDimensions = () => {
      if (videoRef.current) {
        setDimensions({
          width: videoRef.current.videoWidth || 640,
          height: videoRef.current.videoHeight || 480
        });
      }
    };
    
    const video = videoRef.current;
    video.addEventListener('loadedmetadata', updateDimensions);
    updateDimensions();
    
    return () => {
      video.removeEventListener('loadedmetadata', updateDimensions);
    };
  }, [isActive, videoRef]);
  
  // Reset measurement when mode changes
  useEffect(() => {
    setPoints([]);
  }, [measurementMode]);
  
  // Handle canvas interaction for measurement
  useEffect(() => {
    if (!isActive || !canvasRef.current) return;
    
    const canvas = canvasRef.current;
    
    // Calculate the scale factor between the video dimensions and displayed size
    const getScaleFactor = () => {
      if (!videoRef.current) return { scaleX: 1, scaleY: 1 };
      
      const videoWidth = videoRef.current.videoWidth || dimensions.width;
      const videoHeight = videoRef.current.videoHeight || dimensions.height;
      const displayWidth = canvas.offsetWidth;
      const displayHeight = canvas.offsetHeight;
      
      return {
        scaleX: videoWidth / displayWidth,
        scaleY: videoHeight / displayHeight
      };
    };
    
    // Convert screen coordinates to canvas coordinates
    const getCanvasPoint = (clientX: number, clientY: number): Point => {
      const rect = canvas.getBoundingClientRect();
      const { scaleX, scaleY } = getScaleFactor();
      
      return {
        x: (clientX - rect.left) * scaleX,
        y: (clientY - rect.top) * scaleY
      };
    };
    
    // Handle mouse/touch down
    const handleStart = (clientX: number, clientY: number) => {
      const point = getCanvasPoint(clientX, clientY);
      
      // Check if we're clicking near an existing point to drag it
      for (let i = 0; i < points.length; i++) {
        const dx = points[i].x - point.x;
        const dy = points[i].y - point.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < 20) {
          setIsDragging(i);
          return;
        }
      }
      
      // Otherwise, add a new point if we haven't reached the limit
      if (
        (measurementMode === 'distance' && points.length < 2) || 
        (measurementMode === 'area' && points.length < 4)
      ) {
        setPoints([...points, point]);
      }
    };
    
    // Handle mouse/touch move
    const handleMove = (clientX: number, clientY: number) => {
      const point = getCanvasPoint(clientX, clientY);
      setCurrentPosition(point);
      
      // If dragging a point, update its position
      if (isDragging !== null) {
        const newPoints = [...points];
        newPoints[isDragging] = point;
        setPoints(newPoints);
      }
    };
    
    // Handle mouse/touch up
    const handleEnd = () => {
      setIsDragging(null);
    };
    
    // Mouse event handlers
    const handleMouseDown = (e: MouseEvent) => handleStart(e.clientX, e.clientY);
    const handleMouseMove = (e: MouseEvent) => handleMove(e.clientX, e.clientY);
    const handleMouseUp = () => handleEnd();
    
    // Touch event handlers
    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        handleStart(e.touches[0].clientX, e.touches[0].clientY);
      }
    };
    
    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        handleMove(e.touches[0].clientX, e.touches[0].clientY);
      }
    };
    
    const handleTouchEnd = () => handleEnd();
    
    // Add event listeners
    canvas.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    canvas.addEventListener('touchstart', handleTouchStart);
    window.addEventListener('touchmove', handleTouchMove);
    window.addEventListener('touchend', handleTouchEnd);
    
    // Cleanup event listeners
    return () => {
      canvas.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      canvas.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, [isActive, canvasRef, points, isDragging, dimensions, measurementMode]);
  
  // Draw measurement on canvas
  useEffect(() => {
    if (!isActive || !canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set canvas dimensions
    canvas.width = dimensions.width;
    canvas.height = dimensions.height;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw points and lines
    if (points.length > 0) {
      // Draw each point
      points.forEach((point, index) => {
        ctx.fillStyle = isDragging === index ? '#ef4444' : '#3b82f6';
        ctx.beginPath();
        ctx.arc(point.x, point.y, 8, 0, 2 * Math.PI);
        ctx.fill();
        
        // Label the point
        ctx.fillStyle = 'white';
        ctx.font = '12px Arial';
        ctx.fillText(`P${index + 1}`, point.x + 12, point.y);
      });
      
      // Draw lines between points
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 2;
      
      if (measurementMode === 'distance' && points.length === 2) {
        // Draw a line between the two points
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        ctx.lineTo(points[1].x, points[1].y);
        ctx.stroke();
        
        // Calculate and display the distance
        const dx = points[1].x - points[0].x;
        const dy = points[1].y - points[0].y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        // Calculate real-world distance if calibrated
        let distanceLabel = `${distance.toFixed(0)} px`;
        
        if (pixelsPerCm) {
          const realDistance = distance / pixelsPerCm;
          distanceLabel = `${realDistance.toFixed(1)} cm`;
        }
        
        // Draw distance label
        const midX = (points[0].x + points[1].x) / 2;
        const midY = (points[0].y + points[1].y) / 2;
        
        ctx.fillStyle = 'rgba(59, 130, 246, 0.8)';
        ctx.font = '14px Arial';
        const textWidth = ctx.measureText(distanceLabel).width;
        
        ctx.fillRect(midX - textWidth / 2 - 5, midY - 20, textWidth + 10, 25);
        ctx.fillStyle = 'white';
        ctx.fillText(distanceLabel, midX - textWidth / 2, midY - 5);
      } 
      else if (measurementMode === 'area' && points.length >= 3) {
        // Draw polygon connecting all points
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        
        for (let i = 1; i < points.length; i++) {
          ctx.lineTo(points[i].x, points[i].y);
        }
        
        // Close the polygon if all 4 points are set
        if (points.length === 4) {
          ctx.closePath();
        } 
        // Draw a line to the current mouse position if not all points are set
        else if (currentPosition) {
          ctx.lineTo(currentPosition.x, currentPosition.y);
        }
        
        ctx.stroke();
        
        // Fill area with semi-transparent color
        if (points.length === 4) {
          ctx.fillStyle = 'rgba(59, 130, 246, 0.2)';
          ctx.fill();
          
          // Calculate area (simplified for rectangles)
          // For irregular shapes, we would use a more complex algorithm
          let area = 0;
          
          // Using Shoelace formula for polygon area
          for (let i = 0; i < points.length; i++) {
            const j = (i + 1) % points.length;
            area += points[i].x * points[j].y;
            area -= points[j].x * points[i].y;
          }
          
          area = Math.abs(area) / 2;
          
          // Calculate real-world area if calibrated
          let areaLabel = `${area.toFixed(0)} px²`;
          
          if (pixelsPerCm) {
            const realArea = area / (pixelsPerCm * pixelsPerCm);
            areaLabel = `${realArea.toFixed(1)} cm²`;
          }
          
          // Find center of polygon
          let centerX = 0, centerY = 0;
          for (const point of points) {
            centerX += point.x;
            centerY += point.y;
          }
          centerX /= points.length;
          centerY /= points.length;
          
          // Draw area label
          ctx.fillStyle = 'rgba(59, 130, 246, 0.8)';
          ctx.font = '14px Arial';
          const textWidth = ctx.measureText(areaLabel).width;
          
          ctx.fillRect(centerX - textWidth / 2 - 5, centerY - 10, textWidth + 10, 25);
          ctx.fillStyle = 'white';
          ctx.fillText(areaLabel, centerX - textWidth / 2, centerY + 5);
        }
      }
    }
    
    // Draw calibration instructions if not calibrated
    if (!calibrated && points.length === 0) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.fillRect(0, canvas.height - 80, canvas.width, 80);
      
      ctx.fillStyle = 'white';
      ctx.font = '16px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(
        'Calibration: Measure an object of known size first', 
        canvas.width / 2, 
        canvas.height - 50
      );
      ctx.font = '14px Arial';
      ctx.fillText(
        'Place a credit card or ruler in view, then mark its width', 
        canvas.width / 2, 
        canvas.height - 30
      );
    }
    
  }, [isActive, canvasRef, points, isDragging, dimensions, measurementMode, currentPosition, pixelsPerCm, calibrated]);
  
  // Function to calibrate using known object width
  const calibrateWithReference = (knownWidthInCm: number = 8.5) => {
    if (points.length !== 2) return;
    
    const dx = points[1].x - points[0].x;
    const dy = points[1].y - points[0].y;
    const pixelDistance = Math.sqrt(dx * dx + dy * dy);
    
    // Calculate pixels per cm
    const newPixelsPerCm = pixelDistance / knownWidthInCm;
    setPixelsPerCm(newPixelsPerCm);
    setCalibrated(true);
    
    // Reset points after calibration
    setPoints([]);
  };
  
  if (!isActive) return null;
  
  return (
    <>
      <canvas
        ref={canvasRef}
        className="absolute top-0 left-0 w-full h-full pointer-events-auto"
        style={{ objectFit: 'cover' }}
      />
      
      <div className="absolute bottom-4 left-4 flex flex-col gap-2">
        <div className="flex items-center gap-2 bg-black/70 rounded-lg p-2 backdrop-blur-sm">
          <Button
            variant={measurementMode === 'distance' ? "default" : "outline"}
            size="sm"
            onClick={() => setMeasurementMode('distance')}
            className="h-8 px-2"
          >
            <Ruler className="h-4 w-4 mr-1" />
            Distance
          </Button>
          
          <Button
            variant={measurementMode === 'area' ? "default" : "outline"}
            size="sm"
            onClick={() => setMeasurementMode('area')}
            className="h-8 px-2"
          >
            <Maximize2 className="h-4 w-4 mr-1" />
            Area
          </Button>
          
          {points.length === 2 && measurementMode === 'distance' && !calibrated && (
            <Button
              variant="secondary"
              size="sm"
              onClick={() => calibrateWithReference()}
              className="h-8 px-2"
            >
              <Ruler className="h-4 w-4 mr-1" />
              Calibrate
            </Button>
          )}
          
          {points.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPoints([])}
              className="h-8 px-2"
            >
              Clear
            </Button>
          )}
        </div>
        
        {calibrated && (
          <div className="bg-green-900/70 text-white px-3 py-1 rounded-md text-sm flex items-center">
            <Ruler className="h-4 w-4 mr-2" />
            <span>Calibrated: {pixelsPerCm?.toFixed(1)} px/cm</span>
          </div>
        )}
      </div>
    </>
  );
};