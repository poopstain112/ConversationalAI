import React, { useRef, useEffect, useState } from 'react';
import { ArrowBigDown, ArrowBigLeft, ArrowBigRight, ArrowBigUp, Target } from 'lucide-react';

interface ObjectDetection {
  id: string;
  label: string;
  confidence: number;
  bbox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

interface ObjectDetectionProps {
  videoRef: React.RefObject<HTMLVideoElement>;
  detections: ObjectDetection[];
  targetObject?: string;
  showOverlay: boolean;
}

export const ObjectDetectionOverlay: React.FC<ObjectDetectionProps> = ({
  videoRef,
  detections,
  targetObject,
  showOverlay
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  
  // Update canvas dimensions when video dimensions change
  useEffect(() => {
    const updateDimensions = () => {
      if (videoRef.current) {
        setDimensions({
          width: videoRef.current.videoWidth,
          height: videoRef.current.videoHeight
        });
      }
    };
    
    const video = videoRef.current;
    if (video) {
      video.addEventListener('loadedmetadata', updateDimensions);
      // Also check periodically for dimension changes
      const interval = setInterval(updateDimensions, 1000);
      
      return () => {
        video.removeEventListener('loadedmetadata', updateDimensions);
        clearInterval(interval);
      };
    }
  }, [videoRef]);
  
  // Draw detection boxes and AR elements
  useEffect(() => {
    if (!canvasRef.current || !showOverlay) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set canvas dimensions to match video
    canvas.width = dimensions.width;
    canvas.height = dimensions.height;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw detection boxes
    detections.forEach(detection => {
      const { x, y, width, height } = detection.bbox;
      const isTarget = targetObject && detection.label.toLowerCase().includes(targetObject.toLowerCase());
      
      // Set style based on whether this is the target object
      ctx.strokeStyle = isTarget ? '#4ade80' : '#3b82f6';
      ctx.lineWidth = isTarget ? 3 : 2;
      
      // Draw bounding box
      ctx.beginPath();
      ctx.rect(x, y, width, height);
      ctx.stroke();
      
      // Draw label with confidence
      ctx.fillStyle = isTarget ? 'rgba(74, 222, 128, 0.8)' : 'rgba(59, 130, 246, 0.8)';
      const labelText = `${detection.label} ${Math.round(detection.confidence * 100)}%`;
      ctx.font = '16px Arial';
      const textWidth = ctx.measureText(labelText).width;
      
      ctx.fillRect(x, y - 25, textWidth + 10, 25);
      ctx.fillStyle = 'white';
      ctx.fillText(labelText, x + 5, y - 7);
      
      // Draw AR pointer for target objects
      if (isTarget) {
        // Calculate center of bounding box
        const centerX = x + width / 2;
        const centerY = y + height / 2;
        
        // Draw pulsating target indicator
        const now = Date.now();
        const pulseSize = 10 + Math.sin(now / 200) * 5;
        
        // Outer circle
        ctx.strokeStyle = '#4ade80';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(centerX, centerY, pulseSize + 5, 0, 2 * Math.PI);
        ctx.stroke();
        
        // Inner circle
        ctx.fillStyle = 'rgba(74, 222, 128, 0.6)';
        ctx.beginPath();
        ctx.arc(centerX, centerY, pulseSize, 0, 2 * Math.PI);
        ctx.fill();
        
        // Draw arrow pointing to the object
        // This will change based on the object's position
        const canvasCenterX = canvas.width / 2;
        const canvasCenterY = canvas.height / 2;
        
        // Determine arrow direction and position
        const arrowSize = 30;
        const arrowDistance = 70;
        let arrowX, arrowY, ArrowComponent;
        
        if (centerY < canvasCenterY - canvas.height / 4) {
          // Object is significantly above center
          arrowX = canvasCenterX;
          arrowY = canvasCenterY - arrowDistance;
          
          // Draw up arrow
          ctx.fillStyle = '#4ade80';
          ctx.beginPath();
          ctx.moveTo(arrowX, arrowY - arrowSize);
          ctx.lineTo(arrowX - arrowSize / 2, arrowY);
          ctx.lineTo(arrowX + arrowSize / 2, arrowY);
          ctx.closePath();
          ctx.fill();
        } else if (centerY > canvasCenterY + canvas.height / 4) {
          // Object is significantly below center
          arrowX = canvasCenterX;
          arrowY = canvasCenterY + arrowDistance;
          
          // Draw down arrow
          ctx.fillStyle = '#4ade80';
          ctx.beginPath();
          ctx.moveTo(arrowX, arrowY + arrowSize);
          ctx.lineTo(arrowX - arrowSize / 2, arrowY);
          ctx.lineTo(arrowX + arrowSize / 2, arrowY);
          ctx.closePath();
          ctx.fill();
        } else if (centerX < canvasCenterX - canvas.width / 4) {
          // Object is significantly to the left
          arrowX = canvasCenterX - arrowDistance;
          arrowY = canvasCenterY;
          
          // Draw left arrow
          ctx.fillStyle = '#4ade80';
          ctx.beginPath();
          ctx.moveTo(arrowX - arrowSize, arrowY);
          ctx.lineTo(arrowX, arrowY - arrowSize / 2);
          ctx.lineTo(arrowX, arrowY + arrowSize / 2);
          ctx.closePath();
          ctx.fill();
        } else if (centerX > canvasCenterX + canvas.width / 4) {
          // Object is significantly to the right
          arrowX = canvasCenterX + arrowDistance;
          arrowY = canvasCenterY;
          
          // Draw right arrow
          ctx.fillStyle = '#4ade80';
          ctx.beginPath();
          ctx.moveTo(arrowX + arrowSize, arrowY);
          ctx.lineTo(arrowX, arrowY - arrowSize / 2);
          ctx.lineTo(arrowX, arrowY + arrowSize / 2);
          ctx.closePath();
          ctx.fill();
        }
      }
    });
    
  }, [videoRef, detections, dimensions, targetObject, showOverlay]);
  
  if (!showOverlay) return null;
  
  return (
    <canvas
      ref={canvasRef}
      className="absolute top-0 left-0 w-full h-full pointer-events-none"
      style={{
        objectFit: 'cover',
      }}
    />
  );
};

// Distance estimation component
export const DistanceIndicator: React.FC<{
  distance: number | null;
  direction: string | null;
}> = ({ distance, direction }) => {
  if (distance === null) return null;
  
  const getDirectionIcon = () => {
    switch (direction) {
      case 'up': return <ArrowBigUp className="h-5 w-5" />;
      case 'down': return <ArrowBigDown className="h-5 w-5" />;
      case 'left': return <ArrowBigLeft className="h-5 w-5" />;
      case 'right': return <ArrowBigRight className="h-5 w-5" />;
      default: return <Target className="h-5 w-5" />;
    }
  };
  
  return (
    <div className="absolute bottom-4 left-4 bg-black/70 text-white px-4 py-2 rounded-full flex items-center gap-2">
      {getDirectionIcon()}
      <span>{distance < 1 ? `${Math.round(distance * 100)} cm` : `${distance.toFixed(1)} m`}</span>
    </div>
  );
};