import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PictureInPicture, Maximize2, Minimize2, MonitorSmartphone, Smartphone, QrCode } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

interface DeviceInfo {
  id: string;
  name: string;
  type: 'main' | 'secondary';
  connected: boolean;
}

interface MultiViewProps {
  primaryVideoRef: React.RefObject<HTMLVideoElement>;
  onSecondaryConnect: (deviceInfo: DeviceInfo) => void;
  onSecondaryDisconnect: (deviceId: string) => void;
}

export const MultiView: React.FC<MultiViewProps> = ({
  primaryVideoRef,
  onSecondaryConnect,
  onSecondaryDisconnect
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [pairMode, setPairMode] = useState<'qr' | 'manual'>('qr');
  const [connectedDevices, setConnectedDevices] = useState<DeviceInfo[]>([]);
  const [pairingCode, setPairingCode] = useState<string>('');
  const secondaryViewRef = useRef<HTMLVideoElement>(null);
  
  // Generate a random pairing code on mount
  useEffect(() => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setPairingCode(code);
  }, []);
  
  // Simulate device connection for demo purposes
  const handleConnectSecondaryDevice = () => {
    const newDevice: DeviceInfo = {
      id: `device-${Date.now()}`,
      name: 'Secondary Camera',
      type: 'secondary',
      connected: true
    };
    
    setConnectedDevices(prev => [...prev, newDevice]);
    onSecondaryConnect(newDevice);
    
    // For demo: show a video in the secondary view
    if (secondaryViewRef.current) {
      navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
          if (secondaryViewRef.current) {
            secondaryViewRef.current.srcObject = stream;
            secondaryViewRef.current.play().catch(e => console.error(e));
          }
        })
        .catch(err => console.error('Error accessing camera for secondary view:', err));
    }
  };
  
  const handleDisconnectDevice = (deviceId: string) => {
    setConnectedDevices(prev => prev.filter(device => device.id !== deviceId));
    onSecondaryDisconnect(deviceId);
    
    // Stop the video stream if disconnecting
    if (secondaryViewRef.current && secondaryViewRef.current.srcObject) {
      const stream = secondaryViewRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      secondaryViewRef.current.srcObject = null;
    }
  };
  
  return (
    <>
      {/* Multi-view toggle button */}
      <Button
        variant="outline"
        size="sm"
        className="fixed bottom-4 left-4 z-10 flex items-center gap-2"
        onClick={() => setIsExpanded(true)}
      >
        <MonitorSmartphone className="h-4 w-4" />
        <span>Multi-View</span>
        {connectedDevices.length > 0 && (
          <span className="bg-primary text-primary-foreground w-5 h-5 flex items-center justify-center rounded-full text-xs">
            {connectedDevices.length}
          </span>
        )}
      </Button>
      
      {/* Multi-view panel */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
            onClick={() => setIsExpanded(false)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="bg-card rounded-lg shadow-lg max-w-2xl w-full overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="p-4 border-b flex justify-between items-center">
                <h3 className="font-medium flex items-center gap-2">
                  <MonitorSmartphone className="h-5 w-5" />
                  Multi-View Camera Setup
                </h3>
                <Button variant="ghost" size="icon" onClick={() => setIsExpanded(false)}>
                  <Minimize2 className="h-5 w-5" />
                </Button>
              </div>
              
              <div className="p-5">
                <Tabs defaultValue={pairMode} onValueChange={(value) => setPairMode(value as 'qr' | 'manual')}>
                  <TabsList className="mb-4">
                    <TabsTrigger value="qr" className="flex items-center gap-2">
                      <QrCode className="h-4 w-4" />
                      QR Code Pairing
                    </TabsTrigger>
                    <TabsTrigger value="manual" className="flex items-center gap-2">
                      <Smartphone className="h-4 w-4" />
                      Manual Pairing
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="qr">
                    <Card>
                      <CardContent className="pt-4 flex flex-col items-center">
                        <p className="text-sm text-muted-foreground mb-4 text-center">
                          Scan this QR code with your secondary device's camera to establish a connection.
                        </p>
                        
                        <div className="bg-white p-4 rounded-lg mb-4">
                          {/* Placeholder for QR code - in a real app you would use a library to generate this */}
                          <div className="w-48 h-48 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center">
                            <div className="text-center text-muted-foreground">
                              <QrCode className="h-16 w-16 mx-auto mb-2 opacity-50" />
                              <p className="text-xs">QR Code for pairing</p>
                              <p className="text-xs mt-1">Code: {pairingCode}</p>
                            </div>
                          </div>
                        </div>
                        
                        {/* For demo purposes only - would happen automatically in a real app */}
                        <Button variant="default" size="sm" onClick={handleConnectSecondaryDevice}>
                          Simulate Device Connection
                        </Button>
                      </CardContent>
                    </Card>
                  </TabsContent>
                  
                  <TabsContent value="manual">
                    <Card>
                      <CardContent className="pt-4">
                        <div className="mb-4">
                          <p className="text-sm text-muted-foreground mb-2">
                            Enter this pairing code on your secondary device:
                          </p>
                          <div className="flex items-center justify-center mb-4">
                            <div className="bg-secondary text-secondary-foreground px-6 py-3 rounded-lg text-2xl font-mono tracking-wider">
                              {pairingCode}
                            </div>
                          </div>
                          
                          <p className="text-sm text-muted-foreground">
                            Or ask your helper to navigate to this URL and enter the code:
                          </p>
                          <p className="text-sm bg-secondary px-3 py-2 rounded-md my-2 font-mono break-all">
                            {window.location.origin}/connect
                          </p>
                        </div>
                        
                        {/* For demo purposes only - would happen after code entry in a real app */}
                        <Button variant="default" size="sm" onClick={handleConnectSecondaryDevice} className="w-full">
                          Simulate Device Connection
                        </Button>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
                
                {/* Connected devices */}
                {connectedDevices.length > 0 && (
                  <div className="mt-6">
                    <h4 className="font-medium mb-3">Connected Devices</h4>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-muted/50 rounded-lg overflow-hidden">
                        <div className="p-2 bg-muted/80 text-xs font-medium">Primary View</div>
                        <div className="aspect-video bg-black relative flex items-center justify-center">
                          {primaryVideoRef.current ? (
                            <video 
                              ref={primaryVideoRef} 
                              className="w-full h-full object-cover pointer-events-none"
                            />
                          ) : (
                            <p className="text-sm text-muted-foreground">Camera not available</p>
                          )}
                        </div>
                      </div>
                      
                      {connectedDevices.map(device => (
                        <div key={device.id} className="bg-muted/50 rounded-lg overflow-hidden">
                          <div className="p-2 bg-muted/80 text-xs font-medium flex items-center justify-between">
                            <span>{device.name}</span>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-5 w-5" 
                              onClick={() => handleDisconnectDevice(device.id)}
                            >
                              <Minimize2 className="h-3 w-3" />
                            </Button>
                          </div>
                          <div className="aspect-video bg-black relative flex items-center justify-center">
                            <video 
                              ref={secondaryViewRef}
                              className="w-full h-full object-cover pointer-events-none"
                              autoPlay
                              playsInline
                              muted
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="mt-4">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          connectedDevices.forEach(device => handleDisconnectDevice(device.id));
                        }}
                        className="w-full"
                      >
                        Disconnect All Devices
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};