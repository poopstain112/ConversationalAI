import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { PlayCircle, PauseCircle, VolumeX, Volume1, Volume2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Voice settings interface
export interface VoiceSettings {
  enabled: boolean;
  voice: string;
  rate: number;
  pitch: number;
  volume: number;
  autoRead: boolean;
}

interface VoiceSettingsProps {
  settings: VoiceSettings;
  onSettingsChange: (settings: VoiceSettings) => void;
  onSave?: () => void;
}

export function VoiceSettings({ 
  settings, 
  onSettingsChange,
  onSave
}: VoiceSettingsProps) {
  const { toast } = useToast();
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentUtterance, setCurrentUtterance] = useState<SpeechSynthesisUtterance | null>(null);
  
  // Load available voices
  useEffect(() => {
    const loadVoices = () => {
      if ('speechSynthesis' in window) {
        const voices = window.speechSynthesis.getVoices();
        if (voices.length > 0) {
          setAvailableVoices(voices);
        }
      }
    };
    
    // Load voices immediately
    loadVoices();
    
    // Add event listener for when voices change (some browsers load them asynchronously)
    if ('speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
    
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.onvoiceschanged = null;
      }
    };
  }, []);
  
  // Stop speech when component unmounts
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);
  
  // Handle toggle for speech synthesis
  const handleToggleEnable = (enabled: boolean) => {
    onSettingsChange({ ...settings, enabled });
    
    if (!enabled && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    }
  };
  
  // Test the current voice settings
  const testVoice = () => {
    if (!settings.enabled) {
      toast({
        title: "Speech synthesis is disabled",
        description: "Enable speech synthesis first to test the voice",
      });
      return;
    }
    
    if (!('speechSynthesis' in window)) {
      toast({
        title: "Not supported",
        description: "Speech synthesis is not supported in your browser",
        variant: "destructive",
      });
      return;
    }
    
    // Stop any current speech
    window.speechSynthesis.cancel();
    
    // Create a new utterance to test the voice
    const utterance = new SpeechSynthesisUtterance(
      "Hello, I'm Valor AI. This is a test of my voice settings."
    );
    
    // Find the selected voice
    if (settings.voice) {
      const voice = availableVoices.find(v => v.name === settings.voice);
      if (voice) {
        utterance.voice = voice;
      }
    }
    
    // Apply other settings
    utterance.rate = settings.rate;
    utterance.pitch = settings.pitch;
    utterance.volume = settings.volume;
    
    // Store the utterance to allow stopping
    setCurrentUtterance(utterance);
    
    // Set up listeners
    utterance.onstart = () => setIsPlaying(true);
    utterance.onend = () => {
      setIsPlaying(false);
      setCurrentUtterance(null);
    };
    utterance.onerror = () => {
      setIsPlaying(false);
      setCurrentUtterance(null);
      toast({
        title: "Speech error",
        description: "There was an error playing the speech",
        variant: "destructive",
      });
    };
    
    // Play the speech
    window.speechSynthesis.speak(utterance);
  };
  
  // Stop the test voice
  const stopVoice = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
      setCurrentUtterance(null);
    }
  };
  
  const getVolumeIcon = () => {
    if (settings.volume === 0) return <VolumeX className="h-4 w-4" />;
    if (settings.volume < 0.5) return <Volume1 className="h-4 w-4" />;
    return <Volume2 className="h-4 w-4" />;
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Voice Settings</CardTitle>
        <CardDescription>
          Customize how Valor AI speaks to you
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Enable speech toggle */}
        <div className="flex items-center justify-between">
          <Label htmlFor="speech-toggle" className="flex flex-col gap-1">
            <span>Enable speech</span>
            <span className="text-xs text-muted-foreground">
              Turn on to let Valor AI speak responses aloud
            </span>
          </Label>
          <Switch 
            id="speech-toggle" 
            checked={settings.enabled}
            onCheckedChange={handleToggleEnable}
          />
        </div>
        
        {/* Divider */}
        <div className="border-t my-4" />
        
        {/* Voice selection */}
        <div className="space-y-2">
          <Label htmlFor="voice-select">Voice</Label>
          <Select
            value={settings.voice}
            onValueChange={(value) => onSettingsChange({ ...settings, voice: value })}
            disabled={!settings.enabled}
          >
            <SelectTrigger id="voice-select">
              <SelectValue placeholder="Select a voice" />
            </SelectTrigger>
            <SelectContent className="max-h-[300px]">
              {availableVoices.map((voice) => (
                <SelectItem key={voice.name} value={voice.name}>
                  {voice.name} {voice.localService ? '(Local)' : ''}
                </SelectItem>
              ))}
              {availableVoices.length === 0 && (
                <SelectItem value="default" disabled>
                  No voices available
                </SelectItem>
              )}
            </SelectContent>
          </Select>
        </div>
        
        {/* Rate slider */}
        <div className="space-y-2">
          <Label htmlFor="rate-slider">
            Speed: {settings.rate.toFixed(1)}x
          </Label>
          <Slider
            id="rate-slider"
            min={0.5}
            max={2}
            step={0.1}
            value={[settings.rate]}
            onValueChange={(value) => onSettingsChange({ ...settings, rate: value[0] })}
            disabled={!settings.enabled}
          />
        </div>
        
        {/* Pitch slider */}
        <div className="space-y-2">
          <Label htmlFor="pitch-slider">
            Pitch: {settings.pitch.toFixed(1)}
          </Label>
          <Slider
            id="pitch-slider"
            min={0.5}
            max={2}
            step={0.1}
            value={[settings.pitch]}
            onValueChange={(value) => onSettingsChange({ ...settings, pitch: value[0] })}
            disabled={!settings.enabled}
          />
        </div>
        
        {/* Volume slider */}
        <div className="space-y-2">
          <Label htmlFor="volume-slider" className="flex items-center gap-2">
            {getVolumeIcon()}
            Volume: {Math.round(settings.volume * 100)}%
          </Label>
          <Slider
            id="volume-slider"
            min={0}
            max={1}
            step={0.05}
            value={[settings.volume]}
            onValueChange={(value) => onSettingsChange({ ...settings, volume: value[0] })}
            disabled={!settings.enabled}
          />
        </div>
        
        {/* Auto-read toggle */}
        <div className="flex items-center justify-between mt-4">
          <Label htmlFor="auto-read-toggle" className="flex flex-col gap-1">
            <span>Auto-read responses</span>
            <span className="text-xs text-muted-foreground">
              Automatically read AI responses aloud
            </span>
          </Label>
          <Switch 
            id="auto-read-toggle" 
            checked={settings.autoRead}
            onCheckedChange={(checked) => onSettingsChange({ ...settings, autoRead: checked })}
            disabled={!settings.enabled}
          />
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          size="sm"
          onClick={isPlaying ? stopVoice : testVoice}
          disabled={!settings.enabled || availableVoices.length === 0}
        >
          {isPlaying ? (
            <>
              <PauseCircle className="mr-2 h-4 w-4" />
              Stop Test
            </>
          ) : (
            <>
              <PlayCircle className="mr-2 h-4 w-4" />
              Test Voice
            </>
          )}
        </Button>
        
        {onSave && (
          <Button onClick={onSave}>
            Save Settings
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}