import { FC, useEffect, useRef } from "react";
import { Conversation } from "@/types";
import MessageItem from "./message-item";
import WelcomeMessage from "./welcome-message";
import TypingIndicator from "./typing-indicator";

interface MessageListProps {
  conversation: Conversation;
  isTyping: boolean;
}

const MessageList: FC<MessageListProps> = ({ conversation, isTyping }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { messages } = conversation;
  
  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);
  
  // Show welcome message if there are no messages
  if (messages.length === 0) {
    return <WelcomeMessage />;
  }

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hide py-4 space-y-6">
      {messages.map((message, index) => (
        <MessageItem key={index} message={message} />
      ))}
      
      {isTyping && <TypingIndicator />}
      
      <div ref={messagesEndRef} />
    </div>
  );
};

export default MessageList;
