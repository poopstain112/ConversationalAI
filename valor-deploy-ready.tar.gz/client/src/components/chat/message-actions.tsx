import React, { useState } from 'react';
import { Copy, Check, Share, Speaker, VolumeX, MoreHorizontal } from 'lucide-react';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface MessageActionsProps {
  message: string;
  onSpeakMessage: () => void;
  isSpeaking: boolean;
}

export function MessageActions({ message, onSpeakMessage, isSpeaking }: MessageActionsProps) {
  const { toast } = useToast();
  const [hasCopied, setHasCopied] = useState(false);
  
  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(message);
      setHasCopied(true);
      toast({
        title: "Copied to clipboard",
        description: "Message content copied to clipboard",
      });
      
      // Reset the copied state after 2 seconds
      setTimeout(() => {
        setHasCopied(false);
      }, 2000);
    } catch (error: any) {
      toast({
        title: "Copy failed",
        description: "Could not copy message to clipboard",
        variant: "destructive",
      });
    }
  };
  
  const shareMessage = async () => {
    // Check if the Web Share API is available
    if (navigator.share) {
      try {
        await navigator.share({
          text: message,
        });
        toast({
          title: "Shared successfully",
          description: "Message shared successfully",
        });
      } catch (error: any) {
        // User probably canceled the share dialog
        if (error.name !== 'AbortError') {
          toast({
            title: "Share failed",
            description: "Could not share message",
            variant: "destructive",
          });
        }
      }
    } else {
      // Fallback for browsers that don't support the Web Share API
      copyToClipboard();
    }
  };
  
  return (
    <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity">
      <Button
        variant="ghost"
        size="icon"
        className="h-7 w-7 rounded-full"
        onClick={onSpeakMessage}
        title={isSpeaking ? "Stop speaking" : "Speak message"}
      >
        {isSpeaking ? <VolumeX className="h-3.5 w-3.5" /> : <Speaker className="h-3.5 w-3.5" />}
      </Button>
      
      <Button
        variant="ghost"
        size="icon"
        className="h-7 w-7 rounded-full"
        onClick={copyToClipboard}
        title="Copy to clipboard"
      >
        {hasCopied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
      </Button>
      
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 rounded-full"
          >
            <MoreHorizontal className="h-3.5 w-3.5" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={copyToClipboard}>
            <Copy className="h-4 w-4 mr-2" />
            Copy text
          </DropdownMenuItem>
          <DropdownMenuItem onClick={shareMessage}>
            <Share className="h-4 w-4 mr-2" />
            Share
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={onSpeakMessage}>
            {isSpeaking ? <VolumeX className="h-4 w-4 mr-2" /> : <Speaker className="h-4 w-4 mr-2" />}
            {isSpeaking ? "Stop speaking" : "Speak message"}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}