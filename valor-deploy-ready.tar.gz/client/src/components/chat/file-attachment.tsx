import React, { useState, useRef } from 'react';
import { Paperclip, X, FileImage, FileText, File, FileArchive, FileVideo } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface FileAttachmentProps {
  onAttach: (files: File[]) => void;
  acceptedTypes?: string;
  maxSize?: number; // in MB
  maxFiles?: number;
  attachedFiles: File[];
  onRemove: (index: number) => void;
}

export function FileAttachment({
  onAttach,
  acceptedTypes = 'image/*',
  maxSize = 10, // 10MB default
  maxFiles = 5,
  attachedFiles,
  onRemove
}: FileAttachmentProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  
  const handleClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  const validateFiles = (files: File[]): File[] => {
    // Check if adding these files would exceed the maximum
    if (attachedFiles.length + files.length > maxFiles) {
      toast({
        title: "Too many files",
        description: `You can only attach up to ${maxFiles} files`,
        variant: "destructive",
      });
      
      // Return only the number of files that can be added
      return files.slice(0, maxFiles - attachedFiles.length);
    }
    
    // Validate each file
    return files.filter(file => {
      // Check file size
      if (file.size > maxSize * 1024 * 1024) {
        toast({
          title: "File too large",
          description: `${file.name} exceeds the ${maxSize}MB limit`,
          variant: "destructive",
        });
        return false;
      }
      
      // Check file type if acceptedTypes is specified
      if (acceptedTypes !== '*') {
        const fileType = file.type;
        const acceptedTypesList = acceptedTypes.split(',');
        
        const isAccepted = acceptedTypesList.some(type => {
          // Handle wildcards like "image/*"
          if (type.endsWith('/*')) {
            const category = type.split('/')[0];
            return fileType.startsWith(category + '/');
          }
          return type === fileType;
        });
        
        if (!isAccepted) {
          toast({
            title: "Unsupported file type",
            description: `${file.name} is not a supported file type`,
            variant: "destructive",
          });
          return false;
        }
      }
      
      return true;
    });
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    
    const filesArray = Array.from(fileList);
    const validFiles = validateFiles(filesArray);
    
    if (validFiles.length > 0) {
      onAttach(validFiles);
      
      // Clear the input value so the same file can be selected again
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };
  
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    const fileList = e.dataTransfer.files;
    if (!fileList || fileList.length === 0) return;
    
    const filesArray = Array.from(fileList);
    const validFiles = validateFiles(filesArray);
    
    if (validFiles.length > 0) {
      onAttach(validFiles);
    }
  };
  
  const getFileIcon = (file: File) => {
    const fileType = file.type;
    
    if (fileType.startsWith('image/')) {
      return <FileImage className="h-4 w-4" />;
    } else if (fileType.startsWith('text/')) {
      return <FileText className="h-4 w-4" />;
    } else if (fileType.startsWith('video/')) {
      return <FileVideo className="h-4 w-4" />;
    } else if (fileType.includes('zip') || fileType.includes('rar') || fileType.includes('7z')) {
      return <FileArchive className="h-4 w-4" />;
    } else {
      return <File className="h-4 w-4" />;
    }
  };
  
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };
  
  return (
    <div className="w-full">
      {/* Hidden file input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept={acceptedTypes}
        multiple={maxFiles > 1}
        className="hidden"
      />
      
      {/* Attachment button */}
      <div className="flex items-center">
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 rounded-full"
          onClick={handleClick}
          title="Attach files"
        >
          <Paperclip className="h-4 w-4" />
        </Button>
        
        <div className="text-xs text-muted-foreground ml-2">
          {maxFiles > 1 ? `Up to ${maxFiles} files` : 'One file'}, max {maxSize}MB each
        </div>
      </div>
      
      {/* Drop zone - only shown when files are being dragged over */}
      {isDragging && (
        <div
          className="absolute inset-0 bg-primary/10 border-2 border-dashed border-primary/50 rounded-lg flex items-center justify-center z-10"
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <div className="text-center p-4">
            <Paperclip className="h-8 w-8 mx-auto mb-2 text-primary" />
            <p className="text-sm font-medium">Drop files here</p>
          </div>
        </div>
      )}
      
      {/* File attachments preview */}
      {attachedFiles.length > 0 && (
        <div className="mt-2 space-y-2">
          <div className="text-xs font-medium text-muted-foreground mb-1">
            Attachments ({attachedFiles.length})
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {attachedFiles.map((file, index) => (
              <div 
                key={index}
                className="flex items-center group bg-muted/50 rounded-md p-2 text-sm"
              >
                <div className="mr-2">
                  {getFileIcon(file)}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="truncate font-medium" title={file.name}>
                    {file.name}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {formatFileSize(file.size)}
                  </div>
                </div>
                
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => onRemove(index)}
                  title="Remove file"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}