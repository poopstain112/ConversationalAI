import { FC, FormEvent, useRef, useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { SendIcon } from "lucide-react";

interface MessageFormProps {
  onSendMessage: (message: string) => void;
  disabled?: boolean;
}

const MessageForm: FC<MessageFormProps> = ({ onSendMessage, disabled = false }) => {
  const [message, setMessage] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea based on content
  const autoResizeTextarea = () => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = "auto";
      const newHeight = Math.min(textarea.scrollHeight, 150);
      textarea.style.height = `${newHeight}px`;
    }
  };

  // Update textarea height when content changes
  useEffect(() => {
    autoResizeTextarea();
  }, [message]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    
    if (!message.trim() || disabled) return;
    
    onSendMessage(message);
    setMessage("");
    
    // Reset textarea height
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
  };

  return (
    <footer className="bg-white border-t border-neutral-200 py-4 sticky bottom-0 z-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <form onSubmit={handleSubmit} className="flex items-end gap-2">
          <div className="flex-1 min-w-0">
            <div className="relative bg-neutral-100 rounded-lg focus-within:ring-2 focus-within:ring-primary">
              <textarea
                ref={textareaRef}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={1}
                className="block w-full py-3 pl-4 pr-10 bg-transparent border-0 resize-none focus:ring-0 text-neutral-800 placeholder-neutral-500 rounded-lg"
                placeholder="Type your message..."
                style={{ maxHeight: "150px", overflowY: "auto" }}
                disabled={disabled}
              />
            </div>
          </div>
          <Button
            type="submit"
            className="flex-shrink-0 bg-primary hover:bg-primary/90 text-white rounded-full w-12 h-12 flex items-center justify-center"
            disabled={disabled || !message.trim()}
          >
            <SendIcon className="h-5 w-5" />
          </Button>
        </form>
      </div>
    </footer>
  );
};

export default MessageForm;
