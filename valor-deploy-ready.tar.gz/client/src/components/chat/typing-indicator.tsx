import { FC } from "react";

const TypingIndicator: FC = () => {
  return (
    <div className="py-4">
      <div className="flex">
        <div className="bg-white rounded-2xl rounded-tl-sm py-3 px-4 shadow-sm border border-neutral-200 flex items-center">
          <div className="flex space-x-1">
            <div className="w-2 h-2 bg-neutral-400 rounded-full animate-pulse"></div>
            <div className="w-2 h-2 bg-neutral-400 rounded-full animate-pulse" style={{ animationDelay: "0.2s" }}></div>
            <div className="w-2 h-2 bg-neutral-400 rounded-full animate-pulse" style={{ animationDelay: "0.4s" }}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TypingIndicator;
