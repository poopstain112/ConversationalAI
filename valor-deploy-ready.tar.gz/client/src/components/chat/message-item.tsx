import { FC } from "react";
import { Message } from "@/types";
import { cn } from "@/lib/utils";

interface MessageItemProps {
  message: Message;
}

const MessageItem: FC<MessageItemProps> = ({ message }) => {
  const isUser = message.role === "user";
  
  // Function to process message content and handle markdown-like formatting
  const formatContent = (content: string) => {
    if (content.includes("\n1.")) {
      const parts = content.split("\n");
      const formattedParts = [];
      let inList = false;
      let listItems: string[] = [];
      
      parts.forEach((part, index) => {
        if (part.match(/^\d+\./)) {
          if (!inList) {
            inList = true;
          }
          listItems.push(part.replace(/^\d+\.\s*/, ""));
        } else {
          if (inList) {
            formattedParts.push(
              <ol key={`list-${index}`} className="list-decimal pl-5 mt-2 space-y-1">
                {listItems.map((item, i) => (
                  <li key={`item-${i}`}>{item}</li>
                ))}
              </ol>
            );
            listItems = [];
            inList = false;
          }
          
          if (part.trim()) {
            formattedParts.push(
              <p key={`text-${index}`} className={formattedParts.length > 0 ? "mt-2" : ""}>
                {part}
              </p>
            );
          }
        }
      });
      
      // Handle case where list is at the end of the message
      if (inList && listItems.length > 0) {
        formattedParts.push(
          <ol key="list-end" className="list-decimal pl-5 mt-2 space-y-1">
            {listItems.map((item, i) => (
              <li key={`item-end-${i}`}>{item}</li>
            ))}
          </ol>
        );
      }
      
      return formattedParts;
    }
    
    // Simple line breaks
    return content.split("\n").map((line, i) => 
      line ? <p key={i} className={i > 0 ? "mt-2" : ""}>{line}</p> : null
    );
  };

  return (
    <div className={cn("flex", isUser && "justify-end")}>
      <div
        className={cn(
          "py-3 px-4 max-w-[85%] shadow-sm rounded-2xl",
          isUser
            ? "bg-primary text-white rounded-tr-sm"
            : "bg-white rounded-tl-sm border border-neutral-200"
        )}
      >
        {formatContent(message.content)}
      </div>
    </div>
  );
};

export default MessageItem;
