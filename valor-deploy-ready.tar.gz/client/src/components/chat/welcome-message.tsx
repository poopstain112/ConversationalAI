import { FC } from "react";

const WelcomeMessage: FC = () => {
  return (
    <div className="flex-1 flex items-center justify-center py-10">
      <div className="text-center max-w-md">
        <div className="bg-gradient-to-r from-primary to-purple-600 w-16 h-16 rounded-full mx-auto flex items-center justify-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="28"
            height="28"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-white"
          >
            <path d="M7 10v12" />
            <path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z" />
          </svg>
        </div>
        <h2 className="mt-6 text-2xl font-semibold text-neutral-800">Welcome to Valor AI</h2>
        <p className="mt-3 text-neutral-600">
          Your AI assistant powered by GPT-4o. Ask me anything, and I'll do my best to help you.
        </p>
      </div>
    </div>
  );
};

export default WelcomeMessage;
