import React from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { BrainCircuit, Home, Layers, Printer, Eye, Settings, FileUp } from "lucide-react";

export function Navigation() {
  const [location] = useLocation();

  return (
    <header className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 max-w-screen-2xl items-center">
        <div className="flex items-center gap-2 mr-4">
          <BrainCircuit className="h-6 w-6 text-primary" />
          <span className="font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            Valor AI
          </span>
        </div>
        <nav className="flex-1 flex items-center space-x-2 text-sm">
          <Link href="/">
            <Button 
              variant={location === "/" ? "default" : "ghost"} 
              size="sm"
              className="gap-1"
            >
              <Home className="h-4 w-4" />
              Home
            </Button>
          </Link>
          <Link href="/demo">
            <Button 
              variant={location === "/demo" ? "default" : "ghost"} 
              size="sm"
              className="gap-1"
            >
              <Layers className="h-4 w-4" />
              Demo
            </Button>
          </Link>
          <Link href="/gcode">
            <Button 
              variant={location === "/gcode" ? "default" : "ghost"} 
              size="sm"
              className="gap-1"
            >
              <Printer className="h-4 w-4" />
              G-code
            </Button>
          </Link>
          <Link href="/vision">
            <Button 
              variant={location === "/vision" ? "default" : "ghost"} 
              size="sm"
              className="gap-1"
            >
              <Eye className="h-4 w-4" />
              Vision
            </Button>
          </Link>
          
          {/* Right-aligned items */}
          <div className="flex-1 flex justify-end space-x-2">
            <Link href="/settings">
              <Button 
                variant={location === "/settings" ? "default" : "ghost"} 
                size="sm"
                className="gap-1"
              >
                <Settings className="h-4 w-4" />
                Settings
              </Button>
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
}