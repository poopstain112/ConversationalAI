import { AskRequest, AskResponse, Conversation } from "@/types";
import { apiRequest } from "./queryClient";

// API functions for chat operations
export const chatApi = {
  // Get conversation history for a user
  async getConversation(userId: string = "default"): Promise<Conversation> {
    const response = await fetch(`/api/conversation/${userId}`, {
      credentials: "include",
    });
    
    if (!response.ok) {
      const error = await response.text();
      throw new Error(error || response.statusText);
    }
    
    return response.json();
  },
  
  // Send a message and get AI response
  async sendMessage(data: AskRequest): Promise<AskResponse> {
    const response = await apiRequest("POST", "/api/ask", data);
    return response.json();
  },
  
  // Clear conversation history for a user
  async clearConversation(userId: string = "default"): Promise<void> {
    const response = await apiRequest("POST", `/api/conversation/${userId}/clear`);
    return response.json();
  }
};
