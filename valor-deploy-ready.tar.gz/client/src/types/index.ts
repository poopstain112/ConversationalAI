export interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export interface Conversation {
  userId: string;
  messages: Message[];
}

export interface AskRequest {
  user: string;
  message: string;
}

export interface AskResponse {
  reply: string;
}

export interface ApiError {
  error: string;
}
