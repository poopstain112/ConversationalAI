import { useState, useEffect, useCallback } from 'react';

export type BatteryMode = 'normal' | 'saving';

interface BatterySaverOptions {
  initialMode?: BatteryMode;
  savingModeFrameRate?: number; // Target FPS in saving mode
  normalModeFrameRate?: number; // Target FPS in normal mode
  lowBatteryThreshold?: number; // Percentage (0-100) to consider as low battery
  autoEnableSavingMode?: boolean; // Automatically enable saving mode on low battery
}

interface BatterySaverHook {
  batteryMode: BatteryMode;
  setBatteryMode: (mode: BatteryMode) => void;
  batteryLevel: number | null;
  isCharging: boolean | null;
  hasBatteryInfo: boolean;
  timeRemaining: number | null; // in minutes
  isLowBattery: boolean;
  supportsFps: boolean;
  currentFrameRate: number;
  setProcessingCallback: (cb: (() => void) | null) => void; // For advanced frame skipping
}

export function useBatterySaver({
  initialMode = 'normal',
  savingModeFrameRate = 15,
  normalModeFrameRate = 30,
  lowBatteryThreshold = 20,
  autoEnableSavingMode = true,
}: BatterySaverOptions = {}): BatterySaverHook {
  const [batteryMode, setBatteryMode] = useState<BatteryMode>(initialMode);
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [isCharging, setIsCharging] = useState<boolean | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<number | null>(null);
  const [isLowBattery, setIsLowBattery] = useState(false);
  const [supportsFps, setSupportsFps] = useState(true);
  const [processingCallback, setProcessingCallback] = useState<(() => void) | null>(null);
  
  // Calculate current frame rate based on mode
  const currentFrameRate = batteryMode === 'saving' ? savingModeFrameRate : normalModeFrameRate;
  
  // Initialize and track battery status
  useEffect(() => {
    // Check if the Battery API is supported
    if (!('getBattery' in navigator)) {
      console.log('Battery API not supported in this browser');
      setSupportsFps(true); // Still support FPS throttling even without battery info
      return;
    }
    
    // Access battery information
    const setupBattery = async () => {
      try {
        // @ts-ignore - TypeScript doesn't know about the getBattery method
        const battery = await navigator.getBattery();
        
        // Initial update
        updateBatteryInfo(battery);
        
        // Listen for battery changes
        battery.addEventListener('chargingchange', () => updateBatteryInfo(battery));
        battery.addEventListener('levelchange', () => updateBatteryInfo(battery));
        battery.addEventListener('dischargingtimechange', () => updateBatteryInfo(battery));
        
        // Cleanup event listeners
        return () => {
          battery.removeEventListener('chargingchange', () => updateBatteryInfo(battery));
          battery.removeEventListener('levelchange', () => updateBatteryInfo(battery));
          battery.removeEventListener('dischargingtimechange', () => updateBatteryInfo(battery));
        };
      } catch (error) {
        console.error('Error accessing battery information:', error);
      }
    };
    
    setupBattery();
  }, []);
  
  // Update battery information
  const updateBatteryInfo = (battery: any) => {
    setBatteryLevel(battery.level * 100);
    setIsCharging(battery.charging);
    
    // Calculate time remaining in minutes (only relevant when not charging)
    if (!battery.charging && battery.dischargingTime !== Infinity) {
      setTimeRemaining(Math.floor(battery.dischargingTime / 60));
    } else {
      setTimeRemaining(null);
    }
    
    // Check if battery level is low
    const isLow = battery.level * 100 <= lowBatteryThreshold;
    setIsLowBattery(isLow);
    
    // Auto-enable battery saving mode if battery is low and not charging
    if (isLow && !battery.charging && autoEnableSavingMode) {
      setBatteryMode('saving');
    }
  };
  
  // Frame rate control using requestAnimationFrame throttling
  useEffect(() => {
    if (!supportsFps) return;
    
    let lastFrameTime = 0;
    let animationFrameId: number | null = null;
    const targetFrameInterval = 1000 / currentFrameRate;
    
    const frameLoop = (timestamp: number) => {
      animationFrameId = requestAnimationFrame(frameLoop);
      
      const elapsed = timestamp - lastFrameTime;
      
      // Only process frames at the target rate
      if (elapsed >= targetFrameInterval) {
        lastFrameTime = timestamp - (elapsed % targetFrameInterval);
        
        // Execute callback if provided
        if (processingCallback) {
          processingCallback();
        }
      }
    };
    
    // Start the animation frame loop
    animationFrameId = requestAnimationFrame(frameLoop);
    
    // Cleanup function
    return () => {
      if (animationFrameId !== null) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [currentFrameRate, processingCallback, supportsFps]);
  
  // Detect when page becomes hidden/visible to save battery when in the background
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden && batteryMode === 'normal') {
        // Store the previous mode before auto-switching to save battery
        localStorage.setItem('previous_battery_mode', batteryMode);
        setBatteryMode('saving');
      } else if (!document.hidden && localStorage.getItem('previous_battery_mode') === 'normal') {
        // Restore previous mode when page becomes visible again
        setBatteryMode('normal');
        localStorage.removeItem('previous_battery_mode');
      }
    };
    
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [batteryMode]);
  
  return {
    batteryMode,
    setBatteryMode,
    batteryLevel,
    isCharging,
    hasBatteryInfo: batteryLevel !== null,
    timeRemaining,
    isLowBattery,
    supportsFps,
    currentFrameRate,
    setProcessingCallback
  };
}