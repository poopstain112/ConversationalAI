import { useState, useEffect, useCallback, useRef } from 'react';

interface VoiceCommandOptions {
  commands: VoiceCommand[];
  enabledByDefault?: boolean;
  language?: string;
  noiseThreshold?: number; // 0-1 value for sensitivity
  requiredConfidence?: number; // 0-1 value for recognition confidence
  debug?: boolean;
}

export interface VoiceCommand {
  phrase: string;
  aliases?: string[];
  action: () => void;
  description?: string;
  category?: string;
}

export interface VoiceRecognitionState {
  isEnabled: boolean;
  isListening: boolean;
  lastCommand: string | null;
  lastResult: string | null;
  error: string | null;
  toggleVoiceRecognition: () => void;
  startListening: () => void;
  stopListening: () => void;
  availableCommands: VoiceCommand[];
  isSupported: boolean;
}

export function useVoiceCommands({
  commands,
  enabledByDefault = false,
  language = 'en-US',
  noiseThreshold = 0.1,
  requiredConfidence = 0.7,
  debug = false
}: VoiceCommandOptions): VoiceRecognitionState {
  const [isEnabled, setIsEnabled] = useState(enabledByDefault);
  const [isListening, setIsListening] = useState(false);
  const [lastCommand, setLastCommand] = useState<string | null>(null);
  const [lastResult, setLastResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isSupported, setIsSupported] = useState(false);
  
  // Use refs for values that might change during the lifetime of speech recognition
  const recognitionRef = useRef<any>(null);
  const commandsRef = useRef(commands);
  commandsRef.current = commands; // Keep ref updated
  
  // Initialize speech recognition on mount
  useEffect(() => {
    const checkSpeechRecognitionSupport = () => {
      if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
        return true;
      }
      return false;
    };
    
    setIsSupported(checkSpeechRecognitionSupport());
    
    if (checkSpeechRecognitionSupport()) {
      // Initialize recognition
      const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      
      // Configure recognition
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = language;
      
      // Set up event handlers
      recognition.onstart = () => {
        setIsListening(true);
        if (debug) console.log('Voice recognition started');
      };
      
      recognition.onend = () => {
        setIsListening(false);
        if (debug) console.log('Voice recognition ended');
        
        // Restart if still enabled
        if (isEnabled) {
          setTimeout(() => {
            if (isEnabled && recognitionRef.current) {
              try {
                recognitionRef.current.start();
              } catch (e) {
                if (debug) console.error('Error restarting recognition:', e);
              }
            }
          }, 500);
        }
      };
      
      recognition.onerror = (event: any) => {
        const errorMessage = `Recognition error: ${event.error}`;
        setError(errorMessage);
        if (debug) console.error(errorMessage);
        
        // Handle aborted errors differently - these are often just timeouts
        if (event.error !== 'aborted') {
          setIsEnabled(false);
        }
      };
      
      recognition.onresult = (event: any) => {
        // Get the most recent result
        const result = event.results[event.results.length - 1];
        const transcript = result[0].transcript.trim().toLowerCase();
        const confidence = result[0].confidence;
        
        // Process interim results
        if (!result.isFinal) {
          if (debug) console.log(`Interim result: ${transcript} (${confidence})`);
          return;
        }
        
        // Process final results
        setLastResult(transcript);
        if (debug) console.log(`Final result: ${transcript} (${confidence})`);
        
        // Check if this is a valid command with sufficient confidence
        if (confidence < requiredConfidence) {
          if (debug) console.log(`Confidence too low (${confidence}), ignoring`);
          return;
        }
        
        // Check against commands
        const recognizedCommand = findMatchingCommand(transcript, commandsRef.current);
        if (recognizedCommand) {
          setLastCommand(recognizedCommand.phrase);
          if (debug) console.log(`Command recognized: ${recognizedCommand.phrase}`);
          
          // Execute the command's action
          recognizedCommand.action();
          
          // Provide feedback (optional in a real app)
          provideFeedback(recognizedCommand.phrase);
        }
      };
      
      recognitionRef.current = recognition;
      
      // Start listening if enabled by default
      if (isEnabled) {
        try {
          recognition.start();
        } catch (e) {
          if (debug) console.error('Error starting recognition:', e);
        }
      }
      
      // Cleanup on unmount
      return () => {
        if (recognitionRef.current) {
          try {
            recognitionRef.current.stop();
          } catch (e) {
            // Ignore errors on cleanup
          }
        }
      };
    } else {
      setError('Speech recognition is not supported in this browser');
    }
  }, [language, isEnabled, debug, requiredConfidence]);
  
  // Find a matching command from a transcript
  const findMatchingCommand = (transcript: string, commands: VoiceCommand[]): VoiceCommand | null => {
    for (const command of commands) {
      // Check the main phrase
      if (transcript.includes(command.phrase.toLowerCase())) {
        return command;
      }
      
      // Check aliases
      if (command.aliases) {
        for (const alias of command.aliases) {
          if (transcript.includes(alias.toLowerCase())) {
            return command;
          }
        }
      }
    }
    return null;
  };
  
  // Provide audio feedback for recognized commands
  const provideFeedback = (command: string) => {
    try {
      // Simple beep for now, could be more sophisticated
      const context = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = context.createOscillator();
      const gainNode = context.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(context.destination);
      
      oscillator.type = 'sine';
      oscillator.frequency.value = 800;
      gainNode.gain.value = 0.1;
      
      oscillator.start(context.currentTime);
      oscillator.stop(context.currentTime + 0.1);
    } catch (e) {
      // Ignore errors in feedback
    }
  };
  
  // Toggle voice recognition on/off
  const toggleVoiceRecognition = useCallback(() => {
    setIsEnabled(prev => {
      const newState = !prev;
      
      // Start or stop recognition based on new state
      if (newState) {
        startListeningImpl();
      } else {
        stopListeningImpl();
      }
      
      return newState;
    });
  }, []);
  
  // Start listening
  const startListeningImpl = useCallback(() => {
    if (!isSupported) {
      setError('Speech recognition is not supported in this browser');
      return;
    }
    
    if (!recognitionRef.current) {
      setError('Speech recognition not initialized');
      return;
    }
    
    try {
      recognitionRef.current.start();
      setError(null);
    } catch (e) {
      setError(`Failed to start speech recognition: ${(e as Error).message}`);
    }
  }, [isSupported]);
  
  const startListening = useCallback(() => {
    setIsEnabled(true);
    startListeningImpl();
  }, [startListeningImpl]);
  
  // Stop listening
  const stopListeningImpl = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        if (debug) console.error('Error stopping recognition:', e);
      }
    }
  }, [debug]);
  
  const stopListening = useCallback(() => {
    setIsEnabled(false);
    stopListeningImpl();
  }, [stopListeningImpl]);
  
  return {
    isEnabled,
    isListening,
    lastCommand,
    lastResult,
    error,
    toggleVoiceRecognition,
    startListening,
    stopListening,
    availableCommands: commands,
    isSupported
  };
}