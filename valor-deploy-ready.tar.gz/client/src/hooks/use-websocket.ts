import { useState, useEffect, useRef, useCallback } from 'react';

type WebSocketHookOptions = {
  onMessage?: (data: any) => void;
  onOpen?: () => void;
  onClose?: () => void;
  onError?: (error: Event) => void;
  reconnectInterval?: number;
  reconnectAttempts?: number;
  automaticOpen?: boolean;
};

type WebSocketStatus = 'CONNECTING' | 'OPEN' | 'CLOSING' | 'CLOSED' | 'RECONNECTING';

export const useWebSocket = (options: WebSocketHookOptions = {}) => {
  const [status, setStatus] = useState<WebSocketStatus>('CLOSED');
  const [lastMessage, setLastMessage] = useState<any>(null);
  const webSocketRef = useRef<WebSocket | null>(null);
  const reconnectCount = useRef(0);
  const reconnectTimerRef = useRef<number | null>(null);
  const heartbeatTimerRef = useRef<number | null>(null);

  const {
    onMessage,
    onOpen,
    onClose,
    onError,
    reconnectInterval = 5000,
    reconnectAttempts = 10,
    automaticOpen = true
  } = options;

  // Connect to the WebSocket server
  const connect = useCallback(() => {
    if (webSocketRef.current?.readyState === WebSocket.OPEN) {
      console.log('WebSocket already connected');
      return;
    }

    // Close any existing connection
    if (webSocketRef.current) {
      webSocketRef.current.close();
    }

    try {
      // Create WebSocket connection with the correct protocol
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      console.log('Connecting to WebSocket at:', wsUrl);
      setStatus('CONNECTING');
      
      const ws = new WebSocket(wsUrl);
      webSocketRef.current = ws;

      // Set up event handlers
      ws.onopen = () => {
        console.log('WebSocket connection established');
        setStatus('OPEN');
        reconnectCount.current = 0;
        if (onOpen) onOpen();
        startHeartbeat();
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          console.log('WebSocket message received:', data);
          setLastMessage(data);
          if (onMessage) onMessage(data);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };

      ws.onclose = (event) => {
        console.log('WebSocket connection closed:', event.code, event.reason);
        setStatus('CLOSED');
        stopHeartbeat();
        
        if (onClose) onClose();
        
        // Attempt to reconnect if not manually closed
        if (event.code !== 1000) {
          attemptReconnect();
        }
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        if (onError) onError(error);
        // Don't attempt reconnect here, wait for onclose which will fire after an error
      };
    } catch (error) {
      console.error('WebSocket connection error:', error);
      setStatus('CLOSED');
      attemptReconnect();
    }
  }, [onMessage, onOpen, onClose, onError, reconnectInterval, reconnectAttempts]);

  // Send a message through the WebSocket
  const sendMessage = useCallback((data: any) => {
    if (webSocketRef.current?.readyState === WebSocket.OPEN) {
      webSocketRef.current.send(JSON.stringify(data));
      return true;
    } else {
      console.warn('WebSocket not connected, cannot send message');
      return false;
    }
  }, []);

  // Attempt to reconnect to the WebSocket server
  const attemptReconnect = useCallback(() => {
    if (reconnectCount.current >= reconnectAttempts) {
      console.log('Maximum reconnection attempts reached');
      return;
    }

    if (reconnectTimerRef.current) {
      window.clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }

    setStatus('RECONNECTING');
    reconnectCount.current += 1;
    console.log(`Attempting to reconnect (${reconnectCount.current}/${reconnectAttempts})...`);
    
    // Exponential backoff with jitter
    const delay = Math.min(
      reconnectInterval * Math.pow(1.5, reconnectCount.current - 1),
      30000
    ) * (0.9 + Math.random() * 0.2);
    
    reconnectTimerRef.current = window.setTimeout(() => {
      connect();
    }, delay);
  }, [connect, reconnectInterval, reconnectAttempts]);

  // Start heartbeat to keep the connection alive
  const startHeartbeat = useCallback(() => {
    if (heartbeatTimerRef.current) {
      window.clearInterval(heartbeatTimerRef.current);
    }
    
    heartbeatTimerRef.current = window.setInterval(() => {
      if (webSocketRef.current?.readyState === WebSocket.OPEN) {
        webSocketRef.current.send(JSON.stringify({ type: 'ping' }));
      }
    }, 30000); // Send a ping every 30 seconds
  }, []);

  // Stop the heartbeat
  const stopHeartbeat = useCallback(() => {
    if (heartbeatTimerRef.current) {
      window.clearInterval(heartbeatTimerRef.current);
      heartbeatTimerRef.current = null;
    }
  }, []);

  // Manually disconnect from the WebSocket
  const disconnect = useCallback(() => {
    if (webSocketRef.current) {
      webSocketRef.current.close(1000, 'Client disconnected');
      webSocketRef.current = null;
    }
    
    setStatus('CLOSED');
    stopHeartbeat();
    
    if (reconnectTimerRef.current) {
      window.clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
  }, [stopHeartbeat]);

  // Trigger a proactive message for testing/demo
  const triggerProactiveMessage = useCallback((message: string) => {
    return sendMessage({
      type: 'trigger_proactive',
      message
    });
  }, [sendMessage]);
  
  // Check if the WebSocket is connected
  const isConnected = status === 'OPEN';

  // Automatically connect when the component mounts
  useEffect(() => {
    if (automaticOpen) {
      connect();
    }
    
    // Clean up on unmount
    return () => {
      disconnect();
    };
  }, [connect, disconnect, automaticOpen]);

  return {
    status,
    lastMessage,
    connect,
    disconnect,
    sendMessage,
    isConnected,
    triggerProactiveMessage
  };
};