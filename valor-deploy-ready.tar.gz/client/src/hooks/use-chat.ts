import { useState, useCallback, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { chatApi } from "@/lib/api";
import { Conversation, Message } from "@/types";
import { useToast } from "@/hooks/use-toast";

export function useChat(userId: string = "default") {
  const [isTyping, setIsTyping] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Get conversation history
  const {
    data: conversation,
    isLoading,
    isError,
    error
  } = useQuery({
    queryKey: ["/api/conversation", userId],
    queryFn: () => chatApi.getConversation(userId),
  });
  
  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: chatApi.sendMessage,
    onMutate: async ({ message }) => {
      // Optimistically update UI
      await queryClient.cancelQueries({ queryKey: ["/api/conversation", userId] });
      
      // Get current conversation
      const previousConversation = queryClient.getQueryData<Conversation>(["/api/conversation", userId]);
      
      if (previousConversation) {
        // Add user message immediately
        const newConversation = {
          ...previousConversation,
          messages: [
            ...previousConversation.messages,
            { role: "user", content: message } as Message
          ]
        };
        
        queryClient.setQueryData(["/api/conversation", userId], newConversation);
      }
      
      setIsTyping(true);
      return { previousConversation };
    },
    onSuccess: (data, variables) => {
      // When we get a response, update with the AI message
      const currentConversation = queryClient.getQueryData<Conversation>(["/api/conversation", userId]);
      
      if (currentConversation) {
        const newConversation = {
          ...currentConversation,
          messages: [
            ...currentConversation.messages,
            { role: "assistant", content: data.reply } as Message
          ]
        };
        
        queryClient.setQueryData(["/api/conversation", userId], newConversation);
      }
      
      setIsTyping(false);
    },
    onError: (err: any, variables, context) => {
      // Handle quota error specially - don't revert in this case as we saved a fallback message
      const isQuotaError = err.response?.status === 429 || 
                          (err.message && err.message.includes('quota')) ||
                          (err.response?.data?.isQuotaError);
      
      if (!isQuotaError && context?.previousConversation) {
        // Only revert for non-quota errors
        queryClient.setQueryData(["/api/conversation", userId], context.previousConversation);
      }
      
      // Show appropriate error message
      toast({
        title: isQuotaError ? "API Quota Exceeded" : "Error",
        description: isQuotaError 
          ? "The OpenAI API quota has been exceeded. This typically happens with free accounts. Your message was still saved."
          : (err instanceof Error ? err.message : "Failed to send message"),
        variant: "destructive"
      });
      
      setIsTyping(false);
      
      // Always refresh the conversation data to get the fallback message for quota errors
      queryClient.invalidateQueries({ queryKey: ["/api/conversation", userId] });
    },
    onSettled: () => {
      // Refresh conversation data
      queryClient.invalidateQueries({ queryKey: ["/api/conversation", userId] });
    }
  });
  
  // Clear conversation mutation
  const clearConversationMutation = useMutation({
    mutationFn: () => chatApi.clearConversation(userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversation", userId] });
      toast({
        title: "Success",
        description: "Conversation history has been cleared",
      });
    },
    onError: (err) => {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to clear conversation",
        variant: "destructive"
      });
    }
  });
  
  // Send message handler
  const sendMessage = useCallback(
    (message: string) => {
      if (!message.trim()) return;
      
      sendMessageMutation.mutate({
        user: userId,
        message
      });
    },
    [userId, sendMessageMutation]
  );
  
  // Clear conversation handler
  const clearConversation = useCallback(() => {
    clearConversationMutation.mutate();
  }, [clearConversationMutation]);
  
  return {
    conversation: conversation || { userId, messages: [] },
    isLoading,
    isError,
    error,
    isTyping,
    sendMessage,
    clearConversation,
  };
}
