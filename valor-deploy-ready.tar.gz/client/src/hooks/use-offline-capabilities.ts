import { useState, useEffect, useCallback } from 'react';

interface OfflineCapabilitiesOptions {
  cacheDuration?: number; // How long to cache data in milliseconds
  syncInterval?: number; // How often to attempt syncing in milliseconds
  maxCacheSize?: number; // Maximum number of items to cache
  debugMode?: boolean; // Enable debug logging
}

interface CachedItem<T> {
  data: T;
  timestamp: number;
  syncStatus: 'synced' | 'pending' | 'failed';
  id: string;
  attemptCount: number;
}

interface OfflineCapabilities {
  isOnline: boolean;
  isSyncing: boolean;
  pendingItems: number;
  cacheItem: <T>(item: T, id?: string) => string;
  getCachedItem: <T>(id: string) => T | null;
  syncNow: () => Promise<boolean>;
  clearCache: () => void;
  lastSyncAttempt: Date | null;
  serviceWorkerSupported: boolean;
  serviceWorkerActive: boolean;
}

// Helper function to generate a unique ID
const generateId = () => {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
};

export function useOfflineCapabilities({
  cacheDuration = 7 * 24 * 60 * 60 * 1000, // 1 week default
  syncInterval = 60 * 1000, // 1 minute default
  maxCacheSize = 100,
  debugMode = false
}: OfflineCapabilitiesOptions = {}): OfflineCapabilities {
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [pendingItems, setPendingItems] = useState<number>(0);
  const [lastSyncAttempt, setLastSyncAttempt] = useState<Date | null>(null);
  const [serviceWorkerSupported, setServiceWorkerSupported] = useState<boolean>(false);
  const [serviceWorkerActive, setServiceWorkerActive] = useState<boolean>(false);
  
  // Initialize service worker status
  useEffect(() => {
    // Check if Service Worker API is supported
    const isSupported = 'serviceWorker' in navigator;
    setServiceWorkerSupported(isSupported);
    
    if (isSupported) {
      // Check if there's an active service worker
      navigator.serviceWorker.ready.then(() => {
        setServiceWorkerActive(true);
        if (debugMode) console.log('Service worker is active');
      }).catch(err => {
        if (debugMode) console.error('Service worker ready error:', err);
      });
      
      // Listen for service worker controller changes
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        setServiceWorkerActive(true);
        if (debugMode) console.log('Service worker controller changed');
      });
    }
  }, [debugMode]);
  
  // Network status monitoring
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      if (debugMode) console.log('Network status: Online');
      // Trigger a sync when coming back online
      syncCachedData();
    };
    
    const handleOffline = () => {
      setIsOnline(false);
      if (debugMode) console.log('Network status: Offline');
    };
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [debugMode]);
  
  // Periodic sync attempt
  useEffect(() => {
    const interval = setInterval(() => {
      if (isOnline && pendingItems > 0) {
        syncCachedData();
      }
    }, syncInterval);
    
    return () => clearInterval(interval);
  }, [isOnline, pendingItems, syncInterval]);
  
  // Cache management functions
  const loadCache = useCallback(() => {
    try {
      const cacheData = localStorage.getItem('offline_cache');
      if (cacheData) {
        const cache = JSON.parse(cacheData) as Record<string, CachedItem<any>>;
        
        // Count pending items
        let pending = 0;
        const now = Date.now();
        
        Object.values(cache).forEach(item => {
          // Check if cache item is still valid (not expired)
          if (now - item.timestamp <= cacheDuration) {
            if (item.syncStatus === 'pending') {
              pending++;
            }
          }
        });
        
        setPendingItems(pending);
        return cache;
      }
    } catch (error) {
      if (debugMode) console.error('Error loading cache:', error);
    }
    
    return {};
  }, [cacheDuration, debugMode]);
  
  const saveCache = useCallback((cache: Record<string, CachedItem<any>>) => {
    try {
      localStorage.setItem('offline_cache', JSON.stringify(cache));
    } catch (error) {
      if (debugMode) console.error('Error saving cache:', error);
      
      // If storage is full, try to clear older items
      if (error instanceof DOMException && error.name === 'QuotaExceededError') {
        pruneCache();
      }
    }
  }, [debugMode]);
  
  // Ensure we don't exceed storage limits
  const pruneCache = useCallback(() => {
    try {
      const cache = loadCache();
      const items = Object.entries(cache);
      
      // Sort by timestamp (oldest first)
      items.sort((a, b) => a[1].timestamp - b[1].timestamp);
      
      // Remove oldest items until we're under the limit
      if (items.length > maxCacheSize) {
        const newCache = items
          .slice(-maxCacheSize) // Keep only the newest maxCacheSize items
          .reduce((obj, [key, value]) => ({ ...obj, [key]: value }), {});
        
        saveCache(newCache);
        
        // Update pending count
        const pending = Object.values(newCache).filter(item => item.syncStatus === 'pending').length;
        setPendingItems(pending);
        
        if (debugMode) console.log(`Pruned cache to ${maxCacheSize} items`);
      }
    } catch (error) {
      if (debugMode) console.error('Error pruning cache:', error);
    }
  }, [loadCache, saveCache, maxCacheSize, debugMode]);
  
  // Add an item to the cache
  const cacheItem = useCallback(<T>(item: T, id?: string): string => {
    const cache = loadCache();
    const itemId = id || generateId();
    
    cache[itemId] = {
      data: item,
      timestamp: Date.now(),
      syncStatus: isOnline ? 'synced' : 'pending',
      id: itemId,
      attemptCount: 0
    };
    
    saveCache(cache);
    
    // Update pending count if needed
    if (!isOnline) {
      setPendingItems(prev => prev + 1);
    }
    
    return itemId;
  }, [loadCache, saveCache, isOnline]);
  
  // Retrieve an item from the cache
  const getCachedItem = useCallback(<T>(id: string): T | null => {
    try {
      const cache = loadCache();
      const item = cache[id];
      
      if (item) {
        // Check if the item is expired
        if (Date.now() - item.timestamp > cacheDuration) {
          if (debugMode) console.log(`Item ${id} is expired`);
          return null;
        }
        
        return item.data as T;
      }
    } catch (error) {
      if (debugMode) console.error('Error getting cached item:', error);
    }
    
    return null;
  }, [loadCache, cacheDuration, debugMode]);
  
  // Sync cached data with the server
  const syncCachedData = useCallback(async (): Promise<boolean> => {
    if (!isOnline || isSyncing) {
      return false;
    }
    
    setIsSyncing(true);
    setLastSyncAttempt(new Date());
    
    try {
      const cache = loadCache();
      let successful = true;
      const pendingItems = Object.entries(cache).filter(([_, item]) => item.syncStatus === 'pending');
      
      if (pendingItems.length === 0) {
        if (debugMode) console.log('No pending items to sync');
        setIsSyncing(false);
        return true;
      }
      
      if (debugMode) console.log(`Attempting to sync ${pendingItems.length} items`);
      
      // Process each pending item
      for (const [id, item] of pendingItems) {
        try {
          // This is where you would normally make API calls to sync with the server
          // For now, we'll just simulate successful syncing
          const syncResult = await simulateSyncApiCall(item.data);
          
          if (syncResult) {
            // Update item status to synced
            cache[id] = {
              ...item,
              syncStatus: 'synced',
              timestamp: Date.now() // Update timestamp
            };
          } else {
            // Increment attempt count
            cache[id] = {
              ...item,
              attemptCount: item.attemptCount + 1,
              syncStatus: item.attemptCount >= 3 ? 'failed' : 'pending'
            };
            
            successful = false;
          }
        } catch (error) {
          if (debugMode) console.error(`Error syncing item ${id}:`, error);
          
          // Increment attempt count
          cache[id] = {
            ...item,
            attemptCount: item.attemptCount + 1,
            syncStatus: item.attemptCount >= 3 ? 'failed' : 'pending'
          };
          
          successful = false;
        }
      }
      
      // Save updated cache
      saveCache(cache);
      
      // Count remaining pending items
      const remaining = Object.values(cache).filter(item => item.syncStatus === 'pending').length;
      setPendingItems(remaining);
      
      if (debugMode) {
        console.log(`Sync completed. Success: ${successful}. Remaining pending: ${remaining}`);
      }
      
      return successful;
    } catch (error) {
      if (debugMode) console.error('Error during sync:', error);
      return false;
    } finally {
      setIsSyncing(false);
    }
  }, [isOnline, isSyncing, loadCache, saveCache, debugMode]);
  
  // Simulated API call (replace with real implementation)
  const simulateSyncApiCall = async (data: any): Promise<boolean> => {
    // Simulate network request with 80% success rate
    await new Promise(resolve => setTimeout(resolve, 500));
    return Math.random() < 0.8;
  };
  
  // Clear the entire cache
  const clearCache = useCallback(() => {
    try {
      localStorage.removeItem('offline_cache');
      setPendingItems(0);
      if (debugMode) console.log('Cache cleared');
    } catch (error) {
      if (debugMode) console.error('Error clearing cache:', error);
    }
  }, [debugMode]);
  
  // Manually trigger sync
  const syncNow = useCallback(async (): Promise<boolean> => {
    return await syncCachedData();
  }, [syncCachedData]);
  
  // Initial load of pending items count
  useEffect(() => {
    loadCache();
  }, [loadCache]);
  
  return {
    isOnline,
    isSyncing,
    pendingItems,
    cacheItem,
    getCachedItem,
    syncNow,
    clearCache,
    lastSyncAttempt,
    serviceWorkerSupported,
    serviceWorkerActive
  };
}