// Fix for OpenAI typings
declare module 'openai' {
  interface ChatCompletionMessageParam {
    role: string;
    content: string | null | Array<any>;
    name?: string;
  }
}