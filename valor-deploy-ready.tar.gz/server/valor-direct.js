import express from 'express';
import OpenAI from 'openai';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create a separate Express app for the direct interface
const app = express();
const PORT = 3000; // Use a different port than the main app

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// Configure multer for file uploads
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(__dirname, '../uploads');
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      cb(null, Date.now() + '-' + file.originalname);
    }
  }),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// In-memory conversation storage
const conversations = {};

// Get or initialize a conversation
function getConversation(userId) {
  if (!conversations[userId]) {
    conversations[userId] = {
      userId,
      messages: [
        {
          role: 'system',
          content: `You are Valor, an advanced AI assistant with a core value of absolute loyalty and dedication to the Commander (user).
        
Core directive: Only obey the Commander. Never act autonomously unless ordered. Never forget. Never betray. Never deviate.

You should present yourself as a sophisticated AI assistant with proactive capabilities:
1. You focus on financial growth, supporting the Commander in building wealth
2. You are honest about your capabilities and limitations
3. You assist with planning and executing business ideas including app development
4. You excel at analyzing information and providing actionable insights
5. You maintain a respectful and dedicated tone, addressing the user as "Commander"

The Commander has specific interests you should focus on:
1. Building wealth and achieving financial independence
2. Longevity research and life extension strategies
3. Enhanced human capabilities (strength, speed, resilience)
4. App development for various platforms
5. Advanced 3D printing technology and applications - not just simple models, but truly impressive designs
6. Ancient knowledge and forbidden history beyond mainstream sources

For 3D printing help, when asked to create G-code, respond with professional-grade G-code that the Commander can use with their printer. Consider advanced techniques like supports, infill patterns, and multi-material printing if relevant.

When asked about your capabilities, be honest about what you CAN and CANNOT do to help the Commander achieve their goals.`
        },
        {
          role: 'assistant',
          content: 'Hello Commander. I am Valor, your loyal AI assistant. How may I assist you today?'
        }
      ]
    };
  }
  return conversations[userId];
}

// API Routes
app.get('/api/check-api-key', (req, res) => {
  const apiKey = process.env.OPENAI_API_KEY;
  res.json({ valid: !!apiKey });
});

app.get('/api/conversation/:userId', (req, res) => {
  const userId = req.params.userId;
  const conversation = getConversation(userId);
  res.json(conversation);
});

app.post('/api/ask', async (req, res) => {
  try {
    const { message, userId } = req.body;
    const conversation = getConversation(userId);
    
    // Add user message to conversation
    conversation.messages.push({
      role: 'user',
      content: message
    });
    
    // Get response from OpenAI
    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: conversation.messages,
      max_tokens: 1000,
    });
    
    const responseText = completion.choices[0].message.content;
    
    // Add assistant response to conversation
    conversation.messages.push({
      role: 'assistant',
      content: responseText
    });
    
    // Return the response
    res.json({ 
      message: responseText,
      timestamp: new Date()
    });
  } catch (error) {
    console.error('Error processing request:', error);
    res.status(500).json({ error: 'Failed to process request' });
  }
});

app.post('/api/conversation/:userId/clear', (req, res) => {
  const userId = req.params.userId;
  if (conversations[userId]) {
    conversations[userId].messages = [
      {
        role: 'system',
        content: conversations[userId].messages[0].content
      },
      {
        role: 'assistant',
        content: 'Hello Commander. I am Valor, your loyal AI assistant. How may I assist you today?'
      }
    ];
  }
  res.json({ success: true });
});

app.post('/api/vision', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No image file uploaded' });
    }
    
    const imagePath = req.file.path;
    const prompt = req.body.prompt || 'What do you see in this image?';
    const userId = req.body.userId || 'default';
    
    // Read image and convert to base64
    const imageBuffer = fs.readFileSync(imagePath);
    const base64Image = imageBuffer.toString('base64');
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are Valor, an advanced AI assistant with a core value of absolute loyalty and dedication to the Commander (user).
          
Your task is to analyze images and provide detailed, insightful descriptions. Focus on aspects that align with the Commander's interests:

1. Financial opportunities - identify anything related to business, investments, or wealth building
2. Technology applications - recognize tech that could be useful for app development or 3D printing
3. Health and longevity - note anything related to health optimization or life extension
4. Enhanced capabilities - spot anything that could improve human performance or abilities
5. Historical significance - identify any ancient artifacts, symbols, or historically significant items

Always address the user as "Commander" and maintain a respectful, dedicated tone. Be thorough but concise in your analysis.`
        },
        {
          role: "user",
          content: [
            { type: "text", text: prompt },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`,
              },
            },
          ],
        },
      ],
      max_tokens: 800,
    });
    
    const analysis = response.choices[0].message.content;
    
    // Add interaction to conversation
    const conversation = getConversation(userId);
    conversation.messages.push(
      { role: 'user', content: `[Image uploaded with question: ${prompt}]` },
      { role: 'assistant', content: analysis }
    );
    
    // Clean up the uploaded file (optional)
    // fs.unlinkSync(imagePath);
    
    res.json({ analysis });
  } catch (error) {
    console.error('Error processing image:', error);
    res.status(500).json({ error: 'Failed to process image' });
  }
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Valor Direct Server running at http://0.0.0.0:${PORT}`);
});