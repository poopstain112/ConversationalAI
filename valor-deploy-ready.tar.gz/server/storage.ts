import { 
  messages, users, reminders, printModels, learningProgress, projects,
  type Message, type InsertMessage, type Conversation,
  type User, type InsertUser,
  type Reminder, type InsertReminder,
  type PrintModel, type InsertPrintModel,
  type LearningProgress, type InsertLearningProgress,
  type Project, type InsertProject
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Conversation operations
  getConversation(userId: string): Promise<Conversation>;
  saveMessage(message: InsertMessage): Promise<Message>;
  clearConversation(userId: string): Promise<void>;
  
  // Reminder operations
  createReminder(reminder: InsertReminder): Promise<Reminder>;
  getReminders(userId: number): Promise<Reminder[]>;
  getReminderById(id: number): Promise<Reminder | undefined>;
  updateReminder(id: number, data: Partial<InsertReminder>): Promise<Reminder | undefined>;
  deleteReminder(id: number): Promise<void>;
  getDueReminders(): Promise<Reminder[]>;
  
  // 3D Print operations
  createPrintModel(model: InsertPrintModel): Promise<PrintModel>;
  getPrintModels(userId: number): Promise<PrintModel[]>;
  getPrintModelById(id: number): Promise<PrintModel | undefined>;
  updatePrintModel(id: number, data: Partial<InsertPrintModel>): Promise<PrintModel | undefined>;
  deletePrintModel(id: number): Promise<void>;
  
  // Learning progress operations
  createLearningProgress(progress: InsertLearningProgress): Promise<LearningProgress>;
  getLearningProgress(userId: number): Promise<LearningProgress[]>;
  getLearningProgressById(id: number): Promise<LearningProgress | undefined>;
  updateLearningProgress(id: number, data: Partial<InsertLearningProgress>): Promise<LearningProgress | undefined>;
  deleteLearningProgress(id: number): Promise<void>;
  
  // Project operations
  createProject(project: InsertProject): Promise<Project>;
  getProjects(userId: number): Promise<Project[]>;
  getProjectById(id: number): Promise<Project | undefined>;
  updateProject(id: number, data: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<void>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  // Conversation operations
  async getConversation(userId: string): Promise<Conversation> {
    // Get all messages for this user, ordered by timestamp
    const messagesList = await db
      .select()
      .from(messages)
      .where(eq(messages.userId, userId))
      .orderBy(messages.timestamp);
    
    // Format into conversation structure
    return {
      userId,
      messages: messagesList.map(msg => ({
        role: msg.role as 'user' | 'assistant' | 'system',
        content: msg.content
      }))
    };
  }

  async saveMessage(message: InsertMessage): Promise<Message> {
    const result = await db.insert(messages).values(message).returning();
    return result[0];
  }

  async clearConversation(userId: string): Promise<void> {
    await db.delete(messages).where(eq(messages.userId, userId));
  }

  // Reminder operations
  async createReminder(reminder: InsertReminder): Promise<Reminder> {
    const result = await db.insert(reminders).values(reminder).returning();
    return result[0];
  }

  async getReminders(userId: number): Promise<Reminder[]> {
    return db
      .select()
      .from(reminders)
      .where(eq(reminders.userId, userId))
      .orderBy(desc(reminders.createdAt));
  }

  async getReminderById(id: number): Promise<Reminder | undefined> {
    const result = await db.select().from(reminders).where(eq(reminders.id, id));
    return result[0];
  }

  async updateReminder(id: number, data: Partial<InsertReminder>): Promise<Reminder | undefined> {
    const result = await db
      .update(reminders)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(reminders.id, id))
      .returning();
    return result[0];
  }

  async deleteReminder(id: number): Promise<void> {
    await db.delete(reminders).where(eq(reminders.id, id));
  }

  async getDueReminders(): Promise<Reminder[]> {
    const today = new Date();
    const dateString = today.toISOString().split('T')[0]; // Format as YYYY-MM-DD
    
    return db
      .select()
      .from(reminders)
      .where(
        and(
          eq(reminders.completed, false),
          eq(reminders.notified, false),
          eq(reminders.dueDate, dateString)
        )
      );
  }

  // 3D Print operations
  async createPrintModel(model: InsertPrintModel): Promise<PrintModel> {
    const result = await db.insert(printModels).values(model).returning();
    return result[0];
  }

  async getPrintModels(userId: number): Promise<PrintModel[]> {
    return db
      .select()
      .from(printModels)
      .where(eq(printModels.userId, userId))
      .orderBy(desc(printModels.createdAt));
  }

  async getPrintModelById(id: number): Promise<PrintModel | undefined> {
    const result = await db.select().from(printModels).where(eq(printModels.id, id));
    return result[0];
  }

  async updatePrintModel(id: number, data: Partial<InsertPrintModel>): Promise<PrintModel | undefined> {
    const result = await db
      .update(printModels)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(printModels.id, id))
      .returning();
    return result[0];
  }

  async deletePrintModel(id: number): Promise<void> {
    await db.delete(printModels).where(eq(printModels.id, id));
  }

  // Learning progress operations
  async createLearningProgress(progress: InsertLearningProgress): Promise<LearningProgress> {
    const result = await db.insert(learningProgress).values(progress).returning();
    return result[0];
  }

  async getLearningProgress(userId: number): Promise<LearningProgress[]> {
    return db
      .select()
      .from(learningProgress)
      .where(eq(learningProgress.userId, userId))
      .orderBy(desc(learningProgress.lastStudied));
  }

  async getLearningProgressById(id: number): Promise<LearningProgress | undefined> {
    const result = await db.select().from(learningProgress).where(eq(learningProgress.id, id));
    return result[0];
  }

  async updateLearningProgress(id: number, data: Partial<InsertLearningProgress>): Promise<LearningProgress | undefined> {
    const result = await db
      .update(learningProgress)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(learningProgress.id, id))
      .returning();
    return result[0];
  }

  async deleteLearningProgress(id: number): Promise<void> {
    await db.delete(learningProgress).where(eq(learningProgress.id, id));
  }

  // Project operations
  async createProject(project: InsertProject): Promise<Project> {
    const result = await db.insert(projects).values(project).returning();
    return result[0];
  }

  async getProjects(userId: number): Promise<Project[]> {
    return db
      .select()
      .from(projects)
      .where(eq(projects.userId, userId))
      .orderBy(desc(projects.createdAt));
  }

  async getProjectById(id: number): Promise<Project | undefined> {
    const result = await db.select().from(projects).where(eq(projects.id, id));
    return result[0];
  }

  async updateProject(id: number, data: Partial<InsertProject>): Promise<Project | undefined> {
    const result = await db
      .update(projects)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return result[0];
  }

  async deleteProject(id: number): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }
}

// Export a single instance to be used throughout the application
export const storage = new DatabaseStorage();
