/**
 * Mobile API endpoints for Valor AI
 * 
 * This module handles communication between the native mobile app
 * and the Valor server instance running on the user's personal server.
 */

import type { Express, Request, Response } from "express";
import { storage } from "./storage";
import jwt from "jsonwebtoken";
import { z } from "zod";
import OpenAI from "openai";
import { askMessageSchema } from "@shared/schema";
import { getChatCompletion, analyzeMessage } from "./openai";

// Schema for mobile device registration
const deviceRegistrationSchema = z.object({
  deviceId: z.string(),
  deviceName: z.string(),
  deviceType: z.enum(["ios", "android"]),
  fcmToken: z.string().optional(), // Firebase Cloud Messaging token for push notifications
  permissions: z.object({
    notifications: z.boolean(),
    camera: z.boolean(),
    microphone: z.boolean(),
    location: z.boolean(),
    background: z.boolean()
  })
});

// User session schema
const userSessionSchema = z.object({
  userId: z.string(),
  deviceId: z.string(),
  accessToken: z.string().optional()
});

// Type definitions based on schemas
type DeviceRegistration = z.infer<typeof deviceRegistrationSchema>;
type UserSession = z.infer<typeof userSessionSchema>;

// Environment variables for JWT
const JWT_SECRET = process.env.JWT_SECRET || "temp_secret_replace_in_production";
const JWT_EXPIRY = "7d"; // Token expires in 7 days

/**
 * Register mobile API routes for native app integration
 */
export function registerMobileApiRoutes(app: Express) {
  // === Authentication & Device Management ===

  // Register a new mobile device
  app.post("/api/mobile/register", async (req: Request, res: Response) => {
    try {
      const validatedData = deviceRegistrationSchema.parse(req.body);
      
      // Store device registration in database
      // This would be implemented in a real production system
      
      // Generate authentication token
      const token = jwt.sign(
        { 
          deviceId: validatedData.deviceId,
          userId: "default" // Replace with actual user ID in production
        }, 
        JWT_SECRET, 
        { expiresIn: JWT_EXPIRY }
      );
      
      res.status(201).json({ 
        success: true, 
        token,
        userId: "default", // Replace with actual user ID in production
        expiresIn: JWT_EXPIRY
      });
    } catch (error) {
      console.error("Error registering mobile device:", error);
      res.status(400).json({ error: "Invalid registration data" });
    }
  });
  
  // Validate authentication token
  app.post("/api/mobile/validate-token", async (req: Request, res: Response) => {
    try {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ error: "Token is required" });
      }
      
      // Verify the token
      jwt.verify(token, JWT_SECRET, (err: any, decoded: any) => {
        if (err) {
          return res.status(401).json({ 
            valid: false,
            error: "Invalid or expired token" 
          });
        }
        
        res.json({ 
          valid: true,
          userId: decoded.userId,
          deviceId: decoded.deviceId
        });
      });
    } catch (error) {
      console.error("Error validating token:", error);
      res.status(500).json({ error: "Failed to validate token" });
    }
  });

  // === Message & Conversation Endpoints ===
  
  // Send a message from mobile device (authenticated)
  app.post("/api/mobile/message", authenticateMobile, async (req: Request, res: Response) => {
    try {
      // Validate request body
      const validatedRequest = askMessageSchema.parse(req.body);
      const { user: userId, message, systemPrompt } = validatedRequest;
      
      // Get existing conversation
      const conversation = await storage.getConversation(userId);
      
      // Analyze the message for action items
      const analysisResult = await analyzeMessage(message);
      let metadata = {};
      
      if (analysisResult.success) {
        metadata = { analysis: analysisResult.analysis };
        
        // Process reminders, if any
        if (analysisResult.analysis.containsReminder) {
          const reminderItems = analysisResult.analysis.actionItems.filter(
            (item: string) => item.toLowerCase().includes("remind") || 
                             item.toLowerCase().includes("remember") ||
                             item.toLowerCase().includes("schedule")
          );
          
          // Create reminders automatically
          if (reminderItems.length > 0) {
            // Implementation for creating reminders would go here
          }
        }
      }
      
      // Save user message to storage
      await storage.saveMessage({
        userId,
        role: "user",
        content: message,
        metadata
      });
      
      // Send request to OpenAI
      const aiResponse = await getChatCompletion(conversation.messages, systemPrompt);
      
      if (!aiResponse.success) {
        throw new Error(aiResponse.error || "AI service error");
      }
      
      // Save AI response to storage
      await storage.saveMessage({
        userId,
        role: "assistant",
        content: aiResponse.reply || "Sorry, I couldn't generate a response.",
        metadata: { 
          followUp: analysisResult.success ? analysisResult.analysis.actionItems : []
        }
      });
      
      // Return the response
      res.json({ 
        reply: aiResponse.reply,
        analysisResult: analysisResult.success ? analysisResult.analysis : null
      });
    } catch (error: any) {
      console.error("Error processing mobile message:", error);
      res.status(500).json({ error: error.message || "Failed to process message" });
    }
  });
  
  // Get conversation history for mobile device
  app.get("/api/mobile/conversation/:userId", authenticateMobile, async (req: Request, res: Response) => {
    try {
      const userId = req.params.userId || "default";
      const conversation = await storage.getConversation(userId);
      res.json(conversation);
    } catch (error) {
      console.error("Error fetching mobile conversation:", error);
      res.status(500).json({ error: "Failed to fetch conversation history" });
    }
  });
  
  // === Vision & Camera Integration ===
  
  // Process camera input from mobile device
  app.post("/api/mobile/vision", authenticateMobile, async (req: Request, res: Response) => {
    try {
      const { message, image, timestamp } = req.body;
      
      if (!message && !image) {
        return res.status(400).json({ error: "Either message or image is required" });
      }
      
      // Check if API key is configured
      if (!process.env.OPENAI_API_KEY) {
        return res.status(500).json({ 
          error: "OpenAI API key is not configured", 
          needsApiKey: true 
        });
      }
      
      // Prepare the message content
      const messageContent: any[] = [];
      
      // Add the text message if provided
      if (message) {
        messageContent.push({
          type: "text",
          text: message
        });
      }
      
      // Add the image if provided
      if (image) {
        messageContent.push({
          type: "image_url",
          image_url: {
            url: `data:image/jpeg;base64,${image}`
          }
        });
      }
      
      // Use OpenAI to analyze the image and respond
      const openaiClient = new OpenAI({ 
        apiKey: process.env.OPENAI_API_KEY
      });
      
      const response = await openaiClient.chat.completions.create({
        model: "gpt-4o", // Use GPT-4o for vision capabilities
        messages: [
          {
            role: "system",
            content: `You are Valor AI, a helpful assistant that can see through the user's phone camera or smart glasses. 
            Your job is to analyze what the user is looking at and provide helpful guidance.
            
            If you see code, you can help debug it, suggest improvements, or explain how it works.
            If you see a physical object or environment, describe what you see and provide relevant information.
            If you're asked to detect if someone is lying or being deceptive, analyze facial expressions, body language, and statement consistency.
            
            Always be concise, practical, and focused on helping the user accomplish their immediate task.`
          },
          {
            role: "user",
            content: messageContent
          }
        ],
        max_tokens: 500,
      });
      
      const reply = response.choices[0].message.content || "I'm not sure what I'm looking at.";
      
      // Save this interaction to the conversation history
      await storage.saveMessage({
        userId: "default",
        role: "user",
        content: message || "Shared an image",
        metadata: {
          hasImage: !!image,
          timestamp,
          fromMobile: true
        }
      });
      
      await storage.saveMessage({
        userId: "default",
        role: "assistant",
        content: reply,
        metadata: {
          fromVision: true,
          timestamp: new Date().toISOString(),
          fromMobile: true
        }
      });
      
      res.json({ reply });
    } catch (error: any) {
      console.error("Mobile vision processing error:", error);
      res.status(500).json({ error: error.message || "Failed to process visual input" });
    }
  });
  
  // === Notification & Background Processing ===
  
  // Register for push notifications
  app.post("/api/mobile/notifications/register", authenticateMobile, async (req: Request, res: Response) => {
    try {
      const { deviceId, token, platform } = req.body;
      
      if (!deviceId || !token || !platform) {
        return res.status(400).json({ error: "Device ID, token, and platform are required" });
      }
      
      // Store notification token in database
      // This would be implemented in a real production system
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error registering for notifications:", error);
      res.status(500).json({ error: "Failed to register for notifications" });
    }
  });
  
  // Get background processing config
  app.get("/api/mobile/background/config", authenticateMobile, async (req: Request, res: Response) => {
    try {
      // Return configuration for background processing
      res.json({
        enabled: true,
        intervalMinutes: 15,
        batteryOptimization: true,
        dataUsageLimit: "moderate",
        features: {
          proactiveMessages: true,
          lifelogging: true,
          locationAwareness: true,
          backgroundAnalysis: true
        }
      });
    } catch (error) {
      console.error("Error fetching background config:", error);
      res.status(500).json({ error: "Failed to fetch background processing configuration" });
    }
  });
  
  // Update background processing config
  app.post("/api/mobile/background/config", authenticateMobile, async (req: Request, res: Response) => {
    try {
      const { enabled, intervalMinutes, batteryOptimization, dataUsageLimit, features } = req.body;
      
      // Update configuration in database
      // This would be implemented in a real production system
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating background config:", error);
      res.status(500).json({ error: "Failed to update background processing configuration" });
    }
  });
}

/**
 * Middleware to authenticate mobile API requests
 */
function authenticateMobile(req: Request, res: Response, next: Function) {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: "Authorization token required" });
    }
    
    const token = authHeader.split(' ')[1];
    
    jwt.verify(token, JWT_SECRET, (err: any, decoded: any) => {
      if (err) {
        return res.status(401).json({ error: "Invalid or expired token" });
      }
      
      // Add decoded token info to request
      (req as any).user = decoded;
      next();
    });
  } catch (error) {
    console.error("Authentication error:", error);
    res.status(500).json({ error: "Authentication failed" });
  }
}