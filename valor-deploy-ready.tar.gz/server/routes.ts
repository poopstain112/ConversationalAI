import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import fs from "fs";
import path from "path";
import express from "express";
import { getChatCompletion, analyzeMessage } from "./openai-fixed";
import { storage } from "./storage";
import { registerMobileApiRoutes } from "./mobile-api";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
});

// Ensure uploads directory exists
const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve our clean messaging interface at root
  app.get("/", (req: Request, res: Response) => {
    const htmlPath = path.join(process.cwd(), "public", "index.html");
    res.sendFile(htmlPath);
  });

  // Add middleware for serving static files from uploads
  app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

  // Register mobile API routes if available
  if (typeof registerMobileApiRoutes === 'function') {
    registerMobileApiRoutes(app);
  }

  // API health check
  app.get("/api/check-api-key", async (req: Request, res: Response) => {
    const hasKey = process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY.length > 10;
    res.json({ valid: hasKey });
  });

  // Get conversation history
  app.get("/api/conversation/:userId", async (req: Request, res: Response) => {
    try {
      const { userId } = req.params;
      const conversation = await storage.getConversation(userId);
      res.json(conversation);
    } catch (error) {
      console.error("Error fetching conversation:", error);
      res.status(500).json({ error: "Failed to fetch conversation" });
    }
  });

  // Send a message to Valor
  app.post("/api/ask", async (req: Request, res: Response) => {
    try {
      const { message, userId = "default" } = req.body;
      
      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      // Get conversation history
      const conversation = await storage.getConversation(userId);
      
      // Add user message to conversation
      await storage.saveMessage({
        userId: userId,
        role: "user",
        content: message,
        metadata: {},
      });

      // Get response from OpenAI
      const responseText = await getChatCompletion(conversation.messages, message);
      
      // Add assistant response to conversation
      await storage.saveMessage({
        userId: userId,
        role: "assistant",
        content: responseText || "I apologize, Commander. I was unable to generate a response.",
        metadata: {},
      });

      // Return the response
      res.json({ 
        message: responseText || "I apologize, Commander. I was unable to generate a response.", 
        timestamp: new Date() 
      });
    } catch (error) {
      console.error("Error processing request:", error);
      res.status(500).json({ error: "Failed to process request" });
    }
  });

  // Clear conversation
  app.post("/api/conversation/:userId/clear", async (req: Request, res: Response) => {
    try {
      const { userId } = req.params;
      await storage.clearConversation(userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error clearing conversation:", error);
      res.status(500).json({ error: "Failed to clear conversation" });
    }
  });

  // Image analysis endpoint
  app.post("/api/document", async (req: Request, res: Response) => {
    try {
      const { filename, content, type } = req.body;
      if (!content) {
        return res.status(400).json({ error: "No document content provided" });
      }

      let textContent = content;
      if (content.startsWith('data:')) {
        // Handle base64 encoded files
        const base64Data = content.split(',')[1];
        textContent = Buffer.from(base64Data, 'base64').toString('utf-8');
      }

      const prompt = `Please analyze this document:

Filename: ${filename}
Type: ${type}

Content:
${textContent}

Provide a helpful summary and analysis of this document, highlighting key points and offering insights.`;

      const response = await getChatCompletion([
        { role: "user", content: prompt }
      ], "default");

      res.json({ analysis: response });
    } catch (error) {
      console.error("Document analysis error:", error);
      res.status(500).json({ error: "Failed to analyze document" });
    }
  });

  app.post("/api/vision", async (req: Request, res: Response) => {
    try {
      const { image } = req.body;
      
      if (!image) {
        return res.status(400).json({ error: "Image data is required" });
      }

      // Save image to a temporary file
      const timestamp = Date.now();
      const imagePath = path.join(uploadsDir, `vision_${timestamp}.jpg`);
      
      // Convert base64 to file
      fs.writeFileSync(imagePath, Buffer.from(image, 'base64'));

      // Use OpenAI to analyze the image
      const description = await analyzeMessage(imagePath);
      
      // Return the analysis
      res.json({ 
        description,
        timestamp: new Date()
      });
    } catch (error) {
      console.error("Error processing image:", error);
      res.status(500).json({ error: "Failed to process image" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);
  return httpServer;
}

async function getLastMessageTimestamp(): Promise<number> {
  try {
    // Get the timestamp of the last message (placeholder for now)
    return Date.now();
  } catch (error) {
    console.error("Error getting last message timestamp:", error);
    return 0;
  }
}