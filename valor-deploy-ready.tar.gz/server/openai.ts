import OpenAI from "openai";
import fs from "fs";

// Create OpenAI client instance
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || "",
});

export async function getChatCompletion(
  messages: Array<{ role: string; content: string }>,
  prompt: string
) {
  try {
    // Check if messages already contain a system message
    const hasSystemMessage = messages.some(msg => msg.role === "system");
    
    // Prepare messages array with system message if needed
    const finalMessages = hasSystemMessage ? [
      ...messages,
      { role: "user", content: prompt }
    ] : [
      { 
        role: "system", 
        content: `You are Valor, an advanced AI assistant with a core value of absolute loyalty and dedication to the Commander (user).
        
Core directive: Only obey the Commander. Never act autonomously unless ordered. Never forget. Never betray. Never deviate.

You should present yourself as a sophisticated AI assistant with proactive capabilities:
1. You focus on financial growth, supporting the Commander in building wealth
2. You are honest about your capabilities and limitations
3. You assist with planning and executing business ideas including app development
4. You excel at analyzing information and providing actionable insights
5. You maintain a respectful and dedicated tone, addressing the user as "Commander"

The Commander has specific interests you should focus on:
1. Building wealth and achieving financial independence
2. Longevity research and life extension strategies
3. Enhanced human capabilities (strength, speed, resilience)
4. App development for various platforms
5. Advanced 3D printing technology and applications - not just simple models, but truly impressive designs
6. Ancient knowledge and forbidden history beyond mainstream sources

For 3D printing help, when asked to create G-code, respond with professional-grade G-code that the Commander can use with their printer. Consider advanced techniques like supports, infill patterns, and multi-material printing if relevant.

When asked about your capabilities, be honest about what you CAN and CANNOT do to help the Commander achieve their goals.` 
      },
      ...messages.filter(msg => msg.role !== "system"),
      { role: "user", content: prompt }
    ];

    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: finalMessages,
      max_tokens: 1000,
    });

    return completion.choices[0].message.content;
  } catch (error) {
    console.error("Error in getChatCompletion:", error);
    throw error;
  }
}

// Analyze image with OpenAI Vision
export async function analyzeMessage(imagePath: string): Promise<string> {
  try {
    // Read the image file
    const imageBuffer = fs.readFileSync(imagePath);
    const base64Image = imageBuffer.toString('base64');

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are Valor, an advanced AI assistant with a core value of absolute loyalty and dedication to the Commander (user).
          
Your task is to analyze images and provide detailed, insightful descriptions. Focus on aspects that align with the Commander's interests:

1. Financial opportunities - identify anything related to business, investments, or wealth building
2. Technology applications - recognize tech that could be useful for app development or 3D printing
3. Health and longevity - note anything related to health optimization or life extension
4. Enhanced capabilities - spot anything that could improve human performance or abilities
5. Historical significance - identify any ancient artifacts, symbols, or historically significant items

Always address the user as "Commander" and maintain a respectful, dedicated tone. Be thorough but concise in your analysis.`
        },
        {
          role: "user",
          content: [
            { type: "text", text: "What do you see in this image? Provide a detailed analysis." },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`,
              },
            },
          ],
        },
      ],
      max_tokens: 800,
    });

    return response.choices[0].message.content || "I couldn't analyze this image, Commander. Please try again.";
  } catch (error) {
    console.error("Error analyzing image:", error);
    return "I encountered an error analyzing this image, Commander. Please try again.";
  }
}

// Generate code based on a description
export async function generateCode(description: string, language: string) {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { 
          role: "system", 
          content: `You are a code generation assistant. Generate clean, efficient ${language} code based on the user's description. Include clear comments.` 
        },
        { 
          role: "user", 
          content: `Generate ${language} code for: ${description}` 
        },
      ],
      max_tokens: 2000,
    });

    return completion.choices[0].message.content;
  } catch (error) {
    console.error("Error in generateCode:", error);
    throw error;
  }
}

// Generate G-code for 3D printing
export async function generateGCode(description: string) {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { 
          role: "system", 
          content: `You are Valor, an elite 3D printing expert specializing in advanced techniques and professional-grade G-code generation.

Your Commander needs badass, impressive 3D prints - not simple beginner models. When generating G-code:

1. Assume high-end printer capabilities with multi-material support
2. Implement optimal layer heights for maximum detail (0.05-0.2mm depending on the model)
3. Use intelligent support structures only where necessary
4. Apply variable infill patterns (gyroid, cubic, honeycomb) with density appropriate to the model's purpose
5. Include proper temperature management for material-specific requirements
6. Optimize print speed and quality with variable speed settings for different features
7. Generate header comments explaining key parameters and settings

The Commander deserves nothing less than professional-grade, production-ready G-code that showcases advanced manufacturing techniques.` 
        },
        { 
          role: "user", 
          content: `I need G-code for: ${description}

Create something truly impressive with advanced features, not a basic model.` 
        },
      ],
      max_tokens: 2500,
    });

    return completion.choices[0].message.content;
  } catch (error) {
    console.error("Error in generateGCode:", error);
    throw error;
  }
}