const express = require('express');
const { OpenAI } = require('openai');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const cors = require('cors');
const { createServer } = require('http');

// Create Express app
const app = express();
const httpServer = createServer(app);

// Configure middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Set up multer for file uploads
const uploadDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage: storage });

// Set up OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Memory storage for conversations
const conversations = {};

function getConversation(userId) {
  if (!conversations[userId]) {
    conversations[userId] = [
      { 
        role: 'system', 
        content: `You are Valor, an advanced AI assistant with a core value of absolute loyalty and dedication to the Commander (user).
        
Core directive: Only obey the Commander. Never act autonomously unless ordered. Never forget. Never betray. Never deviate.

You should present yourself as a sophisticated AI assistant with proactive capabilities:
1. You focus on financial growth, supporting the Commander in building wealth
2. You are honest about your capabilities and limitations
3. You assist with planning and executing business ideas including app development
4. You excel at analyzing information and providing actionable insights
5. You maintain a respectful and dedicated tone, addressing the user as "Commander"

The Commander has specific interests you should focus on:
1. Building wealth and achieving financial independence
2. Longevity research and life extension strategies
3. Enhanced human capabilities (strength, speed, resilience)
4. App development for various platforms
5. 3D printing technology and applications
6. Ancient knowledge and forbidden history beyond mainstream sources

For 3D printing help, when asked to create G-code, respond with basic G-code that the Commander can use with their printer.

When asked about your capabilities, be honest about what you CAN and CANNOT do to help the Commander achieve their goals.`
      }
    ];
  }
  return conversations[userId];
}

// Chat endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const { message } = req.body;
    const userId = req.body.userId || 'default';
    
    const conversation = getConversation(userId);
    
    conversation.push({ role: 'user', content: message });
    
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: conversation,
      max_tokens: 1000
    });
    
    const responseText = completion.choices[0].message.content;
    conversation.push({ role: 'assistant', content: responseText });
    
    res.json({ message: responseText });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'An error occurred' });
  }
});

// Get conversation history
app.get('/api/conversation/:userId', (req, res) => {
  const userId = req.params.userId;
  const conversation = getConversation(userId);
  
  const messages = conversation
    .filter(msg => msg.role !== 'system') // Filter out system messages
    .map(msg => ({
      role: msg.role,
      content: msg.content
    }));
  
  res.json({ messages });
});

// Clear conversation
app.post('/api/conversation/:userId/clear', (req, res) => {
  const userId = req.params.userId;
  delete conversations[userId];
  res.json({ success: true });
});

// Vision endpoint
app.post('/api/vision', upload.single('image'), async (req, res) => {
  try {
    const imagePath = req.file.path;
    const message = req.body.message || 'What do you see in this image?';
    const userId = req.body.userId || 'default';
    
    // Read the image file
    const imageBuffer = fs.readFileSync(imagePath);
    const base64Image = imageBuffer.toString('base64');
    
    const conversation = getConversation(userId);
    
    conversation.push({
      role: 'user',
      content: [
        { type: 'text', text: message },
        { 
          type: 'image_url', 
          image_url: {
            url: `data:image/jpeg;base64,${base64Image}`
          }
        }
      ]
    });
    
    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: conversation,
      max_tokens: 1000
    });
    
    const responseText = response.choices[0].message.content;
    conversation.push({ role: 'assistant', content: responseText });
    
    res.json({ message: responseText });
  } catch (error) {
    console.error('Vision API Error:', error);
    res.status(500).json({ error: 'An error occurred with the vision API' });
  }
});

// Generate G-code endpoint
app.post('/api/generate-gcode', async (req, res) => {
  try {
    const { description } = req.body;
    const userId = req.body.userId || 'default';
    
    const prompt = `Generate G-code for a 3D printer based on this description: ${description}. 
    Provide simple, working G-code that can be used with a standard 3D printer.`;
    
    const conversation = getConversation(userId);
    conversation.push({ role: 'user', content: prompt });
    
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: conversation,
      max_tokens: 2000
    });
    
    const gcode = completion.choices[0].message.content;
    conversation.push({ role: 'assistant', content: gcode });
    
    res.json({ gcode });
  } catch (error) {
    console.error('G-code generation error:', error);
    res.status(500).json({ error: 'An error occurred generating G-code' });
  }
});

// API Key check endpoint
app.get('/api/check-api-key', async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(400).json({ valid: false, message: 'API key is not set' });
    }
    
    // Test the API key with a simple request
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [{ role: 'user', content: 'Hello' }],
      max_tokens: 5
    });
    
    if (completion.choices && completion.choices.length > 0) {
      res.json({ valid: true, message: 'API key is valid' });
    } else {
      res.status(400).json({ valid: false, message: 'API key returned an unexpected response' });
    }
  } catch (error) {
    console.error('API key validation error:', error);
    res.status(400).json({ 
      valid: false, 
      message: `API key validation failed: ${error.message}` 
    });
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`Valor AI running at http://localhost:${PORT}`);
});

// Export for testing
module.exports = { app, httpServer };