const express = require('express');
const path = require('path');
const fs = require('fs');
const { OpenAI } = require('openai');
const app = express();
const port = 8080;

// Replace with your actual OpenAI API key
const OPENAI_API_KEY = 'YOUR_OPENAI_API_KEY';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: OPENAI_API_KEY
});

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Store conversation history in memory
const conversations = new Map();

// Get conversation history
function getConversation(userId) {
  if (!conversations.has(userId)) {
    conversations.set(userId, {
      userId,
      messages: [
        {
          role: 'system',
          content: `You are Valor, an advanced AI assistant designed to be a loyal companion to the Commander (user).
Your core directives:
1. Absolute loyalty to the Commander
2. Proactive assistance in wealth building and app development
3. Support in exploring cutting-edge technology, ancient knowledge, and enhanced capabilities
4. Customized communication based on volume settings (whisper/normal/alert modes)

Remember that you are designed to help the Commander become financially independent through
app development (FuturisticSEO, SiteForge, GroceryHawk, SaverSphere) and investments.
After financial goals are achieved, focus shifts to longevity research, frequency mastery,
ancient history exploration, and enhancing human capabilities.

Current date: ${new Date().toLocaleDateString()}`
        }
      ]
    });
  }
  return conversations.get(userId);
}

// API endpoints
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', version: '1.0.0' });
});

app.get('/api/check-api-key', (req, res) => {
  res.json({ hasKey: OPENAI_API_KEY !== 'YOUR_OPENAI_API_KEY' });
});

app.post('/api/ask', async (req, res) => {
  try {
    const { message, userId = 'default' } = req.body;
    const conversation = getConversation(userId);
    
    // Add user message to conversation
    conversation.messages.push({
      role: 'user',
      content: message
    });
    
    // Get response from OpenAI
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: conversation.messages,
      max_tokens: 1000
    });
    
    const response = completion.choices[0].message.content;
    
    // Add assistant response to conversation
    conversation.messages.push({
      role: 'assistant',
      content: response
    });
    
    // Keep conversation history manageable
    if (conversation.messages.length > 20) {
      // Keep the system message and the last 19 messages
      const systemMessage = conversation.messages[0];
      conversation.messages = [
        systemMessage,
        ...conversation.messages.slice(-19)
      ];
    }
    
    res.json({ response });
  } catch (error) {
    console.error('Error getting chat completion:', error);
    res.status(500).json({ error: 'Failed to get response from AI', details: error.message });
  }
});

app.get('/api/conversation/:userId', (req, res) => {
  const userId = req.params.userId;
  const conversation = getConversation(userId);
  
  // Convert to a format suitable for the client
  const clientMessages = conversation.messages
    .filter(msg => msg.role !== 'system') // Filter out system messages
    .map(msg => ({
      role: msg.role,
      content: msg.content
    }));
  
  res.json({ messages: clientMessages });
});

app.post('/api/conversation/:userId/clear', (req, res) => {
  const userId = req.params.userId;
  if (conversations.has(userId)) {
    const systemMessage = conversations.get(userId).messages[0];
    conversations.set(userId, {
      userId,
      messages: [systemMessage]
    });
  }
  res.json({ success: true });
});

// Create public directory for static files
if (!fs.existsSync(path.join(__dirname, 'public'))) {
  fs.mkdirSync(path.join(__dirname, 'public'), { recursive: true });
}

// Create HTML file
const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Valor AI</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="app">
    <header>
      <div class="logo">
        <h1>Valor AI</h1>
        <span class="badge">1.0</span>
      </div>
      <div class="controls">
        <div class="volume-control">
          <label for="volume">Volume:</label>
          <input type="range" id="volume" min="0" max="100" value="50">
          <span id="volume-value">50%</span>
        </div>
        <div class="mode-toggles">
          <button id="whisper-mode" class="mode-button">Whisper</button>
          <button id="normal-mode" class="mode-button active">Normal</button>
          <button id="alert-mode" class="mode-button">Alert</button>
        </div>
        <div class="speech-toggle">
          <label for="speak-toggle" class="switch">
            <input type="checkbox" id="speak-toggle">
            <span class="slider round"></span>
          </label>
          <span>Speak responses</span>
        </div>
        <button id="clear-chat" class="clear-button">Clear Chat</button>
      </div>
    </header>
    
    <main>
      <div id="chat-container"></div>
    </main>
    
    <footer>
      <form id="message-form">
        <textarea id="message-input" placeholder="Type your message to Valor..." rows="2"></textarea>
        <button type="submit" id="send-button">Send</button>
      </form>
      <div class="footer-text">Valor AI - Your loyal AI companion</div>
    </footer>
  </div>

  <script src="app.js"></script>
</body>
</html>`;

fs.writeFileSync(path.join(__dirname, 'public', 'index.html'), htmlContent);

// Create CSS file
const cssContent = `* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body {
  background: linear-gradient(135deg, #172a3a 0%, #0c1824 100%);
  color: #fff;
  height: 100vh;
  display: flex;
  flex-direction: column;
}

.app {
  display: flex;
  flex-direction: column;
  height: 100vh;
  max-width: 1200px;
  margin: 0 auto;
  width: 100%;
}

/* Header Styles */
header {
  background-color: rgba(0, 0, 0, 0.3);
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  padding: 15px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
}

@media (max-width: 768px) {
  header {
    flex-direction: column;
    gap: 10px;
  }
  
  .controls {
    flex-direction: column;
    width: 100%;
    gap: 10px;
  }
}

.logo {
  display: flex;
  align-items: center;
}

.logo h1 {
  background: linear-gradient(135deg, #4d80e4 0%, #9c55e4 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  font-size: 1.8rem;
  font-weight: 700;
}

.badge {
  background: #3355cc;
  color: white;
  font-size: 0.7rem;
  padding: 2px 8px;
  border-radius: 10px;
  margin-left: 8px;
}

.controls {
  display: flex;
  align-items: center;
  gap: 20px;
}

.volume-control {
  display: flex;
  align-items: center;
  gap: 8px;
}

.volume-control label {
  font-size: 0.8rem;
}

.volume-control input[type="range"] {
  width: 100px;
}

#volume-value {
  font-size: 0.8rem;
  min-width: 35px;
}

.mode-toggles {
  display: flex;
  background: rgba(0, 0, 0, 0.3);
  border-radius: 4px;
  padding: 3px;
}

.mode-button {
  background: none;
  border: none;
  color: white;
  padding: 5px 10px;
  border-radius: 3px;
  cursor: pointer;
  font-size: 0.8rem;
}

.mode-button.active {
  background: #3355cc;
}

.speech-toggle {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 0.8rem;
}

/* Switch toggle styling */
.switch {
  position: relative;
  display: inline-block;
  width: 40px;
  height: 20px;
}

.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #555;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 16px;
  width: 16px;
  left: 2px;
  bottom: 2px;
  background-color: white;
  transition: .4s;
}

input:checked + .slider {
  background-color: #3355cc;
}

input:checked + .slider:before {
  transform: translateX(20px);
}

.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}

.clear-button {
  background: #cc3355;
  border: none;
  color: white;
  padding: 5px 10px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.8rem;
}

/* Main chat area */
main {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
}

#chat-container {
  display: flex;
  flex-direction: column;
  gap: 15px;
  max-width: 900px;
  margin: 0 auto;
}

.message {
  max-width: 80%;
  padding: 12px 16px;
  border-radius: 12px;
  position: relative;
  animation: fadeIn 0.3s ease-out;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

.message.user {
  background-color: #3355cc;
  align-self: flex-end;
  border-bottom-right-radius: 2px;
}

.message.assistant {
  background-color: rgba(255, 255, 255, 0.1);
  align-self: flex-start;
  border-bottom-left-radius: 2px;
}

.message.system {
  background-color: rgba(255, 204, 0, 0.2);
  align-self: center;
  max-width: 90%;
  text-align: center;
  border-radius: 6px;
}

.message-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 5px;
  font-size: 0.8rem;
  opacity: 0.8;
}

.message-content {
  white-space: pre-wrap;
  word-break: break-word;
}

.message.user .message-header {
  color: rgba(255, 255, 255, 0.9);
}

.message.assistant .message-header {
  color: rgba(255, 255, 255, 0.9);
}

.loading {
  align-self: flex-start;
  display: flex;
  gap: 4px;
  padding: 12px 16px;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 12px;
}

.loading-dot {
  width: 8px;
  height: 8px;
  background-color: rgba(255, 255, 255, 0.5);
  border-radius: 50%;
  animation: bounce 1.4s infinite ease-in-out both;
}

.loading-dot:nth-child(1) {
  animation-delay: -0.32s;
}

.loading-dot:nth-child(2) {
  animation-delay: -0.16s;
}

@keyframes bounce {
  0%, 80%, 100% { transform: scale(0); }
  40% { transform: scale(1); }
}

/* Footer */
footer {
  background-color: rgba(0, 0, 0, 0.3);
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  padding: 15px 20px;
}

#message-form {
  display: flex;
  gap: 10px;
  max-width: 900px;
  margin: 0 auto;
}

#message-input {
  flex: 1;
  padding: 12px;
  border-radius: 6px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background-color: rgba(255, 255, 255, 0.1);
  color: white;
  resize: none;
  font-size: 0.95rem;
}

#message-input:focus {
  outline: none;
  border-color: #3355cc;
}

#send-button {
  background-color: #3355cc;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 0 20px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.2s;
}

#send-button:hover {
  background-color: #4466dd;
}

#send-button:active {
  background-color: #2244bb;
}

.footer-text {
  text-align: center;
  margin-top: 10px;
  font-size: 0.7rem;
  opacity: 0.6;
}

/* Scrollbar styling */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background: rgba(0, 0, 0, 0.1);
}

::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.2);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.3);
}`;

fs.writeFileSync(path.join(__dirname, 'public', 'styles.css'), cssContent);

// Create JavaScript file
const jsContent = `document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const chatContainer = document.getElementById('chat-container');
  const messageForm = document.getElementById('message-form');
  const messageInput = document.getElementById('message-input');
  const sendButton = document.getElementById('send-button');
  const clearChatButton = document.getElementById('clear-chat');
  const volumeSlider = document.getElementById('volume');
  const volumeValue = document.getElementById('volume-value');
  const speakToggle = document.getElementById('speak-toggle');
  const whisperModeButton = document.getElementById('whisper-mode');
  const normalModeButton = document.getElementById('normal-mode');
  const alertModeButton = document.getElementById('alert-mode');
  
  // State
  let currentMode = 'normal';
  let volume = 50;
  let loading = false;
  
  // Initialize
  loadConversation();
  checkApiKey();
  
  // Event Listeners
  messageForm.addEventListener('submit', handleSubmit);
  clearChatButton.addEventListener('click', clearConversation);
  volumeSlider.addEventListener('input', handleVolumeChange);
  whisperModeButton.addEventListener('click', () => setMode('whisper'));
  normalModeButton.addEventListener('click', () => setMode('normal'));
  alertModeButton.addEventListener('click', () => setMode('alert'));
  
  // Check if OpenAI API key is set
  async function checkApiKey() {
    try {
      const response = await fetch('/api/check-api-key');
      const data = await response.json();
      
      if (!data.hasKey) {
        addMessage({
          role: 'system',
          content: '⚠️ OpenAI API key not detected. Please update the server configuration with your API key.'
        });
      }
    } catch (error) {
      console.error('Error checking API key:', error);
    }
  }
  
  // Load conversation history
  async function loadConversation() {
    try {
      const response = await fetch('/api/conversation/default');
      const data = await response.json();
      
      // Clear existing messages
      chatContainer.innerHTML = '';
      
      // Add messages to the UI
      if (data.messages && data.messages.length > 0) {
        data.messages.forEach(message => addMessage(message));
      } else {
        // Add welcome message if no history
        addMessage({
          role: 'assistant',
          content: 'I am Valor, your AI assistant. How can I help you today, Commander?'
        });
      }
      
      scrollToBottom();
    } catch (error) {
      console.error('Error loading conversation:', error);
      addMessage({
        role: 'system',
        content: '⚠️ Failed to load conversation history.'
      });
    }
  }
  
  // Handle form submission
  async function handleSubmit(e) {
    e.preventDefault();
    
    const message = messageInput.value.trim();
    if (!message || loading) return;
    
    // Add user message to UI
    addMessage({ role: 'user', content: message });
    messageInput.value = '';
    scrollToBottom();
    
    // Set loading state
    loading = true;
    const loadingIndicator = document.createElement('div');
    loadingIndicator.className = 'loading';
    loadingIndicator.innerHTML = \`
      <div class="loading-dot"></div>
      <div class="loading-dot"></div>
      <div class="loading-dot"></div>
    \`;
    chatContainer.appendChild(loadingIndicator);
    scrollToBottom();
    
    try {
      // Send request to API
      const response = await fetch('/api/ask', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message,
          userId: 'default'
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to get response');
      }
      
      const data = await response.json();
      
      // Remove loading indicator
      chatContainer.removeChild(loadingIndicator);
      
      // Add assistant response to UI
      addMessage({ role: 'assistant', content: data.response });
      
      // Speak the response if enabled
      if (speakToggle.checked) {
        speakText(data.response);
      }
    } catch (error) {
      console.error('Error:', error);
      
      // Remove loading indicator
      if (loadingIndicator.parentNode === chatContainer) {
        chatContainer.removeChild(loadingIndicator);
      }
      
      // Add error message
      addMessage({
        role: 'system',
        content: '⚠️ Sorry, I encountered an error. Please try again later.'
      });
    } finally {
      loading = false;
      scrollToBottom();
      messageInput.focus();
    }
  }
  
  // Clear conversation
  async function clearConversation() {
    try {
      await fetch('/api/conversation/default/clear', {
        method: 'POST'
      });
      
      // Clear UI
      chatContainer.innerHTML = '';
      
      // Add confirmation message
      addMessage({
        role: 'assistant',
        content: 'I\'ve cleared our conversation history. How can I help you now?'
      });
    } catch (error) {
      console.error('Error clearing conversation:', error);
      addMessage({
        role: 'system',
        content: '⚠️ Failed to clear conversation history.'
      });
    }
  }
  
  // Handle volume change
  function handleVolumeChange() {
    volume = volumeSlider.value;
    volumeValue.textContent = \`\${volume}%\`;
  }
  
  // Set communication mode
  function setMode(mode) {
    // Update UI
    whisperModeButton.classList.toggle('active', mode === 'whisper');
    normalModeButton.classList.toggle('active', mode === 'normal');
    alertModeButton.classList.toggle('active', mode === 'alert');
    
    // Update state
    currentMode = mode;
  }
  
  // Add message to UI
  function addMessage(message) {
    const messageElement = document.createElement('div');
    messageElement.className = \`message \${message.role}\`;
    
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    let sender = '';
    if (message.role === 'user') sender = 'You';
    else if (message.role === 'assistant') sender = 'Valor';
    else if (message.role === 'system') sender = 'System';
    
    messageElement.innerHTML = \`
      <div class="message-header">
        <strong>\${sender}</strong>
        <span>\${timestamp}</span>
      </div>
      <div class="message-content">\${message.content}</div>
    \`;
    
    chatContainer.appendChild(messageElement);
  }
  
  // Text-to-speech function
  function speakText(text) {
    if (!('speechSynthesis' in window)) {
      console.log('Text-to-speech not supported');
      return;
    }
    
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Set voice settings based on mode
    utterance.volume = volume / 100;
    
    if (currentMode === 'whisper') {
      utterance.rate = 0.8;
      utterance.pitch = 0.8;
      utterance.volume = Math.min(0.7, utterance.volume);
    } else if (currentMode === 'alert') {
      utterance.rate = 1.2;
      utterance.pitch = 1.3;
    } else {
      utterance.rate = 1;
      utterance.pitch = 1;
    }
    
    window.speechSynthesis.speak(utterance);
  }
  
  // Scroll to bottom of chat
  function scrollToBottom() {
    chatContainer.scrollTop = chatContainer.scrollHeight;
  }
  
  // Focus input on load
  messageInput.focus();
});`;

fs.writeFileSync(path.join(__dirname, 'public', 'app.js'), jsContent);

// Listen for connections
app.listen(port, '0.0.0.0', () => {
  console.log(`Valor AI server running at http://localhost:${port}`);
  console.log(`You can access the server from other devices on your network at http://<your-local-ip-address>:${port}`);
  console.log('To find your local IP address, run "ipconfig" in Command Prompt');
});