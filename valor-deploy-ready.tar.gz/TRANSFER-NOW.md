# Deploy Valor to Digital Ocean - 3 Steps

## Step 1: Download Files
- Download `valor-complete.zip` from this Replit
- Extract it on your computer

## Step 2: Digital Ocean App Platform
1. Go to Digital Ocean → Apps → Create App
2. Choose "Upload Source Code" 
3. Upload the extracted files
4. Set environment variables:
   - OPENAI_API_KEY: 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
   - NODE_ENV: production

## Step 3: Done
App deploys automatically. You get a live URL. Camera works immediately.

No droplets. No manual setup. No complexity.